// ==========================================
    // 1. DUAL-SCREEN VECTOR CONSTANTS
    // ==========================================
    const VW = 960;
    const VH = 540;
    const GRAVITY_STRENGTH = 1200;
    const TERMINAL_VELOCITY = 900;
    const baseSpeed = 350;
    let currentSpeed = 350;

    // ==========================================
    // WORLD EVENTS CONFIGURATION
    // ==========================================
    let currentWorldEvent = null;
    let eventCooldown = 20 + Math.random() * 10;
    let eventParticles = [];
    let eventSubTimer = 0;
    let activeGravityStrength = GRAVITY_STRENGTH;

    const BIOME_EVENTS = {
      0: [{type: 'coin_rain', name: 'Coin Rain'}, {type: 'rainbow', name: 'Rainbow'}],
      1: [{type: 'fog', name: 'Dense Fog'}, {type: 'fireflies', name: 'Firefly Swarm'}],
      2: [{type: 'sandstorm', name: 'Sandstorm'}],
      3: [{type: 'heavy_snow', name: 'Blizzard'}],
      4: [{type: 'ash_storm', name: 'Ash Rain'}, {type: 'lava_sparks', name: 'Lava Sparks'}],
      5: [{type: 'lightning', name: 'Lightning Storm'}],
      6: [{type: 'low_gravity', name: 'Low Gravity Event'}],
      7: [{type: 'meteor_shower', name: 'Meteor Shower'}],
      8: [{type: 'distortion', name: 'Space Distortion'}],
      9: [{type: 'gravity_pulses', name: 'Gravity Pulses'}]
    };

    // ==========================================
    // 2. GAME PROGRESS STATE & SAVE MODULE
    // ==========================================
    let gameState = {
      bestScore: 0,
      totalCoins: 0,
      totalFlips: 0,
      totalDeaths: 0,
      totalMeters: 0,
      maxBiomeIndex: 0,
      soundEnabled: true,
      musicEnabled: true,
      vibrationEnabled: true,
      
      // Customization properties
      unlockedCharacters: ['gravity_cube'],
      activeCharacter: 'gravity_cube',
      unlockedSkins: ['default'],
      activeSkin: 'default',
      unlockedTrails: ['none'],
      activeTrail: 'none',
      achievementsClaimed: [], 
      discoveredBiomes: ['Plains'], 
      
      // Stats records
      gamesPlayed: 0,
      coinsSpent: 0,
      
      // Daily Missions tracking
      missionsDateStamp: "",
      missions: []
    };

    // Character Configuration Catalogue
    const CHARACTERS = {
      gravity_cube: { name: "Gravity Cube", cost: 0, desc: "Prototype gravity test cube." },
      robo_runner: { name: "Robo Runner", cost: 250, desc: "A robotic experiment built for speed." },
      explorer: { name: "Explorer", cost: 500, desc: "Always searching for new worlds." },
      astronaut: { name: "Astronaut", cost: 1000, desc: "Trained to survive deep space." },
      ninja: { name: "Ninja", cost: 1500, desc: "Master of precision movement." },
      gravity_bot: { name: "Gravity Bot", cost: 2500, desc: "Advanced AI gravity controller." },
      gravity_master: { name: "Gravity Master", cost: 5000, desc: "The ultimate gravity manipulator." }
    };

    // Skins Configuration Catalogue
    const SKINS = {
      default: { name: "Default White", cost: 0, color: "#ffffff", burstColor: "#ffffff", effect: "pixel" },
      neon_green: { name: "Neon Green", cost: 100, color: "#22c55e", burstColor: "#22c55e", effect: "pixel" },
      cyber_cyan: { name: "Cyber Cyan", cost: 250, color: "#06b6d4", burstColor: "#06b6d4", effect: "pixel" },
      purple_core: { name: "Purple Core", cost: 500, color: "#a855f7", burstColor: "#a855f7", effect: "implosion" },
      gold_shift: { name: "Gold Shift", cost: 1000, color: "#eab308", burstColor: "#eab308", effect: "burst" },
      gravity_master: { name: "Gravity Master", cost: 2500, color: "#ec4899", burstColor: "#d946ef", effect: "implosion" }
    };

    // Trails Configuration Catalogue
    const TRAILS = {
      none: { name: "No Trail", cost: 0, color: "transparent" },
      fire: { name: "Fire Trail", cost: 250, color: "#f97316" },
      ice: { name: "Ice Trail", cost: 500, color: "#38bdf8" },
      lightning: { name: "Lightning Trail", cost: 1000, color: "#22d3ee" },
      galaxy: { name: "Galaxy Trail", cost: 2000, color: "#a855f7" },
      gravity: { name: "Gravity Trail", cost: 3500, color: "#ec4899" }
    };

    // Milestone Configurations
    const ACHIEVEMENT_TEMPLATES = [
      { id: "first_run", name: "First Run", desc: "Initiate your first polarity vector run", reqType: "games", reqVal: 1, bounty: 25 },
      { id: "first_death", name: "First Death", desc: "Experience systems failure once", reqType: "deaths", reqVal: 1, bounty: 15 },
      { id: "dist_500", name: "Corridor Specialist", desc: "Navigate 500 meters in a run", reqType: "bestDist", reqVal: 500, bounty: 50 },
      { id: "dist_1000", name: "Orbital Cruiser", desc: "Navigate 1000 meters in a run", reqType: "bestDist", reqVal: 1000, bounty: 100 },
      { id: "dist_2500", name: "Biome Pioneer", desc: "Navigate 2500 meters in a run", reqType: "bestDist", reqVal: 2500, bounty: 250 },
      { id: "dist_5000", name: "Dimensional Splicer", desc: "Navigate 5000 meters in a run", reqType: "bestDist", reqVal: 5000, bounty: 500 },
      { id: "coins_100", name: "Collector Cadet", desc: "Collect 100 total career coins", reqType: "coinsCollected", reqVal: 100, bounty: 50 },
      { id: "coins_500", name: "Treasurer Pro", desc: "Collect 500 total career coins", reqType: "coinsCollected", reqVal: 500, bounty: 150 },
      { id: "coins_1000", name: "Galaxy Bankroller", desc: "Collect 1000 total career coins", reqType: "coinsCollected", reqVal: 1000, bounty: 400 },
      { id: "unlock_skin", name: "Cosmetic Explorer", desc: "Unlock your first skin modification", reqType: "skinsOwned", reqVal: 2, bounty: 50 },
      { id: "unlock_all", name: "Wardrobe Archon", desc: "Unlock all premium player skins", reqType: "skinsOwned", reqVal: 6, bounty: 500 }
    ];

    // Daily Mission Templates pools
    const MISSION_POOL = [
      { id: "daily_coins", text: "Collect 25 Coins", reqType: "coins", reqVal: 25, bounty: 50 },
      { id: "daily_meters", text: "Travel 1000m total", reqType: "meters", reqVal: 1000, bounty: 75 },
      { id: "daily_flips", text: "Flip Gravity 50 Times", reqType: "flips", reqVal: 50, bounty: 60 },
      { id: "daily_runs", text: "Complete 3 Active Runs", reqType: "runs", reqVal: 3, bounty: 100 }
    ];

    // Explicitly declare all DOM elements
    let orientationOverlay, achievementToast, achievementToastTitle, achievementToastDesc, gameContainer, canvas, ctx;
    let splashScreen, loadingScreen, loadingStatusText, loadingPercentage, loadingProgressBar;
    let mainMenu, menuBestScore, menuTotalCoins, btnCloudStatus, cloudStatusDot, cloudStatusText;
    let btnSettingsOpen, btnPlayGame, btnShopOpen, btnQuestsOpen, btnStatsOpen, gameplayHud;
    let hudDistance, hudCoins, hudChallengeBadge, gameplayAlert, gameplayAlertTitle;
    let eventAlert, eventAlertTitle; // World Events UI
    let shopModal, shopWallet, btnShopClose, tabCharacters, tabSkins, tabTrails, shopItemsGrid;
    let questsModal, btnQuestsClose, missionsTimer, dailyMissionsList, achievementsList;
    let gameOverScreen, goDistance, goNewBest, goBestScore, goCoinsRun, goCoinsTotal;
    let btnRestart, btnGoHome, btnRevive, goReviveCount;
    let settingsModal, btnSettingsClose, toggleSound, toggleMusic, toggleVibration;
    let btnCloudModal, btnResetData, cloudModal, btnCloudClose, cloudConnectionStatus, cloudUserId, btnCloudConnect, btnCloudSync;
    let statsModal, btnStatsClose, statTotalFlips, statTotalDeaths, statMaxBiome, statTotalMeters;
    let customAlertModal, customAlertTitle, customAlertMessage, customAlertConfirm, customAlertCancel;
    
    // UI Additions for Biome Progress Bar integrated in HUD
    let bpCurrent, bpNext, bpDistance, bpBar;

    function initDOMReferences() {
      orientationOverlay = document.getElementById('orientation-overlay');
      achievementToast = document.getElementById('achievement-toast');
      achievementToastTitle = document.getElementById('achievement-toast-title');
      achievementToastDesc = document.getElementById('achievement-toast-desc');
      gameContainer = document.getElementById('game-container');
      canvas = document.getElementById('gameCanvas');
      ctx = canvas.getContext('2d');
      splashScreen = document.getElementById('splash-screen');
      loadingScreen = document.getElementById('loading-screen');
      loadingStatusText = document.getElementById('loading-status-text');
      loadingPercentage = document.getElementById('loading-percentage');
      loadingProgressBar = document.getElementById('loading-progress-bar');
      mainMenu = document.getElementById('main-menu');
      menuBestScore = document.getElementById('menu-best-score');
      menuTotalCoins = document.getElementById('menu-total-coins');
      btnCloudStatus = document.getElementById('btn-cloud-status');
      cloudStatusDot = document.getElementById('cloud-status-dot');
      cloudStatusText = document.getElementById('cloud-status-text');
      btnSettingsOpen = document.getElementById('btn-settings-open');
      btnPlayGame = document.getElementById('btn-play-game');
      btnShopOpen = document.getElementById('btn-shop-open');
      btnQuestsOpen = document.getElementById('btn-quests-open');
      btnStatsOpen = document.getElementById('btn-stats-open');
      gameplayHud = document.getElementById('gameplay-hud');
      hudDistance = document.getElementById('hud-distance');
      hudCoins = document.getElementById('hud-coins');
      hudChallengeBadge = document.getElementById('hud-challenge-badge');
      gameplayAlert = document.getElementById('gameplay-alert');
      gameplayAlertTitle = document.getElementById('gameplay-alert-title');
      
      eventAlert = document.getElementById('event-alert');
      eventAlertTitle = document.getElementById('event-alert-title');
      
      shopModal = document.getElementById('shop-modal');
      shopWallet = document.getElementById('shop-wallet');
      btnShopClose = document.getElementById('btn-shop-close');
      tabCharacters = document.getElementById('tab-characters');
      tabSkins = document.getElementById('tab-skins');
      tabTrails = document.getElementById('tab-trails');
      shopItemsGrid = document.getElementById('shop-items-grid');
      questsModal = document.getElementById('quests-modal');
      btnQuestsClose = document.getElementById('btn-quests-close');
      missionsTimer = document.getElementById('missions-timer');
      dailyMissionsList = document.getElementById('daily-missions-list');
      achievementsList = document.getElementById('achievements-list');
      gameOverScreen = document.getElementById('game-over-screen');
      goDistance = document.getElementById('go-distance');
      goNewBest = document.getElementById('go-new-best');
      goBestScore = document.getElementById('go-best-score');
      goCoinsRun = document.getElementById('go-coins-run');
      goCoinsTotal = document.getElementById('go-coins-total');
      btnRestart = document.getElementById('btn-restart');
      btnGoHome = document.getElementById('btn-go-home');
      btnRevive = document.getElementById('btn-revive');
      goReviveCount = document.getElementById('go-revive-count');
      settingsModal = document.getElementById('settings-modal');
      btnSettingsClose = document.getElementById('settings-modal');
      toggleSound = document.getElementById('toggle-sound');
      toggleMusic = document.getElementById('toggle-music');
      toggleVibration = document.getElementById('toggle-vibration');
      btnCloudModal = document.getElementById('btn-cloud-modal');
      btnResetData = document.getElementById('btn-reset-data');
      cloudModal = document.getElementById('cloud-modal');
      btnCloudClose = document.getElementById('btn-cloud-close');
      cloudConnectionStatus = document.getElementById('cloud-connection-status');
      cloudUserId = document.getElementById('cloud-user-id');
      btnCloudConnect = document.getElementById('btn-cloud-connect');
      btnCloudSync = document.getElementById('btn-cloud-sync');
      statsModal = document.getElementById('stats-modal');
      btnStatsClose = document.getElementById('btn-stats-close');
      statTotalFlips = document.getElementById('stat-total-flips');
      statTotalDeaths = document.getElementById('stat-total-deaths');
      statMaxBiome = document.getElementById('stat-max-biome');
      statTotalMeters = document.getElementById('stat-total-meters');
      customAlertModal = document.getElementById('custom-alert-modal');
      customAlertTitle = document.getElementById('custom-alert-title');
      customAlertMessage = document.getElementById('custom-alert-message');
      customAlertConfirm = document.getElementById('custom-alert-confirm');
      customAlertCancel = document.getElementById('custom-alert-cancel');
      
      bpCurrent = document.getElementById('bp-current');
      bpNext = document.getElementById('bp-next');
      bpDistance = document.getElementById('bp-distance');
      bpBar = document.getElementById('bp-bar');
    }

    function loadSavedData() {
      const local = localStorage.getItem('gravity_shift_save_state_v4');
      if (local) {
        try {
          gameState = { ...gameState, ...JSON.parse(local) };
        } catch (e) {
          console.warn("Could not read local save, resorting to default.");
        }
      }
      // Guarantee fallback collections have basic structures
      if (!gameState.unlockedCharacters) gameState.unlockedCharacters = ['gravity_cube'];
      if (!gameState.activeCharacter) gameState.activeCharacter = 'gravity_cube';
      if (!gameState.unlockedSkins) gameState.unlockedSkins = ['default'];
      if (!gameState.activeSkin) gameState.activeSkin = 'default';
      if (!gameState.unlockedTrails) gameState.unlockedTrails = ['none'];
      if (!gameState.activeTrail) gameState.activeTrail = 'none';
      if (!gameState.achievementsClaimed) gameState.achievementsClaimed = [];
      if (!gameState.discoveredBiomes) gameState.discoveredBiomes = ['Plains'];
      
      initDailyMissions();
      updateUIWithState();
    }

    function saveLocalData() {
      localStorage.setItem('gravity_shift_save_state_v4', JSON.stringify(gameState));
      updateUIWithState();
    }

    function updateUIWithState() {
      if (menuBestScore) menuBestScore.innerText = `${Math.floor(gameState.bestScore)}m`;
      if (menuTotalCoins) menuTotalCoins.innerText = gameState.totalCoins;
      if (toggleSound) toggleSound.checked = gameState.soundEnabled;
      if (toggleMusic) toggleMusic.checked = gameState.musicEnabled;
      if (toggleVibration) toggleVibration.checked = gameState.vibrationEnabled;
      if (statTotalFlips) statTotalFlips.innerText = gameState.totalFlips;
      if (statTotalDeaths) statTotalDeaths.innerText = gameState.totalDeaths;
      if (statTotalMeters) statTotalMeters.innerText = `${Math.floor(gameState.totalMeters)}m`;
      if (statMaxBiome) statMaxBiome.innerText = BIOMES[gameState.maxBiomeIndex]?.name || 'PLAINS';
      if (shopWallet) shopWallet.innerText = gameState.totalCoins;
    }

    // Daily Mission Generator Engine (Based on 24-hour cycle)
    function initDailyMissions() {
      const currentDateString = new Date().toDateString();
      if (gameState.missionsDateStamp !== currentDateString || !gameState.missions || gameState.missions.length === 0) {
        gameState.missionsDateStamp = currentDateString;
        
        // Pick 3 random missions
        const shuffled = [...MISSION_POOL].sort(() => 0.5 - Math.random());
        gameState.missions = shuffled.slice(0, 3).map(m => ({
          ...m,
          progress: 0,
          completed: false,
          claimed: false
        }));
      }
    }

    function trackDailyProgress(type, amt) {
      if (demoMode) return;
      let stateChanged = false;
      gameState.missions.forEach(m => {
        if (!m.completed && m.reqType === type) {
          m.progress += amt;
          if (m.progress >= m.reqVal) {
            m.progress = m.reqVal;
            m.completed = true;
            playSoundFX('mission_complete');
          }
          stateChanged = true;
        }
      });
      if (stateChanged) saveLocalData();
    }

    // Completely isolated Offline mode representation (No Firebase dependencies)
    function initCloudBackup() {
      if (cloudStatusDot) cloudStatusDot.className = "w-2.5 h-2.5 rounded-full bg-emerald-500";
      if (cloudStatusText) cloudStatusText.innerText = "Local Mode";
      if (cloudConnectionStatus) cloudConnectionStatus.innerText = "Offline Only (Cloud Removed)";
      if (cloudConnectionStatus) cloudConnectionStatus.className = "font-extrabold text-teal-400 uppercase";
      if (cloudUserId) cloudUserId.innerText = "GravityShift_LocalClient";
    }

    // ==========================================
    // 3. RETRO AUDIO CHIPTUNE SYNTHESIS ENGINE
    // ==========================================
    let audioCtx = null;
    let musicInterval = null;

    function initAudioContext() {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
    }

    function playSoundFX(type) {
      if (!gameState.soundEnabled) return;
      initAudioContext();
      if (!audioCtx) return;

      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      const now = audioCtx.currentTime;

      if (type === 'flip') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.12);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);
        osc.start(now);
        osc.stop(now + 0.14);
      } 
      else if (type === 'coin') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(987.77, now);
        osc.frequency.setValueAtTime(1318.51, now + 0.08);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      } 
      else if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(450, now);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.04);
        osc.start(now);
        osc.stop(now + 0.04);
      } 
      else if (type === 'death') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(30, now + 0.5);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      }
      else if (type === 'purchase') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); 
        osc.frequency.setValueAtTime(659.25, now + 0.08); 
        osc.frequency.setValueAtTime(783.99, now + 0.16); 
        osc.frequency.setValueAtTime(1046.50, now + 0.24); 
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      }
      else if (type === 'achievement') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(587.33, now); 
        osc.frequency.setValueAtTime(880.00, now + 0.08); 
        osc.frequency.setValueAtTime(1174.66, now + 0.16); 
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
      }
      else if (type === 'mission_complete') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(1760, now + 0.2);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      }
      else if (type === 'biome_discovery') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.6);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.65);
        osc.start(now);
        osc.stop(now + 0.65);
      }
    }

    const melodyPattern = [
      440.00, 493.88, 523.25, 587.33, 659.25, 587.33, 523.25, 493.88,
      392.00, 440.00, 493.88, 523.25, 587.33, 523.25, 493.88, 392.00
    ];
    const bassPattern = [
      110.00, 110.00, 110.00, 110.00, 98.00, 98.00, 98.00, 98.00
    ];

    let musicStep = 0;
    let bassStep = 0;

    function playMusicStep() {
      if (!gameState.musicEnabled || !audioCtx) return;
      const now = audioCtx.currentTime;
      
      let tempoFactor = challengeMode === 'fast' ? 0.7 : 1.0;
      
      if (musicStep % 2 === 0) {
        const mOsc = audioCtx.createOscillator();
        const mGain = audioCtx.createGain();
        mOsc.type = 'triangle';
        mOsc.frequency.setValueAtTime(melodyPattern[musicStep % melodyPattern.length], now);
        mOsc.connect(mGain);
        mGain.connect(audioCtx.destination);
        mGain.gain.setValueAtTime(0.03, now);
        mGain.gain.exponentialRampToValueAtTime(0.002, now + 0.15 * tempoFactor);
        mOsc.start(now);
        mOsc.stop(now + 0.15 * tempoFactor);
      }

      if (musicStep % 4 === 0) {
        const bOsc = audioCtx.createOscillator();
        const bGain = audioCtx.createGain();
        bOsc.type = 'sawtooth';
        bOsc.frequency.setValueAtTime(bassPattern[bassStep % bassPattern.length], now);
        bOsc.connect(bGain);
        bGain.connect(audioCtx.destination);
        bGain.gain.setValueAtTime(0.04, now);
        bGain.gain.exponentialRampToValueAtTime(0.002, now + 0.28 * tempoFactor);
        bOsc.start(now);
        bOsc.stop(now + 0.28 * tempoFactor);
        bassStep++;
      }
      musicStep++;
    }

    function startMusicEngine() {
      if (musicInterval) clearInterval(musicInterval);
      if (!gameState.musicEnabled) return;
      initAudioContext();
      let stepSpeed = challengeMode === 'fast' ? 120 : 180;
      musicInterval = setInterval(playMusicStep, stepSpeed);
    }

    function stopMusicEngine() {
      if (musicInterval) {
        clearInterval(musicInterval);
        musicInterval = null;
      }
    }

    // ==========================================
    // 4. COLOR TRANSITIONS & DATA ARCHITECTURE
    // ==========================================
    function parseHex(hex) {
      let c = hex.substring(1);
      if (c.length === 3) {
        c = c[0]+c[0]+c[1]+c[1]+c[2]+c[2];
      }
      const num = parseInt(c, 16);
      return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
    }

    function lerpColor(c1, c2, factor) {
      return {
        r: Math.round(c1.r + (c2.r - c1.r) * factor),
        g: Math.round(c1.g + (c2.g - c1.g) * factor),
        b: Math.round(c1.b + (c2.b - c1.b) * factor)
      };
    }

    function rgbToString(c) {
      return `rgb(${c.r}, ${c.g}, ${c.b})`;
    }

    function interpolateHex(hex1, hex2, factor) {
      return rgbToString(lerpColor(parseHex(hex1), parseHex(hex2), factor));
    }

    // Biome Definitions with Progressive Spans of 500m
    const BIOMES = [
      {
        name: "Plains", icon: "🌿",
        colorTop: "#0ea5e9", colorBottom: "#0284c7", groundColor: "#22c55e", dangerColor: "#ef4444",
        hillColor: "#16a34a", mountainColor: "#15803d",
        stars: 0, clouds: 0.7, mountains: 35, hills: 30, particle: 'none',
        treeType: 'deciduous', celestial: 'sun_normal', reward: 0
      },
      {
        name: "Forest", icon: "🌲",
        colorTop: "#14532d", colorBottom: "#052e16", groundColor: "#10b981", dangerColor: "#f97316",
        hillColor: "#0f766e", mountainColor: "#115e59",
        stars: 0, clouds: 0.4, mountains: 110, hills: 45, particle: 'ambient_fireflies',
        treeType: 'pine', celestial: 'sun_warm', reward: 25
      },
      {
        name: "Desert", icon: "🏜️",
        colorTop: "#ea580c", colorBottom: "#7c2d12", groundColor: "#eab308", dangerColor: "#dc2626",
        hillColor: "#ca8a04", mountainColor: "#a16207",
        stars: 0, clouds: 0.1, mountains: 55, hills: 75, particle: 'none',
        treeType: 'cactus', celestial: 'sun_desert', reward: 25
      },
      {
        name: "Frozen Wastes", icon: "❄️",
        colorTop: "#e0f2fe", colorBottom: "#bae6fd", groundColor: "#ffffff", dangerColor: "#6366f1",
        hillColor: "#93c5fd", mountainColor: "#60a5fa",
        stars: 0, clouds: 0.5, mountains: 130, hills: 35, particle: 'snow',
        treeType: 'snow_pine', celestial: 'sun_pale', reward: 50
      },
      {
        name: "Volcano", icon: "🌋",
        colorTop: "#1c1917", colorBottom: "#0c0a09", groundColor: "#dc2626", dangerColor: "#ea580c",
        hillColor: "#7f1d1d", mountainColor: "#451a03",
        stars: 0.2, clouds: 0.8, mountains: 150, hills: 55, particle: 'ash',
        treeType: 'burnt', celestial: 'volcano_core', reward: 50
      },
      {
        name: "Sky Islands", icon: "☁️",
        colorTop: "#0ea5e9", colorBottom: "#38bdf8", groundColor: "#f8fafc", dangerColor: "#9333ea",
        hillColor: "#cbd5e1", mountainColor: "#94a3b8",
        stars: 0, clouds: 0.9, mountains: 0, hills: 0, particle: 'islands',
        treeType: 'sky_structures', celestial: 'sun_normal', reward: 75
      },
      {
        name: "Moon", icon: "🌑",
        colorTop: "#030712", colorBottom: "#0f172a", groundColor: "#94a3b8", dangerColor: "#e2e8f0",
        hillColor: "#475569", mountainColor: "#334155",
        stars: 0.8, clouds: 0, mountains: 45, hills: 15, particle: 'none',
        treeType: 'lunar_structures', celestial: 'earth', reward: 75
      },
      {
        name: "Deep Space", icon: "🌌",
        colorTop: "#0d001a", colorBottom: "#020005", groundColor: "#3b82f6", dangerColor: "#f43f5e",
        hillColor: "#311042", mountainColor: "#1c052a",
        stars: 1.0, clouds: 0, mountains: 0, hills: 0, particle: 'cosmic',
        treeType: 'deep_space_structures', celestial: 'moon_deep', reward: 100
      },
      {
        name: "Black Hole Zone", icon: "🌀",
        colorTop: "#050014", colorBottom: "#000002", groundColor: "#a855f7", dangerColor: "#f43f5e",
        hillColor: "#1e0b36", mountainColor: "#0d021a",
        stars: 0.5, clouds: 0, mountains: 0, hills: 0, particle: 'distortion',
        treeType: 'black_hole_structures', celestial: 'blackhole', reward: 100
      },
      {
        name: "Gravity Core", icon: "🔮",
        colorTop: "#090514", colorBottom: "#030008", groundColor: "#06b6d4", dangerColor: "#f43f5e",
        hillColor: "#083344", mountainColor: "#164e63",
        stars: 0.2, clouds: 0, mountains: 0, hills: 0, particle: 'matrix',
        treeType: 'core_structures', celestial: 'core_energy', reward: 150
      }
    ];

    function getBiomeByDistance(distance) {
      const idx = Math.min(Math.floor(distance / 500), BIOMES.length - 1);
      return { index: idx, data: BIOMES[idx] };
    }

    function pseudoRandom(seed) {
      let x = Math.sin(seed) * 10000;
      return x - Math.floor(x);
    }

    // ==========================================
    // 5. BACKGROUND LAYERS & PARALLAX BUFFERS
    // ==========================================
    const staticStars = [];
    for (let i = 0; i < 60; i++) {
      staticStars.push({ x: Math.random() * VW, y: Math.random() * 400, size: 1 + Math.random() * 2 });
    }
    const staticClouds = [];
    for (let i = 0; i < 7; i++) {
      staticClouds.push({ x: Math.random() * VW, y: 60 + Math.random() * 110, r: 25 + Math.random() * 15, speed: 6 + Math.random() * 10 });
    }
    const weatherParticles = [];
    for (let i = 0; i < 50; i++) {
      weatherParticles.push({ x: Math.random() * VW, y: Math.random() * VH, vx: -60 - Math.random() * 80, vy: 40 + Math.random() * 50, size: 1.5 + Math.random() * 2, color: "#ffffff" });
    }

    // ==========================================
    // 6. ENGINE CORE DEFINITIONS
    // ==========================================
    let challengeMode = 'endless'; // endless | hardcore | fast | chaos
    let currentMissionsFinishedCount = 0; 

    let currentBiomeIndex = 0;
    let previousBiomeIndex = 0;
    let transitionTimer = 0; 
    const transitionDuration = 1.0; 

    let cameraX = 0;
    let globalDistance = 0;
    let sessionCoins = 0;
    let flipsThisRun = 0;
    let revivesRemaining = 3;
    let lastSafeY = 246;          // Last Y position considered safe for revive
    let safePositionTimer = 0;    // Interval timer for saving safe position
    let invincibilityTimer = 0;   // Countdown for post-revive invincibility (seconds)
    let reviveTextTimer = 0;      // Countdown for "REVIVED!" floating text display
    
    let shakeIntensity = 0;
    const shakeDecay = 0.92;

    // Trail particles tracking queue
    let trailParticles = [];
    // Death Explosion particles queue
    let deathParticles = [];

    // Chaos Mode Tick Tracker
    let chaosTimer = 0;

    let player = {
      x: 150,
      y: 246,
      size: 44,
      vy: 0,
      gravitySign: 1, 
      targetRotation: 0,
      currentRotation: 0,
      onGround: false
    };

    let obstacles = [];
    let coins = [];
    let lastChunkX = 0;

    // ==========================================
    // 7. MAP ENGINE PROCEDURAL GENERATION
    // ==========================================
    function resetGeneration() {
      cameraX = 0;
      globalDistance = 0;
      sessionCoins = 0;
      flipsThisRun = 0;
      chaosTimer = 0;
      
      // World Event System Resets
      currentWorldEvent = null;
      eventCooldown = 20 + Math.random() * 10;
      eventParticles = [];
      activeGravityStrength = GRAVITY_STRENGTH;
      eventAlert.classList.add('hidden');
      
      // Speed adjustments based on modes
      if (challengeMode === 'fast') {
        currentSpeed = baseSpeed * 1.6;
      } else {
        currentSpeed = baseSpeed;
      }
      
      lastChunkX = 0;
      obstacles = [];
      coins = [];
      trailParticles = [];
      deathParticles = [];

      // Reset revive tracking state
      lastSafeY = 246;
      safePositionTimer = 0;
      invincibilityTimer = 0;
      reviveTextTimer = 0;

      currentBiomeIndex = 0;
      previousBiomeIndex = 0;
      transitionTimer = 0;

      player.x = 150;
      player.y = 246;
      player.vy = 0;
      player.gravitySign = 1;
      player.currentRotation = 0;
      player.targetRotation = 0;

      generateNextChunk(true); 
      generateNextChunk();
      generateNextChunk();
    }

    function generateNextChunk(empty = false) {
      const chunkWidth = 800; 
      const startX = lastChunkX;
      lastChunkX += chunkWidth;

      if (empty) return;

      const diffLevel = Math.floor(globalDistance / 500);
      const difficultyFactor = Math.min(globalDistance / 500, 10); 
      const obstacleCount = 1 + Math.floor(Math.random() * Math.min(difficultyFactor + 1, 4));

      let lastObstacleX = 0;

      for (let i = 0; i < obstacleCount; i++) {
        const relativeX = 220 + (i * (500 / obstacleCount)) + (Math.random() * 40 - 20);
        if (relativeX < lastObstacleX + 180) continue; 
        lastObstacleX = relativeX;

        const worldX = startX + relativeX;
        
        // Additive dynamic obstacle pool scaling safely with distance milestones
        let obstacleTypes = ['floor', 'ceiling', 'tunnel', 'alternating'];
        
        if (diffLevel >= 1) {
            obstacleTypes.push('double_spike'); // Added at 500m
        }
        if (diffLevel >= 2) {
            obstacleTypes.push('moving_spike'); // Added at 1000m
            obstacleTypes.push('narrow_tunnel'); // Preserved from legacy
        }
        if (diffLevel >= 3) {
            obstacleTypes.push('rotating_hazard'); // Added at 1500m
            obstacleTypes.push('gravity_gate'); // Preserved from legacy
        }

        let selectionIndex = Math.floor(Math.random() * obstacleTypes.length);
        const type = obstacleTypes[selectionIndex];

        createObstaclePattern(worldX, type);
      }
    }

    function createObstaclePattern(worldX, type) {
      const railTop = 60;
      const railBottom = 480;
      const sHeight = 44;
      const sWidth = 40;

      if (type === 'floor') {
        obstacles.push({ x: worldX, y: railBottom, width: sWidth, height: sHeight, orientation: 'up', type: 'spike' });
        spawnCoinArc(worldX - 80, railBottom - 80, 4);
      } 
      else if (type === 'ceiling') {
        obstacles.push({ x: worldX, y: railTop, width: sWidth, height: sHeight, orientation: 'down', type: 'spike' });
        spawnCoinArc(worldX - 80, railTop + 80, 4, true);
      } 
      else if (type === 'tunnel') {
        obstacles.push({ x: worldX, y: railBottom, width: sWidth, height: sHeight, orientation: 'up', type: 'spike' });
        obstacles.push({ x: worldX, y: railTop, width: sWidth, height: sHeight, orientation: 'down', type: 'spike' });
        coins.push({ x: worldX - 40, y: 270, collected: false });
        coins.push({ x: worldX + 40, y: 270, collected: false });
      } 
      else if (type === 'double_spike') {
        // Redesigned to require a highly precise gap timing flip per instructions
        obstacles.push({ x: worldX, y: railBottom, width: sWidth, height: sHeight, orientation: 'up', type: 'spike' });
        obstacles.push({ x: worldX + 160, y: railTop, width: sWidth, height: sHeight, orientation: 'down', type: 'spike' });
        coins.push({ x: worldX + 80, y: 270, collected: false });
      }
      else if (type === 'moving_spike') {
        // Redesigned sliding dual spike platform maintaining legacy mechanics format
        obstacles.push({ 
          x: worldX, y: 270, width: sWidth, height: sHeight, type: 'moving_spike', 
          startY: 120, endY: 420, direction: 1, speed: 220 + Math.random() * 80 
        });
        coins.push({ x: worldX, y: 90, collected: false });
        coins.push({ x: worldX, y: 450, collected: false });
      }
      else if (type === 'narrow_tunnel') {
        obstacles.push({ x: worldX, y: railBottom, width: 120, height: 30, orientation: 'up', type: 'spike' });
        obstacles.push({ x: worldX, y: railTop, width: 120, height: 30, orientation: 'down', type: 'spike' });
        coins.push({ x: worldX + 60, y: 270, collected: false });
      }
      else if (type === 'gravity_gate') {
        obstacles.push({ x: worldX, y: 120, width: 25, height: 300, type: 'gravity_gate', triggered: false });
      }
      else if (type === 'rotating_hazard') {
        // Added smooth spinning hazardous gear 
        obstacles.push({ x: worldX, y: 270, radius: 45, type: 'rotating_hazard', angle: 0, rotSpeed: 3 + Math.random() * 2 });
        coins.push({ x: worldX - 70, y: 190, collected: false });
        coins.push({ x: worldX + 70, y: 350, collected: false });
      }
      else if (type === 'alternating') {
        obstacles.push({ x: worldX, y: railBottom, width: sWidth, height: sHeight, orientation: 'up', type: 'spike' });
        obstacles.push({ x: worldX + 220, y: railTop, width: sWidth, height: sHeight, orientation: 'down', type: 'spike' });
        coins.push({ x: worldX, y: railBottom - 100, collected: false });
        coins.push({ x: worldX + 110, y: 270, collected: false });
        coins.push({ x: worldX + 220, y: railTop + 100, collected: false });
      }
    }

    function spawnCoinArc(startX, apexY, count, flipped = false) {
      for (let i = 0; i < count; i++) {
        const step = i / (count - 1);
        const relativeX = i * 40;
        const relativeY = Math.sin(step * Math.PI) * (flipped ? -80 : 80);
        coins.push({ x: startX + relativeX, y: apexY - relativeY, collected: false });
      }
    }

    function cleanupEntities() {
      obstacles = obstacles.filter(o => o.x > cameraX - 150);
      coins = coins.filter(c => c.x > cameraX - 150 && !c.collected);
    }

    // ==========================================
    // WORLD EVENTS ENGINE (NEW)
    // ==========================================
    function startRandomEvent() {
      const events = BIOME_EVENTS[currentBiomeIndex];
      if (!events || events.length === 0) return;
      
      const ev = events[Math.floor(Math.random() * events.length)];
      
      currentWorldEvent = {
        type: ev.type,
        name: ev.name,
        durationLeft: 10 + Math.random() * 5
      };
      
      eventParticles = [];
      eventSubTimer = 0;
      
      if (appState === 'PLAYING') {
        triggerEventPopup(ev.name);
      }
    }

    function triggerEventPopup(name) {
      eventAlertTitle.innerText = name;
      eventAlert.classList.remove('hidden');
      eventAlert.style.opacity = '0';
      eventAlert.style.transform = 'translateY(-20px) scale(0.9)';

      requestAnimationFrame(() => {
        eventAlert.style.transition = 'all 400ms cubic-bezier(0.34, 1.56, 0.64, 1)';
        eventAlert.style.opacity = '1';
        eventAlert.style.transform = 'translateY(0) scale(1)';
      });

      setTimeout(() => {
        eventAlert.style.opacity = '0';
        eventAlert.style.transform = 'translateY(-20px) scale(0.9)';
        setTimeout(() => {
          eventAlert.classList.add('hidden');
        }, 400);
      }, 3000);
    }

    function handleEventPhysics(dt) {
      const tType = currentWorldEvent.type;
      eventSubTimer += dt;

      // Gameplay Modifications
      if (tType === 'coin_rain' && eventSubTimer > 0.4) {
        eventSubTimer = 0;
        coins.push({ x: cameraX + VW + 50 + Math.random() * 150, y: 120 + Math.random() * 240, collected: false });
      }

      if (tType === 'gravity_pulses' && eventSubTimer > 2.5) {
        eventSubTimer = 0;
        if (!demoMode) flipGravity();
      }

      if (tType === 'low_gravity') {
        activeGravityStrength = 500; 
      } else {
        activeGravityStrength = GRAVITY_STRENGTH;
      }

      // Visual Particle Tracking & Spawning
      eventParticles.forEach(p => {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (tType === 'fireflies') p.vy += Math.sin(eventSubTimer * 10 + p.x) * 5 * dt;

        // Wrapping logic for dense effects to save performance
        if (tType === 'sandstorm') {
          if (p.x < cameraX - 100) p.x = cameraX + VW + 100;
          if (p.y < 0) p.y = VH;
          if (p.y > VH) p.y = 0;
        } else if (tType === 'heavy_snow') {
          if (p.y > VH + 50) {
            p.y = -50;
            p.x = cameraX + Math.random() * VW * 1.5;
          }
        } else {
          // Normal life decay
          if (p.life !== undefined) {
            p.life -= dt;
            if (p.life <= 0) p.dead = true;
          }
        }
      });

      eventParticles = eventParticles.filter(p => !p.dead);

      // Continuous spawning bounds
      if (tType === 'fireflies' && eventParticles.length < 35) {
        eventParticles.push({x: cameraX + Math.random() * VW + VW / 2, y: 100 + Math.random() * 300, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 50, size: 2 + Math.random() * 3, life: 3 + Math.random() * 2});
      }
      if (tType === 'sandstorm' && eventParticles.length < 120) {
        eventParticles.push({x: cameraX + Math.random() * VW + 200, y: Math.random() * VH, vx: -500 - Math.random() * 400, vy: (Math.random() - 0.5) * 50, size: 2 + Math.random() * 4});
      }
      if (tType === 'heavy_snow' && eventParticles.length < 180) {
        eventParticles.push({x: cameraX + Math.random() * VW * 1.5, y: Math.random() * VH - VH, vx: -100 - Math.random() * 150, vy: 250 + Math.random() * 200, size: 3 + Math.random() * 5});
      }
      if ((tType === 'ash_storm' || tType === 'lava_sparks') && eventParticles.length < 70) {
        eventParticles.push({x: cameraX + Math.random() * VW, y: VH + 20, vx: -50 + Math.random() * 100, vy: -150 - Math.random() * 250, size: 2 + Math.random() * 5, life: 2 + Math.random() * 2});
      }
      if (tType === 'meteor_shower' && Math.random() < 0.15) {
        eventParticles.push({x: cameraX + Math.random() * VW + VW / 2, y: -50, vx: -700 - Math.random() * 500, vy: 450 + Math.random() * 350, size: 2 + Math.random() * 4, life: 2});
      }
    }

    function drawEventBackgrounds(t) {
      if (!currentWorldEvent) return;
      const tType = currentWorldEvent.type;

      if (tType === 'rainbow') {
        ctx.save();
        ctx.lineWidth = 15;
        ctx.globalAlpha = 0.35;
        const cx = VW / 2;
        const cy = VH;
        const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#a855f7'];
        colors.forEach((col, i) => {
          ctx.strokeStyle = col;
          ctx.beginPath();
          ctx.arc(cx, cy, 320 - i * 15, Math.PI, 0);
          ctx.stroke();
        });
        ctx.restore();
      }

      if (tType === 'lightning') {
        if (Math.random() < 0.05) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.fillRect(0, 0, VW, VH);
        }
      }
    }

    function drawEventForegrounds(t) {
      if (!currentWorldEvent) return;
      const tType = currentWorldEvent.type;

      ctx.save();

      if (tType === 'fog') {
        ctx.fillStyle = 'rgba(200, 215, 230, 0.4)';
        ctx.fillRect(0, 0, VW, VH);
      }
      if (tType === 'sandstorm') {
        ctx.fillStyle = 'rgba(217, 119, 6, 0.25)';
        ctx.fillRect(0, 0, VW, VH);
      }

      // Draw Particles
      eventParticles.forEach(p => {
        const px = p.x - cameraX;
        if (px < -100 || px > VW + 100) return;

        if (tType === 'fireflies') {
          ctx.fillStyle = `rgba(253, 224, 71, ${Math.min(1, p.life)})`;
          ctx.shadowColor = '#fef08a';
          ctx.shadowBlur = 8;
          ctx.beginPath(); ctx.arc(px, p.y, p.size, 0, Math.PI*2); ctx.fill();
          ctx.shadowBlur = 0;
        }
        else if (tType === 'sandstorm') {
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(px, p.y, p.size * 3, p.size);
        }
        else if (tType === 'heavy_snow') {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.beginPath(); ctx.arc(px, p.y, p.size, 0, Math.PI*2); ctx.fill();
        }
        else if (tType === 'ash_storm' || tType === 'lava_sparks') {
          ctx.fillStyle = tType === 'lava_sparks' ? '#f97316' : '#9ca3af';
          ctx.globalAlpha = Math.min(1, p.life || 1);
          ctx.fillRect(px, p.y, p.size, p.size);
        }
        else if (tType === 'meteor_shower') {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = p.size;
          ctx.beginPath();
          ctx.moveTo(px, p.y);
          ctx.lineTo(px - p.vx * 0.05, p.y - p.vy * 0.05);
          ctx.stroke();
        }
      });

      ctx.restore();
    }


    // ==========================================
    // 8. TRAIL & EXPLOSION PARTICLE ENGINE
    // ==========================================
    function createTrailParticles() {
      if (gameState.activeTrail === 'none') return;
      
      const config = TRAILS[gameState.activeTrail];
      const count = 2;
      for (let i = 0; i < count; i++) {
        trailParticles.push({
          x: player.x + player.size / 2 - currentSpeed * 0.05 * Math.random(),
          y: player.y + player.size / 2 + (Math.random() - 0.5) * player.size,
          size: 3 + Math.random() * 6,
          color: config.color,
          life: 1.0,
          decay: 1.5 + Math.random() * 1.5,
          vx: -currentSpeed * 0.2 - Math.random() * 50,
          vy: (Math.random() - 0.5) * 80
        });
      }
    }

    function triggerDeathEffect() {
      const activeSkinData = SKINS[gameState.activeSkin] || SKINS.default;
      const count = 35;
      
      if (activeSkinData.effect === 'pixel') {
        for (let i = 0; i < count; i++) {
          deathParticles.push({
            type: 'pixel',
            x: player.x + player.size / 2,
            y: player.y + player.size / 2,
            size: 4 + Math.random() * 8,
            color: activeSkinData.burstColor,
            vx: (Math.random() - 0.5) * 500,
            vy: (Math.random() - 0.5) * 500,
            life: 1.0,
            decay: 1.2 + Math.random() * 1.5
          });
        }
      }
      else if (activeSkinData.effect === 'implosion') {
        for (let i = 0; i < count; i++) {
          deathParticles.push({
            type: 'implosion',
            x: player.x + player.size / 2,
            y: player.y + player.size / 2,
            size: 2 + Math.random() * 5,
            color: activeSkinData.burstColor,
            angle: Math.random() * Math.PI * 2,
            radius: 100 + Math.random() * 80,
            speed: 250 + Math.random() * 150,
            life: 1.0,
            decay: 2.0
          });
        }
      }
      else if (activeSkinData.effect === 'burst') {
        for (let i = 0; i < count; i++) {
          deathParticles.push({
            type: 'burst',
            x: player.x + player.size / 2,
            y: player.y + player.size / 2,
            size: 3 + Math.random() * 4,
            color: activeSkinData.burstColor,
            vx: (Math.random() - 0.5) * 600,
            vy: (Math.random() - 0.5) * 600,
            life: 1.0,
            decay: 1.0 + Math.random() * 2.0,
            sparkle: true
          });
        }
      }
    }

    function updateParticles(dt) {
      // Trail updates
      for (let i = trailParticles.length - 1; i >= 0; i--) {
        const p = trailParticles[i];
        p.life -= p.decay * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (p.life <= 0) {
          trailParticles.splice(i, 1);
        }
      }

      // Death updates
      for (let i = deathParticles.length - 1; i >= 0; i--) {
        const p = deathParticles[i];
        p.life -= p.decay * dt;
        if (p.type === 'pixel' || p.type === 'burst') {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
        } else if (p.type === 'implosion') {
          p.radius -= p.speed * dt;
          if (p.radius < 2) p.radius = 2;
          p.x = player.x + player.size / 2 + Math.cos(p.angle) * p.radius;
          p.y = player.y + player.size / 2 + Math.sin(p.angle) * p.radius;
        }
        if (p.life <= 0) {
          deathParticles.splice(i, 1);
        }
      }
    }

    // ==========================================
    // 9. PHYSICS MECHANICS & DETECTOR
    // ==========================================
    function updatePhysics(dt) {
      if (dt > 0.1) dt = 0.1; 

      if (transitionTimer > 0) {
        transitionTimer -= dt;
        if (transitionTimer < 0) transitionTimer = 0;
      }

      // Base Speed computation based on active modes
      let targetSpeed = baseSpeed;
      if (challengeMode === 'fast') {
        targetSpeed = baseSpeed * 1.6;
      }
      
      currentSpeed = targetSpeed + (globalDistance * 0.05);
      if (currentSpeed > 850) currentSpeed = 850;

      if (demoMode) {
        currentSpeed = 360;
      }

      player.x += currentSpeed * dt;
      cameraX = player.x - 150; 

      // Chaos Mode Random polarity shifts
      if (challengeMode === 'chaos' && !demoMode) {
        chaosTimer += dt;
        if (chaosTimer >= 2.5 + Math.random() * 3.5) {
          chaosTimer = 0;
          flipGravity();
        }
      }

      // World Event System Hook
      if (currentWorldEvent) {
        currentWorldEvent.durationLeft -= dt;
        handleEventPhysics(dt);
        if (currentWorldEvent.durationLeft <= 0) {
          currentWorldEvent = null;
          eventCooldown = 20 + Math.random() * 10;
          eventParticles = [];
          activeGravityStrength = GRAVITY_STRENGTH;
        }
      } else {
        eventCooldown -= dt;
        if (eventCooldown <= 0) {
          startRandomEvent();
        }
      }

      // Upgrades: Obstacle Position Animations
      obstacles.forEach(o => {
        if (o.type === 'moving_spike') {
          o.y += o.speed * o.direction * dt;
          if (o.y >= o.endY) {
            o.y = o.endY;
            o.direction = -1;
          } else if (o.y <= o.startY) {
            o.y = o.startY;
            o.direction = 1;
          }
        }
        else if (o.type === 'rotating_hazard') {
          o.angle += o.rotSpeed * dt;
        }
      });

      player.vy += player.gravitySign * activeGravityStrength * dt;

      if (player.vy > TERMINAL_VELOCITY) player.vy = TERMINAL_VELOCITY;
      if (player.vy < -TERMINAL_VELOCITY) player.vy = -TERMINAL_VELOCITY;

      player.y += player.vy * dt;

      const railTop = 60;
      const railBottom = 480;

      if (player.y <= railTop) {
        player.y = railTop;
        player.vy = 0;
        player.onGround = true;
      }
      else if (player.y + player.size >= railBottom) {
        player.y = railBottom - player.size;
        player.vy = 0;
        player.onGround = true;
      } else {
        player.onGround = false;
      }

      const rotDiff = player.targetRotation - player.currentRotation;
      player.currentRotation += rotDiff * 15 * dt;

      const meters = Math.floor(player.x / 100);
      if (meters > globalDistance) {
        globalDistance = meters;
        
        if (!demoMode) {
          gameState.totalMeters += 1;
          trackDailyProgress('meters', 1);
        }
        checkBiomeTransitions();
      }

      if (demoMode) {
        runDemoAI();
      } else {
        createTrailParticles();
      }

      updateParticles(dt);

      // Save last safe Y position every 0.5s (only during live play, not while invincible)
      if (!demoMode && invincibilityTimer <= 0) {
        safePositionTimer += dt;
        if (safePositionTimer >= 0.5) {
          safePositionTimer = 0;
          lastSafeY = player.y;
        }
      }

      // Decrement post-revive invincibility timer
      if (invincibilityTimer > 0) {
        invincibilityTimer -= dt;
        if (invincibilityTimer < 0) invincibilityTimer = 0;
      }

      // Decrement REVIVED text display timer
      if (reviveTextTimer > 0) {
        reviveTextTimer -= dt;
        if (reviveTextTimer < 0) reviveTextTimer = 0;
      }

      if (cameraX + VW > lastChunkX) {
        generateNextChunk();
        cleanupEntities();
      }

      checkCollisions();
    }

    function checkCollisions() {
      const px = player.x;
      const py = player.y;
      const pSize = player.size;

      for (let i = 0; i < obstacles.length; i++) {
        const obs = obstacles[i];
        
        const marginX = 8;
        const marginY = 4;
        
        if (obs.type === 'spike') {
          const isOverlapping = (
            px + pSize - marginX > obs.x &&
            px + marginX < obs.x + obs.width
          );

          if (isOverlapping) {
            if (obs.orientation === 'up' && py + pSize > obs.y - obs.height + marginY) {
              triggerDeath();
              return;
            }
            if (obs.orientation === 'down' && py < obs.y + obs.height - marginY) {
              triggerDeath();
              return;
            }
          }
        }
        else if (obs.type === 'moving_spike') {
          // Inner bounding box overlap for dynamic sliding spike logic
          if (px + pSize - marginX > obs.x &&
              px + marginX < obs.x + obs.width &&
              py + pSize - marginY > obs.y - obs.height &&
              py + marginY < obs.y + obs.height) {
            triggerDeath();
            return;
          }
        }
        else if (obs.type === 'rotating_hazard') {
          // Circular boundary collision tracker for saw blades
          const circleX = obs.x + obs.radius; 
          const circleY = obs.y;
          const closestX = Math.max(px, Math.min(circleX, px + pSize));
          const closestY = Math.max(py, Math.min(circleY, py + pSize));
          const distance = Math.hypot(circleX - closestX, circleY - closestY);
          if (distance < obs.radius - 8) {
            triggerDeath();
            return;
          }
        }
        else if (obs.type === 'gravity_gate') {
          if (!obs.triggered &&
              px + pSize > obs.x &&
              px < obs.x + obs.width &&
              py + pSize > obs.y &&
              py < obs.y + obs.height) {
            obs.triggered = true;
            flipGravity();
          }
        }
      }

      for (let i = 0; i < coins.length; i++) {
        const coin = coins[i];
        if (coin.collected) continue;

        const dist = Math.hypot((px + pSize / 2) - coin.x, (py + pSize / 2) - coin.y);
        if (dist < (pSize / 2 + 14)) {
          coin.collected = true;
          if (!demoMode) {
            sessionCoins += 1;
            gameState.totalCoins += 1;
            playSoundFX('coin');
            trackDailyProgress('coins', 1);
          }
        }
      }
    }

    function runDemoAI() {
      for (let i = 0; i < obstacles.length; i++) {
        const obs = obstacles[i];
        if (obs.x > player.x && obs.x < player.x + 220) {
          if (obs.type === 'spike' && obs.orientation === 'up' && player.gravitySign === 1 && player.onGround) {
            flipGravity();
          } 
          else if (obs.type === 'spike' && obs.orientation === 'down' && player.gravitySign === -1 && player.onGround) {
            flipGravity();
          }
          else if (obs.type === 'moving_spike' && Math.abs(obs.y - player.y) < 140) {
            flipGravity();
          }
          else if (obs.type === 'rotating_hazard' && Math.abs(obs.y - player.y) < 140) {
            flipGravity();
          }
        }
      }
    }

    function flipGravity() {
      player.gravitySign *= -1;
      player.targetRotation += Math.PI; 
      
      if (!demoMode) {
        flipsThisRun++;
        gameState.totalFlips += 1;
        trackDailyProgress('flips', 1);
        playSoundFX('flip');
        
        if (gameState.vibrationEnabled && navigator.vibrate) {
          navigator.vibrate(15);
        }
      }
    }

    function checkBiomeTransitions() {
      const currentBiome = getBiomeByDistance(globalDistance);
      const computedIndex = currentBiome.index;
      
      if (computedIndex !== currentBiomeIndex) {
        previousBiomeIndex = currentBiomeIndex;
        currentBiomeIndex = computedIndex;
        transitionTimer = transitionDuration; 
        
        // Interrupt ongoing world events smoothly on biome swap
        if (currentWorldEvent) {
          currentWorldEvent = null;
          eventCooldown = 15;
          eventParticles = [];
          activeGravityStrength = GRAVITY_STRENGTH;
          eventAlert.classList.add('hidden');
        }

        if (!demoMode) {
          // Biome rewards system logic
          const bData = currentBiome.data;
          if (!gameState.discoveredBiomes.includes(bData.name)) {
            gameState.discoveredBiomes.push(bData.name);
            if (bData.reward > 0) {
              gameState.totalCoins += bData.reward;
              playSoundFX('biome_discovery');
              setTimeout(() => {
                showAlert(`${bData.name} Discovery!`, `Your pioneering telemetry earned a bounty of +${bData.reward} Coins!`);
              }, 1200);
            }
          }

          if (computedIndex > gameState.maxBiomeIndex) {
            gameState.maxBiomeIndex = computedIndex;
          }
          triggerNewBiomePopup(bData.name);
        }
      }
    }

    function triggerNewBiomePopup(name) {
      gameplayAlertTitle.innerText = name;
      gameplayAlert.classList.remove('hidden');
      
      gameplayAlert.style.opacity = '0';
      gameplayAlert.style.transform = 'translateY(10px) scale(0.95)';
      
      requestAnimationFrame(() => {
        gameplayAlert.style.transition = 'all 300ms cubic-bezier(0.34, 1.56, 0.64, 1)';
        gameplayAlert.style.opacity = '1';
        gameplayAlert.style.transform = 'translateY(0) scale(1)';
      });

      setTimeout(() => {
        gameplayAlert.style.transition = 'all 500ms ease';
        gameplayAlert.style.opacity = '0';
        gameplayAlert.style.transform = 'translateY(-10px) scale(0.95)';
        setTimeout(() => {
          gameplayAlert.classList.add('hidden');
        }, 500);
      }, 2000); 
    }

    function triggerDeath() {
      // Post-revive invincibility — ignore all death triggers
      if (invincibilityTimer > 0) return;

      triggerDeathEffect();
      playSoundFX('death');
      shakeIntensity = 18;

      if (gameState.vibrationEnabled && navigator.vibrate) {
        navigator.vibrate([100, 50, 100]);
      }

      if (demoMode) {
        resetGeneration();
        return;
      }

      gameState.totalDeaths += 1;
      gameState.gamesPlayed += 1;
      trackDailyProgress('runs', 1);
      
      // Achievements tracking validation on death
      checkUnlockAchievements();

      saveLocalData();

      appState = 'GAMEOVER';
      
      goDistance.innerText = `${globalDistance}m`;
      goBestScore.innerText = `${Math.floor(gameState.bestScore)}m`;
      goCoinsRun.innerText = sessionCoins;
      goCoinsTotal.innerText = gameState.totalCoins;

      if (globalDistance >= gameState.bestScore && globalDistance > 10) {
        goNewBest.classList.remove('hidden');
      } else {
        goNewBest.classList.add('hidden');
      }

      gameplayHud.classList.add('hidden');
      gameOverScreen.classList.remove('hidden');

      // Show or hide revive button based on remaining revives
      if (btnRevive) {
        if (revivesRemaining > 0) {
          btnRevive.classList.remove('hidden');
          if (goReviveCount) goReviveCount.innerText = revivesRemaining;
        } else {
          btnRevive.classList.add('hidden');
        }
      }
    }

    // ==========================================
    // REVIVE SYSTEM
    // ==========================================

    // Ad simulation — shows a 2-second "Watching Ad..." popup, then calls revivePlayer()
    function showAdThenRevive() {
      if (revivesRemaining <= 0) return;

      const adOverlay    = document.getElementById('ad-overlay');
      const adProgressBar = document.getElementById('ad-progress-bar');
      const adCountdown  = document.getElementById('ad-countdown');

      // Show overlay
      adOverlay.classList.remove('hidden');
      adOverlay.classList.add('flex');
      adProgressBar.style.width = '0%';
      if (adCountdown) adCountdown.innerText = '2';

      const DURATION = 2000; // ms
      const startTime = performance.now();

      const tick = setInterval(() => {
        const elapsed = performance.now() - startTime;
        const pct     = Math.min(100, (elapsed / DURATION) * 100);

        adProgressBar.style.width = `${pct}%`;

        // Update the skip-button countdown (2 → 1 → 0)
        if (adCountdown) {
          const secsLeft = Math.max(0, Math.ceil((DURATION - elapsed) / 1000));
          adCountdown.innerText = secsLeft;
        }

        if (elapsed >= DURATION) {
          clearInterval(tick);
          adProgressBar.style.width = '100%';

          // Small pause so the bar visibly completes before dismissal
          setTimeout(() => {
            adOverlay.classList.add('hidden');
            adOverlay.classList.remove('flex');
            adProgressBar.style.width = '0%';
            revivePlayer(); // call the existing revive — unchanged
          }, 120);
        }
      }, 30);
    }

    function revivePlayer() {
      if (revivesRemaining <= 0) return;

      playSoundFX('click');
      revivesRemaining -= 1;

      // Restore player to the last recorded safe Y; keep X, distance, and coins intact
      player.y = lastSafeY;
      player.vy = 0;
      player.gravitySign = 1;
      player.targetRotation = 0;
      player.currentRotation = 0;
      deathParticles = [];

      // Arm invincibility and REVIVED text timers
      invincibilityTimer = 2.0;
      reviveTextTimer = 2.0;

      // Resume the run
      appState = 'PLAYING';
      gameOverScreen.classList.add('hidden');
      gameplayHud.classList.remove('hidden');
      gameplayHud.classList.add('flex');

      // If no revives left, hide button for the rest of this run
      if (revivesRemaining === 0 && btnRevive) {
        btnRevive.classList.add('hidden');
      }
    }

    // ==========================================
    // 10. ACHIEVEMENTS VALIDATION ENGINE
    // ==========================================
    function checkUnlockAchievements() {
      ACHIEVEMENT_TEMPLATES.forEach(ach => {
        if (gameState.achievementsClaimed.includes(ach.id)) return;

        let meetsRequirement = false;
        if (ach.reqType === 'games' && gameState.gamesPlayed >= ach.reqVal) meetsRequirement = true;
        else if (ach.reqType === 'deaths' && gameState.totalDeaths >= ach.reqVal) meetsRequirement = true;
        else if (ach.reqType === 'bestDist' && gameState.bestScore >= ach.reqVal) meetsRequirement = true;
        else if (ach.reqType === 'coinsCollected' && (gameState.totalCoins + gameState.coinsSpent) >= ach.reqVal) meetsRequirement = true;
        else if (ach.reqType === 'skinsOwned' && gameState.unlockedSkins.length >= ach.reqVal) meetsRequirement = true;

        if (meetsRequirement) {
          gameState.achievementsClaimed.push(ach.id);
          gameState.totalCoins += ach.bounty;
          triggerAchievementToast(ach.name, ach.bounty);
          saveLocalData();
        }
      });
    }

    function triggerAchievementToast(name, bounty) {
      playSoundFX('achievement');
      document.getElementById('achievement-toast-title').innerText = name;
      document.getElementById('achievement-toast-desc').innerText = `Awarded +${bounty} Coins`;
      
      achievementToast.style.transform = 'translateX(0)';
      achievementToast.style.opacity = '1';
      
      setTimeout(() => {
        achievementToast.style.transform = 'translateX(20rem)';
        achievementToast.style.opacity = '0';
      }, 4000);
    }

    // ==========================================
    // 11. ADVANCED RENDERING PIPELINE
    // ==========================================
    function drawGame(t) {
      ctx.clearRect(0, 0, VW, VH);
      ctx.save();
      
      // Global screen shake
      if (shakeIntensity > 0.1) {
        const dx = (Math.random() - 0.5) * shakeIntensity;
        const dy = (Math.random() - 0.5) * shakeIntensity;
        ctx.translate(dx, dy);
        shakeIntensity *= shakeDecay;
      }

      // World Event visual distortions applied at base level
      if (currentWorldEvent && currentWorldEvent.type === 'distortion') {
        ctx.translate(Math.sin(t * 15) * 8, Math.cos(t * 12) * 8);
        ctx.scale(1 + Math.sin(t * 8) * 0.02, 1 + Math.cos(t * 8) * 0.02);
      }

      // Smooth color and active biome blending
      const state = getInterpolatedState();

      // Render sky gradients
      const skyGrad = ctx.createLinearGradient(0, 0, 0, VH);
      skyGrad.addColorStop(0, state.colorTop);
      skyGrad.addColorStop(1, state.colorBottom);
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, VW, VH);

      // Render atmospheric stars
      if (state.stars > 0) {
        ctx.fillStyle = `rgba(255, 255, 255, ${state.stars})`;
        for (let i = 0; i < staticStars.length; i++) {
          const star = staticStars[i];
          const sx = (star.x - cameraX * 0.02) % VW;
          const finalX = sx < 0 ? sx + VW : sx;
          ctx.fillRect(finalX, star.y, star.size, star.size);
        }
      }

      // Render cross-faded celestial suns, moons, or planets
      ctx.save();
      if (state.celestialPrev !== 'none') {
        ctx.globalAlpha = 1.0 - state.transitionFactor;
        drawCelestialBody(ctx, state.celestialPrev, t);
      }
      if (state.celestialActive !== 'none') {
        ctx.globalAlpha = state.transitionFactor;
        drawCelestialBody(ctx, state.celestialActive, t);
      }
      ctx.restore();

      // Draw active event backgrounds (Rainbows, Lightning, etc.)
      drawEventBackgrounds(t);

      // Render Parallax Mountains
      if (state.mountains > 0) {
        ctx.fillStyle = state.mountainColor;
        ctx.beginPath();
        ctx.moveTo(0, VH);
        const wavelength = 360;
        for (let x = 0; x <= VW + 30; x += 15) {
          const worldX = cameraX * 0.05 + x;
          const h1 = Math.sin(worldX / wavelength) * state.mountains;
          const h2 = Math.cos(worldX / (wavelength * 0.4)) * (state.mountains * 0.35);
          const y = 480 - Math.abs(h1 + h2);
          ctx.lineTo(x, y);
        }
        ctx.lineTo(VW, VH);
        ctx.closePath();
        ctx.fill();
      }

      // Render Parallax Hills
      if (state.hills > 0) {
        ctx.fillStyle = state.hillColor;
        ctx.beginPath();
        ctx.moveTo(0, VH);
        const wavelength = 180;
        for (let x = 0; x <= VW + 30; x += 15) {
          const worldX = cameraX * 0.18 + x;
          const h = Math.sin(worldX / wavelength) * state.hills;
          const y = 480 - Math.abs(h);
          ctx.lineTo(x, y);
        }
        ctx.lineTo(VW, VH);
        ctx.closePath();
        ctx.fill();
      }

      // Render dynamic background trees and structures
      if (state.treeType !== 'none' && (state.hills > 0 || state.treeType === 'sky_structures' || state.treeType === 'crystal' || state.treeType === 'lunar_structures' || state.treeType === 'deep_space_structures' || state.treeType === 'black_hole_structures' || state.treeType === 'core_structures')) {
        const hillScrollX = cameraX * 0.18;
        const sliceWidth = 70; 
        const startSlice = Math.floor(hillScrollX / sliceWidth);
        const endSlice = Math.ceil((hillScrollX + VW) / sliceWidth);

        for (let s = startSlice; s <= endSlice; s++) {
          const worldX = s * sliceWidth;
          const screenX = worldX - hillScrollX;

          const seed = s * 1793;
          const randChance = pseudoRandom(seed);
          const randSize = 25 + pseudoRandom(seed + 1) * 20;

          if (randChance < 0.65) {
            const wavelength = 180;
            const h = Math.sin(worldX / wavelength) * state.hills;
            const groundY = 480 - Math.abs(h);
            drawProceduralTree(ctx, screenX, groundY, randSize, state.treeType, seed, t);
          }
        }
      }

      // Render Drifting Clouds
      if (state.clouds > 0) {
        ctx.fillStyle = `rgba(255, 255, 255, ${state.clouds * 0.32})`;
        for (let i = 0; i < staticClouds.length; i++) {
          const c = staticClouds[i];
          const drift = t * c.speed;
          
          // Calculate the raw position with parallax and drift
          const wrapWidth = VW + 160;
          let cxRaw = (c.x - cameraX * 0.28 + drift) % wrapWidth;
          
          // Force proper positive modulo wrapping
          if (cxRaw < 0) cxRaw += wrapWidth;
          
          const cx = cxRaw - 80;

          ctx.beginPath();
          ctx.arc(cx, c.y, c.r, 0, Math.PI * 2);
          ctx.arc(cx + c.r * 0.6, c.y - c.r * 0.3, c.r * 0.85, 0, Math.PI * 2);
          ctx.arc(cx - c.r * 0.6, c.y - c.r * 0.2, c.r * 0.7, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Render Standard Weather Particles
      drawWeatherParticles(state.particle, t);

      // Render Active Trails
      trailParticles.forEach(p => {
        ctx.save();
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x - cameraX, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Render Active Death Burst Particles
      deathParticles.forEach(p => {
        ctx.save();
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        if (p.sparkle && Math.random() > 0.5) {
          ctx.fillStyle = "#ffffff";
        }
        ctx.beginPath();
        if (p.type === 'pixel') {
          ctx.fillRect(p.x - cameraX - p.size / 2, p.y - p.size / 2, p.size, p.size);
        } else {
          ctx.arc(p.x - cameraX, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // Render Tracks (Boundaries)
      ctx.fillStyle = state.groundColor;
      ctx.fillRect(0, 0, VW, 60);
      ctx.fillRect(0, 480, VW, 60);

      // Technical HUD Division Bars
      ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
      ctx.fillRect(0, 56, VW, 4);
      ctx.fillRect(0, 480, VW, 4);

      // Draw Coins
      for (let i = 0; i < coins.length; i++) {
        const coin = coins[i];
        if (coin.collected) continue;

        const screenX = coin.x - cameraX;
        if (screenX < -50 || screenX > VW + 50) continue;

        ctx.save();
        ctx.translate(screenX, coin.y);
        
        const scaleX = Math.abs(Math.sin(t * 6));
        ctx.scale(scaleX, 1);

        ctx.fillStyle = "#fbbf24";
        ctx.strokeStyle = "#d97706";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#f59e0b";
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      // Draw Obstacles (Improved Pool with scaling logic injected)
      for (let i = 0; i < obstacles.length; i++) {
        const obs = obstacles[i];
        const screenX = obs.x - cameraX;
        if (screenX < -120 || screenX > VW + 120) continue;

        ctx.save();

        if (obs.type === 'spike') {
          ctx.translate(screenX, obs.y);
          ctx.shadowColor = state.dangerColor;
          ctx.shadowBlur = 12;

          const gradient = ctx.createLinearGradient(0, 0, 0, obs.orientation === 'up' ? -obs.height : obs.height);
          gradient.addColorStop(0, state.dangerColor);
          gradient.addColorStop(1, "#180306");

          ctx.fillStyle = gradient;
          ctx.beginPath();
          if (obs.orientation === 'up') {
            ctx.moveTo(0, 0);
            ctx.lineTo(obs.width / 2, -obs.height);
            ctx.lineTo(obs.width, 0);
          } else {
            ctx.moveTo(0, 0);
            ctx.lineTo(obs.width / 2, obs.height);
            ctx.lineTo(obs.width, 0);
          }
          ctx.closePath();
          ctx.fill();

          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          if (obs.orientation === 'up') {
            ctx.moveTo(0, 0);
            ctx.lineTo(obs.width / 2, -obs.height);
            ctx.lineTo(obs.width, 0);
          } else {
            ctx.moveTo(0, 0);
            ctx.lineTo(obs.width / 2, obs.height);
            ctx.lineTo(obs.width, 0);
          }
          ctx.stroke();
        }
        else if (obs.type === 'moving_spike') {
          // Dynamic Floating Dual Spike Platform
          ctx.translate(screenX, obs.y);
          ctx.shadowColor = state.dangerColor;
          ctx.shadowBlur = 15;

          // Box metallic core
          ctx.fillStyle = "#1e293b";
          ctx.fillRect(0, -10, obs.width, 20);

          // Top Spike pointing upwards
          const gradientUp = ctx.createLinearGradient(0, -10, 0, -obs.height);
          gradientUp.addColorStop(0, state.dangerColor);
          gradientUp.addColorStop(1, "#180306");

          ctx.fillStyle = gradientUp;
          ctx.beginPath();
          ctx.moveTo(0, -10);
          ctx.lineTo(obs.width / 2, -obs.height);
          ctx.lineTo(obs.width, -10);
          ctx.closePath();
          ctx.fill();

          // Bottom Spike pointing downwards
          const gradientDown = ctx.createLinearGradient(0, 10, 0, obs.height);
          gradientDown.addColorStop(0, state.dangerColor);
          gradientDown.addColorStop(1, "#180306");

          ctx.fillStyle = gradientDown;
          ctx.beginPath();
          ctx.moveTo(0, 10);
          ctx.lineTo(obs.width / 2, obs.height);
          ctx.lineTo(obs.width, 10);
          ctx.closePath();
          ctx.fill();

          // Border lines
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(0, -10); ctx.lineTo(obs.width / 2, -obs.height); ctx.lineTo(obs.width, -10);
          ctx.moveTo(0, 10); ctx.lineTo(obs.width / 2, obs.height); ctx.lineTo(obs.width, 10);
          ctx.stroke();
          
          // Technical tracking glow (Movement indicator req)
          ctx.fillStyle = "rgba(255,255,255,0.7)";
          let pulse = Math.abs(Math.sin(t * 12)) * 4;
          ctx.fillRect(obs.width/2 - 2, -4 - pulse, 4, 4);
          ctx.fillRect(obs.width/2 - 2, pulse, 4, 4);
        }
        else if (obs.type === 'rotating_hazard') {
          // Smooth Rotary Circular Saw Blade mechanics
          ctx.translate(screenX + obs.radius, obs.y);
          ctx.rotate(obs.angle);
          ctx.shadowColor = state.dangerColor;
          ctx.shadowBlur = 10;

          // Inner metallic body
          ctx.fillStyle = "#334155";
          ctx.beginPath();
          ctx.arc(0, 0, obs.radius - 12, 0, Math.PI * 2);
          ctx.fill();

          // Outer sharpened blades
          ctx.fillStyle = state.dangerColor;
          for (let k = 0; k < 8; k++) {
            ctx.rotate(Math.PI / 4);
            ctx.beginPath();
            ctx.moveTo(obs.radius - 14, -6);
            ctx.lineTo(obs.radius, 0);
            ctx.lineTo(obs.radius - 14, 6);
            ctx.closePath();
            ctx.fill();
          }

          // Center rivet
          ctx.fillStyle = "#0f172a";
          ctx.beginPath();
          ctx.arc(0, 0, 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(0, 0, obs.radius - 12, 0, Math.PI * 2);
          ctx.stroke();
        }
        else if (obs.type === 'gravity_gate') {
          // Translucent polarity gate bar
          ctx.translate(screenX, obs.y);
          ctx.fillStyle = obs.triggered ? "rgba(59, 130, 246, 0.15)" : "rgba(6, 182, 212, 0.4)";
          ctx.strokeStyle = obs.triggered ? "rgba(59, 130, 246, 0.3)" : "#22d3ee";
          ctx.lineWidth = 3;
          ctx.shadowColor = "#22d3ee";
          ctx.shadowBlur = obs.triggered ? 1 : 12;

          ctx.fillRect(0, 0, obs.width, obs.height);
          ctx.strokeRect(0, 0, obs.width, obs.height);
        }

        ctx.restore();
      }

      // Draw Custom Equipped Skin Player
      if (appState === 'PLAYING' || (appState === 'MENU' && demoMode)) {
        const screenPX = player.x - cameraX;
        ctx.save();
        ctx.translate(screenPX + player.size / 2, player.y + player.size / 2);
        ctx.rotate(player.currentRotation); // Gravity flip is maintained for all characters

        const currentEquippedSkin = SKINS[gameState.activeSkin] || SKINS.default;
        const charType = gameState.activeCharacter || 'gravity_cube';
        const primaryColor = currentEquippedSkin.color;
        const burstColor = currentEquippedSkin.burstColor;
        const pSize = player.size;

        if (charType === 'gravity_cube') {
          ctx.fillStyle = primaryColor;
          ctx.shadowColor = player.gravitySign === 1 ? "#3b82f6" : "#ec4899";
          ctx.shadowBlur = 14;
          ctx.beginPath();
          ctx.roundRect(-pSize / 2, -pSize / 2, pSize, pSize, 10);
          ctx.fill();

          ctx.shadowBlur = 0; 
          ctx.fillStyle = player.gravitySign === 1 ? "#3b82f6" : "#ec4899";
          ctx.beginPath();
          ctx.roundRect(-pSize / 4, -pSize / 4, pSize / 2, pSize / 2, 4);
          ctx.fill();

          ctx.fillStyle = "#ffffff";
          ctx.fillRect(8, -8, 6, 4);
          ctx.fillRect(8, 2, 6, 4);
        } 
        else if (charType === 'robo_runner') {
          let walk = Math.sin(t * 15);
          ctx.translate(0, Math.abs(walk) * -2); // Slight bob
          
          // Back Arm
          ctx.fillStyle = "#64748b";
          ctx.save(); ctx.translate(-2, -5); ctx.rotate(-walk * 1.5); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
          
          // Back Leg
          ctx.fillStyle = "#475569";
          ctx.save(); ctx.translate(-2, 12); ctx.rotate(-walk * 1.2); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
          
          // Front Leg
          ctx.fillStyle = "#64748b";
          ctx.save(); ctx.translate(2, 12); ctx.rotate(walk * 1.2); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
          
          // Body
          ctx.fillStyle = "#94a3b8";
          ctx.fillRect(-10, -10, 20, 22);
          ctx.fillStyle = primaryColor;
          ctx.fillRect(-10, -3, 20, 10);
          
          // Head
          ctx.fillStyle = "#cbd5e1";
          ctx.fillRect(-8, -24, 20, 14); // slightly offset forward
          
          // Eyes
          ctx.fillStyle = burstColor;
          ctx.shadowColor = burstColor; ctx.shadowBlur = 8;
          ctx.fillRect(2, -20, 4, 4);
          ctx.fillRect(8, -20, 4, 4);
          ctx.shadowBlur = 0;
          
          // Antenna
          ctx.fillStyle = "#64748b";
          ctx.fillRect(0, -30, 2, 6);
          ctx.fillStyle = "#ef4444";
          ctx.beginPath(); ctx.arc(1, -31, 3, 0, Math.PI*2); ctx.fill();
          
          // Front Arm
          ctx.fillStyle = "#94a3b8";
          ctx.save(); ctx.translate(2, -5); ctx.rotate(walk * 1.5); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
        }
        else if (charType === 'explorer') {
          let walk = Math.sin(t * 18);
          ctx.translate(0, Math.abs(walk) * -2);
          
          // Backpack
          ctx.fillStyle = "#78350f";
          ctx.beginPath(); ctx.roundRect(-16, -10, 10, 20, 3); ctx.fill();
          
          // Back Arm
          ctx.fillStyle = "#d97706";
          ctx.save(); ctx.translate(-2, -5); ctx.rotate(-walk * 1.5); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
          
          // Back Leg
          ctx.fillStyle = "#451a03";
          ctx.save(); ctx.translate(-2, 12); ctx.rotate(-walk * 1.2); ctx.fillRect(-3.5, 0, 7, 12); ctx.restore();
          
          // Front Leg
          ctx.fillStyle = "#78350f";
          ctx.save(); ctx.translate(2, 12); ctx.rotate(walk * 1.2); ctx.fillRect(-3.5, 0, 7, 12); ctx.restore();
          
          // Body (Shirt)
          ctx.fillStyle = primaryColor;
          ctx.beginPath(); ctx.roundRect(-8, -10, 16, 22, 2); ctx.fill();
          
          // Belt
          ctx.fillStyle = "#451a03";
          ctx.fillRect(-8, 8, 16, 4);
          
          // Front Arm
          ctx.fillStyle = "#f59e0b";
          ctx.save(); ctx.translate(2, -5); ctx.rotate(walk * 1.5); ctx.fillRect(-3, 0, 6, 12); ctx.restore();
          
          // Head
          ctx.fillStyle = "#fcd34d";
          ctx.beginPath(); ctx.arc(2, -15, 8, 0, Math.PI*2); ctx.fill();
          
          // Hat
          ctx.fillStyle = burstColor;
          ctx.beginPath(); ctx.ellipse(2, -19, 14, 3, 0, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(2, -20, 7, 0, Math.PI, true); ctx.fill();
        }
        else if (charType === 'astronaut') {
          let float = Math.sin(t * 6) * 3;
          let legW = Math.sin(t * 5) * 0.4;
          ctx.translate(0, float);
          
          // Jetpack
          ctx.fillStyle = "#cbd5e1";
          ctx.beginPath(); ctx.roundRect(-20, -12, 12, 24, 4); ctx.fill();
          
          // Jetpack Flame
          ctx.fillStyle = "#38bdf8";
          ctx.beginPath(); ctx.moveTo(-18, 12); ctx.lineTo(-10, 12); ctx.lineTo(-14, 22 + Math.random()*8); ctx.fill();
          
          // Back Leg & Boot
          ctx.save(); ctx.translate(0, 12); ctx.rotate(-legW); 
          ctx.fillStyle = "#e2e8f0"; ctx.fillRect(-6, 0, 8, 10); 
          ctx.fillStyle = "#64748b"; ctx.fillRect(-7, 8, 10, 6); 
          ctx.restore();
          
          // Front Leg & Boot
          ctx.save(); ctx.translate(0, 12); ctx.rotate(legW); 
          ctx.fillStyle = "#f8fafc"; ctx.fillRect(2, 0, 8, 10); 
          ctx.fillStyle = "#94a3b8"; ctx.fillRect(1, 8, 10, 6); 
          ctx.restore();
          
          // Body Suit
          ctx.fillStyle = "#f1f5f9";
          ctx.beginPath(); ctx.roundRect(-12, -10, 24, 24, 8); ctx.fill();
          
          // Suit Accents
          ctx.fillStyle = primaryColor;
          ctx.fillRect(-6, -4, 12, 4);
          ctx.fillRect(-6, 2, 12, 2);
          
          // Arms
          ctx.save(); ctx.translate(0, -4); ctx.rotate(-legW * 1.5);
          ctx.fillStyle = "#f8fafc"; ctx.beginPath(); ctx.roundRect(-4, 0, 8, 14, 3); ctx.fill();
          ctx.fillStyle = primaryColor; ctx.fillRect(-4, 10, 8, 4); // gloves
          ctx.restore();
          
          // Helmet
          ctx.fillStyle = "#e2e8f0";
          ctx.beginPath(); ctx.arc(2, -14, 12, 0, Math.PI*2); ctx.fill();
          
          // Visor
          ctx.fillStyle = "#0f172a";
          ctx.beginPath(); ctx.roundRect(-2, -20, 14, 12, 4); ctx.fill();
          
          // Visor Reflection
          ctx.fillStyle = "rgba(56, 189, 248, 0.6)";
          ctx.beginPath(); ctx.roundRect(5, -18, 6, 6, 2); ctx.fill();
        }
        else if (charType === 'ninja') {
          let runFast = Math.sin(t * 30);
          ctx.translate(0, 2);
          ctx.rotate(0.25); // Forward lean
          
          // Back Arm
          ctx.fillStyle = "#020617";
          ctx.save(); ctx.translate(-2, -5); ctx.rotate(-1.2 + Math.sin(t*30)*0.2); ctx.fillRect(-3, 0, 6, 14); ctx.restore();
          
          // Back Leg
          ctx.fillStyle = "#0f172a";
          ctx.save(); ctx.translate(-2, 10); ctx.rotate(-runFast * 1.2); ctx.fillRect(-4, 0, 8, 12); ctx.restore();
          
          // Front Leg
          ctx.fillStyle = "#1e293b";
          ctx.save(); ctx.translate(2, 10); ctx.rotate(runFast * 1.2); ctx.fillRect(-4, 0, 8, 12); ctx.restore();
          
          // Body
          ctx.fillStyle = "#0f172a";
          ctx.beginPath(); ctx.roundRect(-8, -12, 16, 22, 4); ctx.fill();
          
          // Belt
          ctx.fillStyle = primaryColor;
          ctx.fillRect(-9, 2, 18, 4);
          
          // Front Arm
          ctx.fillStyle = "#1e293b";
          ctx.save(); ctx.translate(2, -5); ctx.rotate(-1.0 + Math.sin(t*30 + Math.PI)*0.2); ctx.fillRect(-3, 0, 6, 14); ctx.restore();
          
          // Head
          ctx.fillStyle = "#0f172a";
          ctx.beginPath(); ctx.arc(4, -18, 9, 0, Math.PI*2); ctx.fill();
          
          // Face slit
          ctx.fillStyle = "#fcd34d";
          ctx.fillRect(2, -22, 10, 4);
          
          // Eyes
          ctx.fillStyle = burstColor;
          ctx.fillRect(6, -21, 2, 2);
          ctx.fillRect(10, -21, 2, 2);
          
          // Headband tail
          ctx.fillStyle = primaryColor;
          ctx.beginPath();
          let tailBob = Math.sin(t*40)*4;
          ctx.moveTo(-4, -18);
          ctx.lineTo(-24, -14 + tailBob);
          ctx.lineTo(-20, -10 + tailBob);
          ctx.lineTo(-3, -15);
          ctx.fill();
        }
        else if (charType === 'gravity_bot') {
          let hover = Math.sin(t * 8) * 4;
          ctx.translate(0, hover);
          
          // Thruster flame
          ctx.fillStyle = burstColor;
          ctx.shadowColor = burstColor; ctx.shadowBlur = 15;
          ctx.beginPath();
          ctx.moveTo(-10, 10);
          ctx.lineTo(10, 10);
          ctx.lineTo(0, 25 + Math.random()*15);
          ctx.fill();
          ctx.shadowBlur = 0;
          
          // Base
          ctx.fillStyle = "#334155";
          ctx.beginPath(); ctx.ellipse(0, 10, 14, 6, 0, 0, Math.PI*2); ctx.fill();
          
          // Main Body
          ctx.fillStyle = primaryColor;
          ctx.beginPath(); ctx.roundRect(-16, -14, 32, 24, 6); ctx.fill();
          
          // Screen/Face
          ctx.fillStyle = "#0f172a";
          ctx.beginPath(); ctx.roundRect(-10, -10, 24, 14, 4); ctx.fill();
          
          // Eye (Scanning)
          let scan = Math.sin(t * 5) * 6;
          ctx.fillStyle = burstColor;
          ctx.shadowColor = burstColor; ctx.shadowBlur = 8;
          ctx.beginPath(); ctx.arc(2 + scan, -3, 4, 0, Math.PI*2); ctx.fill();
          ctx.shadowBlur = 0;
          
          // Side Panels
          ctx.fillStyle = "#94a3b8";
          ctx.fillRect(-18, -6, 4, 12);
          
          // Antenna
          ctx.fillStyle = "#64748b";
          ctx.fillRect(-2, -22, 4, 8);
          ctx.fillStyle = burstColor;
          ctx.beginPath(); ctx.arc(0, -24, 3, 0, Math.PI*2); ctx.fill();
        }
        else if (charType === 'gravity_master') {
          let aura = Math.abs(Math.sin(t * 5)) * 8;
          let bob = Math.sin(t * 4) * 5;
          ctx.translate(0, bob);
          
          // Energy Aura
          ctx.globalAlpha = 0.2 + Math.sin(t*8)*0.1;
          ctx.fillStyle = primaryColor;
          ctx.beginPath(); ctx.arc(0, 0, 26 + aura, 0, Math.PI*2); ctx.fill();
          ctx.globalAlpha = 1.0;
          
          // Cape Back
          ctx.fillStyle = "#1e1b4b";
          ctx.beginPath(); ctx.moveTo(-10, -10); ctx.lineTo(-24, 18 + Math.sin(t*10)*4); ctx.lineTo(10, 18); ctx.fill();
          
          // Body (Mystic robes)
          ctx.fillStyle = "#312e81";
          ctx.beginPath(); ctx.moveTo(-6, -15); ctx.lineTo(-12, 18); ctx.lineTo(12, 18); ctx.lineTo(6, -15); ctx.fill();
          
          // Sash/Belt
          ctx.fillStyle = primaryColor;
          ctx.fillRect(-10, 2, 20, 4);
          
          // Shoulders/Trim
          ctx.fillStyle = burstColor;
          ctx.beginPath(); ctx.ellipse(0, -12, 12, 5, 0, 0, Math.PI*2); ctx.fill();
          
          // Head
          ctx.fillStyle = "#fcd34d";
          ctx.beginPath(); ctx.arc(2, -22, 7, 0, Math.PI*2); ctx.fill();
          
          // Glowing Eyes
          ctx.fillStyle = burstColor;
          ctx.shadowColor = burstColor; ctx.shadowBlur = 8;
          ctx.fillRect(1, -24, 3, 2);
          ctx.fillRect(6, -24, 3, 2);
          
          // Floating Hands
          let handY = Math.sin(t*6)*4;
          ctx.beginPath(); ctx.arc(16, -2 + handY, 4, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(-12, -2 - handY, 4, 0, Math.PI*2); ctx.fill();
          
          // Floating Orbs
          let orbit = t * 4;
          ctx.beginPath(); ctx.arc(Math.cos(orbit)*22, Math.sin(orbit)*22, 3, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(Math.cos(orbit+Math.PI)*22, Math.sin(orbit+Math.PI)*22, 3, 0, Math.PI*2); ctx.fill();
          ctx.shadowBlur = 0;
        }

        // ── REVIVE SHIELD EFFECT ──────────────────────────────────────────
        if (invincibilityTimer > 0) {
          const fadeIn  = Math.min(1, (2.0 - invincibilityTimer) / 0.15); // quick fade-in
          const fadeOut = Math.min(1, invincibilityTimer / 0.4);           // fade out near end
          const shieldAlpha = fadeIn * fadeOut * (0.55 + Math.sin(t * 20) * 0.2);
          const shieldR     = pSize * 0.78 + Math.sin(t * 16) * 5;

          ctx.save();
          // Inner fill
          ctx.globalAlpha = shieldAlpha * 0.15;
          ctx.fillStyle   = '#22d3ee';
          ctx.beginPath();
          ctx.arc(0, 0, shieldR, 0, Math.PI * 2);
          ctx.fill();
          // Primary glowing ring
          ctx.globalAlpha  = shieldAlpha;
          ctx.strokeStyle  = '#22d3ee';
          ctx.shadowColor  = '#22d3ee';
          ctx.shadowBlur   = 22;
          ctx.lineWidth    = 3.5;
          ctx.beginPath();
          ctx.arc(0, 0, shieldR, 0, Math.PI * 2);
          ctx.stroke();
          // Outer secondary ring
          ctx.globalAlpha = shieldAlpha * 0.45;
          ctx.shadowBlur  = 8;
          ctx.lineWidth   = 1.5;
          ctx.beginPath();
          ctx.arc(0, 0, shieldR + 8, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
        // ─────────────────────────────────────────────────────────────────

        ctx.restore();
      }

      // ── REVIVED! FLOATING TEXT ────────────────────────────────────────
      if (reviveTextTimer > 0 && appState === 'PLAYING') {
        const elapsed   = 2.0 - reviveTextTimer;
        const floatY    = (player.y + player.size / 2) - 36 - elapsed * 52;
        const textAlpha = reviveTextTimer > 1.7
          ? (2.0 - reviveTextTimer) / 0.3        // fast fade-in
          : (reviveTextTimer < 0.5
              ? reviveTextTimer / 0.5            // fade-out
              : 1.0);                            // fully visible
        const screenCX  = player.x - cameraX + player.size / 2;
        ctx.save();
        ctx.globalAlpha  = textAlpha;
        ctx.font         = 'bold 13px "Press Start 2P", monospace';
        ctx.fillStyle    = '#22d3ee';
        ctx.shadowColor  = '#22d3ee';
        ctx.shadowBlur   = 18;
        ctx.textAlign    = 'center';
        ctx.fillText('REVIVED!', screenCX, floatY);
        ctx.restore();
      }
      // ─────────────────────────────────────────────────────────────────

      // Draw active event foreground particles & overlays
      drawEventForegrounds(t);

      ctx.restore();
    }

    function drawCelestialBody(ctx, type, t) {
      if (type === 'none') return;
      ctx.save();
      const celestialX = 720 - (cameraX * 0.005) % VW;
      const celestialY = 150;

      if (type === 'sun_normal') {
        const radial = ctx.createRadialGradient(celestialX, celestialY, 5, celestialX, celestialY, 60);
        radial.addColorStop(0, '#ffffff');
        radial.addColorStop(0.2, '#fef08a');
        radial.addColorStop(1, 'rgba(234, 179, 8, 0)');
        ctx.fillStyle = radial;
        ctx.beginPath();
        ctx.arc(celestialX, celestialY, 60, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(celestialX, celestialY, 22, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'sun_warm') {
        const radial = ctx.createRadialGradient(celestialX, celestialY - 20, 5, celestialX, celestialY - 20, 80);
        radial.addColorStop(0, '#fffbeb');
        radial.addColorStop(0.3, '#f97316');
        radial.addColorStop(1, 'rgba(249, 115, 22, 0)');
        ctx.fillStyle = radial;
        ctx.beginPath();
        ctx.arc(celestialX, celestialY - 20, 80, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef3c7';
        ctx.beginPath();
        ctx.arc(celestialX, celestialY - 20, 26, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'sun_desert') {
        const pulse = 100 + Math.sin(t * 3) * 8;
        const radial = ctx.createRadialGradient(celestialX - 100, celestialY, 10, celestialX - 100, celestialY, pulse);
        radial.addColorStop(0, '#fef08a');
        radial.addColorStop(0.4, '#ea580c');
        radial.addColorStop(1, 'rgba(220, 38, 38, 0)');
        ctx.fillStyle = radial;
        ctx.beginPath();
        ctx.arc(celestialX - 100, celestialY, pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(celestialX - 100, celestialY, 45, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'sun_pale') {
        const radial = ctx.createRadialGradient(celestialX, celestialY - 30, 5, celestialX, celestialY - 30, 50);
        radial.addColorStop(0, '#ffffff');
        radial.addColorStop(0.4, '#bae6fd');
        radial.addColorStop(1, 'rgba(186, 230, 253, 0)');
        ctx.fillStyle = radial;
        ctx.beginPath();
        ctx.arc(celestialX, celestialY - 30, 50, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f0f9ff';
        ctx.beginPath();
        ctx.arc(celestialX, celestialY - 30, 15, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'volcano_core') {
        const scale = 1.0 + Math.sin(t * 4) * 0.05;
        ctx.strokeStyle = '#f97316';
        ctx.lineWidth = 6;
        ctx.shadowColor = '#dc2626';
        ctx.shadowBlur = 20;
        ctx.beginPath();
        ctx.arc(celestialX - 200, celestialY, 35 * scale, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#0f172a';
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.arc(celestialX - 200, celestialY, 33, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'earth') {
        const rX = 220;
        const rY = 180;
        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.arc(rX, rY, 45, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#10b981';
        ctx.save();
        ctx.beginPath();
        ctx.arc(rX, rY, 45, 0, Math.PI * 2);
        ctx.clip();
        const offset = (t * 8) % 90;
        ctx.beginPath();
        ctx.arc(rX - 15 + offset, rY - 10, 20, 0, Math.PI * 2);
        ctx.arc(rX + offset - 45, rY + 15, 18, 0, Math.PI * 2);
        ctx.arc(rX + offset + 35, rY + 5, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.4)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(rX, rY + 5, 45, 0.2, 1.4);
        ctx.stroke();
        ctx.restore();
      }
      else if (type === 'moon_deep') {
        const mX = 700;
        const mY = 160;
        ctx.fillStyle = '#94a3b8';
        ctx.beginPath();
        ctx.arc(mX, mY, 65, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#64748b';
        ctx.beginPath();
        ctx.arc(mX - 25, mY - 20, 14, 0, Math.PI * 2);
        ctx.arc(mX + 20, mY + 25, 10, 0, Math.PI * 2);
        ctx.arc(mX + 15, mY - 30, 8, 0, Math.PI * 2);
        ctx.arc(mX - 10, mY + 35, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(mX - 27, mY - 21, 10, 0, Math.PI * 2);
        ctx.arc(mX + 19, mY + 24, 7, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'blackhole') {
        const scale = 1.0 + Math.sin(t * 6) * 0.08;
        ctx.translate(VW / 2, VH / 2);
        ctx.rotate(t * 0.5);
        ctx.strokeStyle = 'rgba(168, 85, 247, 0.4)';
        ctx.lineWidth = 14;
        ctx.beginPath();
        ctx.ellipse(0, 0, 110 * scale, 12 * scale, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.ellipse(0, 0, 85 * scale, 6 * scale, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(0, 0, 35, 0, Math.PI * 2);
        ctx.fill();
      }
      else if (type === 'core_energy') {
        ctx.translate(VW / 2, 170);
        ctx.rotate(t * 1.5);
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 2;
        ctx.strokeRect(-25, -25, 50, 50);
        ctx.rotate(-t * 3.0);
        ctx.strokeStyle = '#d946ef';
        ctx.strokeRect(-16, -16, 32, 32);
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    function drawProceduralTree(ctx, x, y, size, type, seed, t) {
      ctx.save();
      ctx.translate(x, y);
      if (type === 'deciduous') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.70) {
          // Regular Tree (70% probability)
          ctx.fillStyle = '#78350f';
          ctx.fillRect(-size * 0.12, -size * 0.35, size * 0.24, size * 0.35);
          ctx.fillStyle = '#16a34a';
          ctx.beginPath();
          ctx.arc(0, -size * 0.45, size * 0.35, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#22c55e';
          ctx.beginPath();
          ctx.arc(-size * 0.18, -size * 0.55, size * 0.25, 0, Math.PI * 2);
          ctx.arc(size * 0.18, -size * 0.55, size * 0.25, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#4ade80';
          ctx.beginPath();
          ctx.arc(0, -size * 0.7, size * 0.2, 0, Math.PI * 2);
          ctx.fill();
        } 
        else if (subTypeRand < 0.80) {
          // Small House (10% probability)
          // Base
          ctx.fillStyle = '#fef3c7'; // Cream body
          ctx.fillRect(-size * 0.4, -size * 0.6, size * 0.8, size * 0.6);
          // Roof
          ctx.fillStyle = '#b91c1c'; // Red pointed roof
          ctx.beginPath();
          ctx.moveTo(-size * 0.5, -size * 0.6);
          ctx.lineTo(size * 0.5, -size * 0.6);
          ctx.lineTo(0, -size * 1.0);
          ctx.fill();
          // Door
          ctx.fillStyle = '#78350f';
          ctx.fillRect(-size * 0.1, -size * 0.3, size * 0.2, size * 0.3);
          // Window
          ctx.fillStyle = '#bae6fd';
          ctx.fillRect(size * 0.15, -size * 0.4, size * 0.15, size * 0.15);
        }
        else if (subTypeRand < 0.90) {
          // Windmill (10% probability)
          // Base structure
          ctx.fillStyle = '#e2e8f0'; // Light slate stone
          ctx.beginPath();
          ctx.moveTo(-size * 0.25, 0);
          ctx.lineTo(size * 0.25, 0);
          ctx.lineTo(size * 0.15, -size * 1.0);
          ctx.lineTo(-size * 0.15, -size * 1.0);
          ctx.fill();
          // Roof
          ctx.fillStyle = '#78350f'; // Dark wood
          ctx.beginPath();
          ctx.moveTo(-size * 0.2, -size * 1.0);
          ctx.lineTo(size * 0.2, -size * 1.0);
          ctx.lineTo(0, -size * 1.3);
          ctx.fill();
          // Rotating Blades
          ctx.save();
          ctx.translate(0, -size * 0.9);
          ctx.rotate((t || 0) * 1.5); // Spin based on time
          for(let i=0; i<4; i++) {
             ctx.rotate(Math.PI / 2);
             // Center rod
             ctx.fillStyle = '#d97706';
             ctx.fillRect(-2, 0, 4, -size * 0.8); 
             // Canvas / Fabric attached to the blade
             ctx.fillStyle = '#fcd34d'; 
             ctx.fillRect(0, -size * 0.2, size * 0.15, -size * 0.5);
          }
          ctx.restore();
        }
        else {
          // Flower Patch (10% probability)
          const numFlowers = 3 + Math.floor(pseudoRandom(seed + 3) * 3);
          for(let i=0; i<numFlowers; i++) {
             const fx = -size * 0.4 + (pseudoRandom(seed + 4 + i) * size * 0.8);
             const fy = 0;
             const fSize = size * 0.1 + (pseudoRandom(seed + 5 + i) * size * 0.1);
             const isPink = pseudoRandom(seed + 6 + i) > 0.5;
             const endX = fx + (pseudoRandom(seed + 7 + i) - 0.5) * 10;
             const endY = fy - fSize * 2.5;
             
             // Stem
             ctx.strokeStyle = '#22c55e';
             ctx.lineWidth = 2;
             ctx.beginPath();
             ctx.moveTo(fx, fy);
             ctx.lineTo(endX, endY);
             ctx.stroke();
             
             // Flower petals
             ctx.fillStyle = isPink ? '#ec4899' : '#eab308';
             ctx.beginPath();
             ctx.arc(endX, endY, fSize, 0, Math.PI * 2);
             ctx.fill();
             
             // Flower center
             ctx.fillStyle = '#ffffff';
             ctx.beginPath();
             ctx.arc(endX, endY, fSize * 0.4, 0, Math.PI * 2);
             ctx.fill();
          }
        }
      }
      else if (type === 'pine') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.50) {
          // Regular Pine Tree (50% probability)
          ctx.fillStyle = '#451a03';
          ctx.fillRect(-size * 0.1, -size * 0.3, size * 0.2, size * 0.3);
          ctx.fillStyle = '#065f46';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.95);
          ctx.lineTo(-size * 0.35, -size * 0.55);
          ctx.lineTo(size * 0.35, -size * 0.55);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#0f766e';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.75);
          ctx.lineTo(-size * 0.45, -size * 0.35);
          ctx.lineTo(size * 0.45, -size * 0.35);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#14b8a6';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.55);
          ctx.lineTo(-size * 0.55, -size * 0.15);
          ctx.lineTo(size * 0.55, -size * 0.15);
          ctx.closePath();
          ctx.fill();
        }
        else if (subTypeRand < 0.70) {
          // Tree Stump (20% probability)
          ctx.fillStyle = '#451a03'; // Dark brown bark
          ctx.fillRect(-size * 0.15, -size * 0.15, size * 0.3, size * 0.15);
          ctx.fillStyle = '#d97706'; // Light wood rings top
          ctx.beginPath(); 
          ctx.ellipse(0, -size * 0.15, size * 0.15, size * 0.05, 0, 0, Math.PI * 2); 
          ctx.fill();
        }
        else if (subTypeRand < 0.85) {
          // Giant Mushroom (15% probability)
          const mSize = size * 1.2;
          // Stem
          ctx.fillStyle = '#fef3c7';
          ctx.fillRect(-mSize * 0.1, -mSize * 0.5, mSize * 0.2, mSize * 0.5);
          // Red Cap
          ctx.fillStyle = '#dc2626';
          ctx.beginPath();
          ctx.arc(0, -mSize * 0.5, mSize * 0.45, Math.PI, 0);
          ctx.fill();
          // White Spots
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.beginPath(); ctx.arc(-mSize * 0.2, -mSize * 0.7, mSize * 0.08, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(mSize * 0.15, -mSize * 0.65, mSize * 0.1, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(0, -mSize * 0.85, mSize * 0.06, 0, Math.PI * 2); ctx.fill();
        }
        else if (subTypeRand < 0.95) {
          // Giant Ancient Tree (10% probability)
          const ancientSize = size * 2.5;
          ctx.fillStyle = '#292524'; // Very dark trunk
          ctx.fillRect(-ancientSize * 0.15, -ancientSize * 0.8, ancientSize * 0.3, ancientSize * 0.8);
          // Thick roots base
          ctx.beginPath(); 
          ctx.moveTo(-ancientSize * 0.15, -ancientSize * 0.2); 
          ctx.lineTo(-ancientSize * 0.4, 0); 
          ctx.lineTo(-ancientSize * 0.15, 0); 
          ctx.fill();
          ctx.beginPath(); 
          ctx.moveTo(ancientSize * 0.15, -ancientSize * 0.2); 
          ctx.lineTo(ancientSize * 0.4, 0); 
          ctx.lineTo(ancientSize * 0.15, 0); 
          ctx.fill();
          // Massive dark canopy layer
          ctx.fillStyle = '#064e3b';
          ctx.beginPath(); ctx.arc(0, -ancientSize * 0.8, ancientSize * 0.5, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#065f46';
          ctx.beginPath(); ctx.arc(-ancientSize * 0.3, -ancientSize * 0.6, ancientSize * 0.4, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(ancientSize * 0.3, -ancientSize * 0.6, ancientSize * 0.4, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#047857';
          ctx.beginPath(); ctx.arc(0, -ancientSize * 1.0, ancientSize * 0.4, 0, Math.PI * 2); ctx.fill();
        }
        else {
          // Abandoned Campsite (5% probability)
          // Green Tent
          ctx.fillStyle = '#14532d'; 
          ctx.beginPath(); 
          ctx.moveTo(0, -size * 0.5); 
          ctx.lineTo(-size * 0.3, 0); 
          ctx.lineTo(size * 0.3, 0); 
          ctx.fill();
          // Tent Opening
          ctx.fillStyle = '#052e16';
          ctx.beginPath(); 
          ctx.moveTo(0, -size * 0.4); 
          ctx.lineTo(-size * 0.1, 0); 
          ctx.lineTo(size * 0.1, 0); 
          ctx.fill();
          // Campfire remains slightly offset
          const fx = size * 0.4;
          ctx.fillStyle = '#4b5563'; // Stones
          ctx.beginPath(); 
          ctx.arc(fx - 4, -2, 3, 0, Math.PI * 2); 
          ctx.arc(fx + 4, -2, 3, 0, Math.PI * 2); 
          ctx.arc(fx, -5, 3, 0, Math.PI * 2); 
          ctx.fill();
          ctx.fillStyle = '#78350f'; // Ash/Logs
          ctx.fillRect(fx - 6, -4, 12, 3);
          ctx.fillStyle = '#ea580c'; // Tiny ember
          ctx.fillRect(fx - 1, -6, 2, 2);
        }
      }
      else if (type === 'cactus') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.50) {
          // 1. Giant Cactus (50% probability)
          const cHeight = size * (1.0 + pseudoRandom(seed + 3));
          ctx.strokeStyle = '#15803d'; // Richer dark green
          ctx.lineWidth = size * 0.15;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          
          // Main trunk
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(0, -cHeight);
          ctx.stroke();
          
          // Left arm
          ctx.beginPath();
          ctx.moveTo(0, -cHeight * 0.4);
          ctx.lineTo(-size * 0.3, -cHeight * 0.4);
          ctx.lineTo(-size * 0.3, -cHeight * 0.7);
          ctx.stroke();
          
          // Right arm
          ctx.beginPath();
          ctx.moveTo(0, -cHeight * 0.6);
          ctx.lineTo(size * 0.3, -cHeight * 0.6);
          ctx.lineTo(size * 0.3, -cHeight * 0.85);
          ctx.stroke();
        }
        else if (subTypeRand < 0.80) {
          // 2. Sand Dunes (30% probability)
          // Shadow/Back Dune
          ctx.fillStyle = '#b45309'; 
          ctx.beginPath();
          ctx.ellipse(0, 0, size * 1.5, size * 0.5, 0, Math.PI, Math.PI * 2);
          ctx.fill();

          // Highlight/Front Dune
          ctx.fillStyle = '#d97706'; 
          ctx.beginPath();
          ctx.ellipse(size * 0.5, 0, size * 1.2, size * 0.4, 0, Math.PI, Math.PI * 2);
          ctx.fill();
        }
        else if (subTypeRand < 0.90) {
          // 3. Desert Ruins (10% probability)
          ctx.fillStyle = '#92400e';
          // Base Foundation
          ctx.fillRect(-size * 0.6, -size * 0.1, size * 1.2, size * 0.1);
          // Broken Pillar 1
          ctx.fillRect(-size * 0.4, -size * 0.8, size * 0.2, size * 0.7);
          // Broken Pillar 2
          ctx.fillRect(size * 0.1, -size * 0.5, size * 0.2, size * 0.4);
          // Fallen block
          ctx.fillRect(size * 0.4, -size * 0.2, size * 0.3, size * 0.2);
        }
        else if (subTypeRand < 0.95) {
          // 4. Ancient Obelisk (5% probability)
          const oHeight = size * 1.8;
          
          // Left Shadow Side
          ctx.fillStyle = '#0f172a'; 
          ctx.beginPath();
          ctx.moveTo(0, -oHeight);
          ctx.lineTo(0, 0);
          ctx.lineTo(-size * 0.2, 0);
          ctx.lineTo(-size * 0.1, -oHeight * 0.8);
          ctx.fill();
          
          // Right Highlight Side
          ctx.fillStyle = '#1e293b'; 
          ctx.beginPath();
          ctx.moveTo(0, -oHeight);
          ctx.lineTo(size * 0.1, -oHeight * 0.8);
          ctx.lineTo(size * 0.2, 0);
          ctx.lineTo(0, 0);
          ctx.fill();
          
          // Glowing Rune/Core
          ctx.fillStyle = '#38bdf8'; 
          ctx.beginPath();
          ctx.arc(0, -oHeight * 0.6, size * 0.08, 0, Math.PI*2);
          ctx.fill();
          ctx.fillRect(-size * 0.02, -oHeight * 0.7, size * 0.04, size * 0.2);
        }
        else {
          // 5. Desert Skeleton (Giant Ribcage) (5% probability)
          ctx.strokeStyle = '#e2e8f0'; // Bone white
          ctx.lineWidth = size * 0.08;
          ctx.lineCap = 'round';
          
          for (let i = 0; i < 4; i++) {
            const ribWidth = size * (0.8 - i * 0.15);
            const ribHeight = size * (0.6 - i * 0.1);
            const offset = i * size * 0.25;
            
            ctx.beginPath();
            // Draw half-ellipses sticking out of the ground
            ctx.ellipse(offset - size * 0.3, 0, ribWidth, ribHeight, 0, Math.PI, Math.PI * 2);
            ctx.stroke();
          }
        }
      }
      else if (type === 'snow_pine') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.40) {
          // 1. Frozen Rocks (40% probability)
          ctx.fillStyle = '#64748b'; // Darker stone base
          ctx.beginPath();
          ctx.moveTo(-size * 0.5, 0);
          ctx.lineTo(-size * 0.2, -size * 0.6);
          ctx.lineTo(size * 0.4, -size * 0.4);
          ctx.lineTo(size * 0.6, 0);
          ctx.fill();
          
          ctx.fillStyle = '#e0f2fe'; // Ice/Snow cap
          ctx.beginPath();
          ctx.moveTo(-size * 0.25, -size * 0.5);
          ctx.lineTo(0, -size * 0.7);
          ctx.lineTo(size * 0.35, -size * 0.45);
          ctx.lineTo(0, -size * 0.2);
          ctx.fill();
          
          ctx.fillStyle = '#bae6fd'; // Ice highlight
          ctx.beginPath();
          ctx.moveTo(-size * 0.2, -size * 0.6);
          ctx.lineTo(0, -size * 0.7);
          ctx.lineTo(-size * 0.05, -size * 0.4);
          ctx.fill();
        }
        else if (subTypeRand < 0.75) {
          // 2. Frozen Trees (35% probability)
          ctx.fillStyle = '#374151';
          ctx.fillRect(-size * 0.08, -size * 0.25, size * 0.16, size * 0.25);
          ctx.fillStyle = '#1e3a8a';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.9);
          ctx.lineTo(-size * 0.4, -size * 0.5);
          ctx.lineTo(size * 0.4, -size * 0.5);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.9);
          ctx.lineTo(-size * 0.15, -size * 0.7);
          ctx.lineTo(size * 0.15, -size * 0.7);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#1d4ed8';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.65);
          ctx.lineTo(-size * 0.5, -size * 0.15);
          ctx.lineTo(size * 0.5, -size * 0.15);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.moveTo(0, -size * 0.65);
          ctx.lineTo(-size * 0.2, -size * 0.45);
          ctx.lineTo(size * 0.2, -size * 0.45);
          ctx.closePath();
          ctx.fill();
        }
        else if (subTypeRand < 0.90) {
          // 3. Ice Mountains (15% probability)
          const mSize = size * 2.5;
          ctx.fillStyle = '#0c4a6e'; // Deep ocean blue / dark ice
          ctx.beginPath();
          ctx.moveTo(-mSize * 0.5, 0);
          ctx.lineTo(0, -mSize * 1.2);
          ctx.lineTo(mSize * 0.6, 0);
          ctx.fill();
          
          ctx.fillStyle = '#0284c7'; // Lighter blue facet
          ctx.beginPath();
          ctx.moveTo(0, -mSize * 1.2);
          ctx.lineTo(mSize * 0.6, 0);
          ctx.lineTo(mSize * 0.2, 0);
          ctx.lineTo(-mSize * 0.1, -mSize * 0.5);
          ctx.fill();

          ctx.fillStyle = '#f0f9ff'; // Snow cap
          ctx.beginPath();
          ctx.moveTo(-mSize * 0.17, -mSize * 0.8);
          ctx.lineTo(0, -mSize * 1.2);
          ctx.lineTo(mSize * 0.2, -mSize * 0.8);
          ctx.lineTo(mSize * 0.1, -mSize * 0.7);
          ctx.lineTo(0, -mSize * 0.85);
          ctx.lineTo(-mSize * 0.05, -mSize * 0.75);
          ctx.fill();
        }
        else if (subTypeRand < 0.96) {
          // 4. Frozen Ruins (6% probability)
          const rSize = size * 1.4;
          ctx.fillStyle = '#475569'; // Frozen stone
          // Base
          ctx.fillRect(-rSize * 0.6, -rSize * 0.15, rSize * 1.2, rSize * 0.15);
          // Pillars
          ctx.fillRect(-rSize * 0.4, -rSize * 0.7, rSize * 0.15, rSize * 0.55);
          ctx.fillRect(rSize * 0.2, -rSize * 0.9, rSize * 0.18, rSize * 0.75);
          // Fallen lintel
          ctx.save();
          ctx.translate(-rSize * 0.1, -rSize * 0.2);
          ctx.rotate(0.3);
          ctx.fillRect(0, 0, rSize * 0.5, rSize * 0.15);
          ctx.restore();
          
          // Snow accumulation
          ctx.fillStyle = '#e0f2fe';
          ctx.fillRect(-rSize * 0.65, -rSize * 0.2, rSize * 1.3, rSize * 0.08);
          ctx.fillRect(-rSize * 0.45, -rSize * 0.75, rSize * 0.25, rSize * 0.08);
          ctx.fillRect(rSize * 0.15, -rSize * 0.95, rSize * 0.28, rSize * 0.08);
        }
        else {
          // 5. Abandoned Shipwreck (4% probability)
          const sSize = size * 2.8;
          ctx.save();
          ctx.translate(0, sSize * 0.1); // Sink into snow
          ctx.rotate(-0.15); // Tilt
          
          // Back hull (dark)
          ctx.fillStyle = '#292524';
          ctx.beginPath();
          ctx.moveTo(-sSize * 0.7, -sSize * 0.25);
          ctx.lineTo(-sSize * 0.5, 0);
          ctx.lineTo(sSize * 0.5, 0);
          ctx.lineTo(sSize * 0.7, -sSize * 0.35);
          ctx.fill();

          // Front hull
          ctx.fillStyle = '#451a03';
          ctx.beginPath();
          ctx.moveTo(-sSize * 0.8, -sSize * 0.2);
          ctx.lineTo(-sSize * 0.6, 0);
          ctx.lineTo(sSize * 0.6, 0);
          ctx.lineTo(sSize * 0.8, -sSize * 0.4);
          ctx.lineTo(sSize * 0.75, -sSize * 0.45);
          ctx.lineTo(-sSize * 0.85, -sSize * 0.25);
          ctx.fill();

          // Broken Mast 1
          ctx.fillStyle = '#78350f';
          ctx.fillRect(-sSize * 0.2, -sSize * 0.9, sSize * 0.06, sSize * 0.8);
          ctx.save();
          ctx.translate(-sSize * 0.17, -sSize * 0.6);
          ctx.rotate(0.5);
          ctx.fillRect(-sSize * 0.2, 0, sSize * 0.4, sSize * 0.04);
          ctx.restore();

          // Broken Mast 2 (snapped)
          ctx.save();
          ctx.translate(sSize * 0.3, -sSize * 0.3);
          ctx.rotate(1.1);
          ctx.fillRect(0, -sSize * 0.5, sSize * 0.05, sSize * 0.5);
          ctx.restore();

          // Ice / Snow on ship
          ctx.fillStyle = '#f0f9ff';
          ctx.beginPath();
          ctx.moveTo(-sSize * 0.85, -sSize * 0.25);
          ctx.lineTo(-sSize * 0.4, -sSize * 0.2);
          ctx.lineTo(-sSize * 0.3, -sSize * 0.1);
          ctx.lineTo(-sSize * 0.9, -sSize * 0.1);
          ctx.fill();
          
          ctx.beginPath();
          ctx.moveTo(sSize * 0.75, -sSize * 0.45);
          ctx.lineTo(sSize * 0.3, -sSize * 0.3);
          ctx.lineTo(sSize * 0.4, -sSize * 0.15);
          ctx.lineTo(sSize * 0.8, -sSize * 0.3);
          ctx.fill();

          ctx.restore();
        }
      }
      else if (type === 'burnt') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.40) {
          // 1. Regular Burnt Tree (40%)
          ctx.strokeStyle = '#1c1917';
          ctx.lineWidth = 3;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(0, -size * 0.7);
          ctx.moveTo(0, -size * 0.35);
          ctx.lineTo(-size * 0.2, -size * 0.55);
          ctx.lineTo(-size * 0.1, -size * 0.75);
          ctx.moveTo(0, -size * 0.5);
          ctx.lineTo(size * 0.25, -size * 0.75);
          ctx.stroke();
        }
        else if (subTypeRand < 0.65) {
          // 2. Volcanic Vents (25%)
          const vSize = size * 0.8;
          ctx.fillStyle = '#ea580c'; // Lava crack
          ctx.beginPath();
          ctx.moveTo(-vSize*0.6, 0); 
          ctx.lineTo(-vSize*0.2, -vSize*0.1); 
          ctx.lineTo(0, -vSize*0.05);
          ctx.lineTo(vSize*0.3, -vSize*0.15); 
          ctx.lineTo(vSize*0.5, 0); 
          ctx.fill();
          
          ctx.fillStyle = 'rgba(100, 100, 100, 0.4)'; // Rising Smoke
          for(let i = 0; i < 3; i++) {
             let rawSy = (t * 30 + i * 20) % (vSize * 1.5);
             let sy = -vSize * 0.1 - rawSy;
             let sx = Math.sin(t * 3 + i) * 8;
             let sRadius = Math.max(2, vSize * 0.15 + rawSy * 0.1);
             ctx.beginPath(); 
             ctx.arc(sx, sy, sRadius, 0, Math.PI * 2); 
             ctx.fill();
          }
        }
        else if (subTypeRand < 0.80) {
          // 3. Broken Lava Bridge (15%)
          const bSize = size * 1.5;
          ctx.fillStyle = '#dc2626'; // Lava base
          ctx.beginPath(); 
          ctx.ellipse(0, 0, bSize*0.8, bSize*0.15, 0, 0, Math.PI*2); 
          ctx.fill();
          
          ctx.fillStyle = '#f97316'; // Lava glow
          ctx.beginPath(); 
          ctx.ellipse(0, 0, bSize*0.5, bSize*0.08, 0, 0, Math.PI*2); 
          ctx.fill();
          
          ctx.fillStyle = '#292524'; // Stone structure
          ctx.fillRect(-bSize*0.7, -bSize*0.6, bSize*0.3, bSize*0.6); // Left pillar
          ctx.beginPath(); 
          ctx.moveTo(-bSize*0.4, -bSize*0.6); 
          ctx.lineTo(-bSize*0.1, -bSize*0.4); 
          ctx.lineTo(-bSize*0.4, -bSize*0.3); 
          ctx.fill(); // Left broken arch
          
          ctx.fillRect(bSize*0.4, -bSize*0.5, bSize*0.3, bSize*0.5); // Right pillar
          ctx.beginPath(); 
          ctx.moveTo(bSize*0.4, -bSize*0.5); 
          ctx.lineTo(bSize*0.15, -bSize*0.35); 
          ctx.lineTo(bSize*0.4, -bSize*0.25); 
          ctx.fill(); // Right broken arch
        }
        else if (subTypeRand < 0.90) {
          // 4. Lava Temple (10%)
          const tSize = size * 1.5;
          ctx.fillStyle = '#1c1917'; // Dark stone
          ctx.fillRect(-tSize*0.8, -tSize*0.2, tSize*1.6, tSize*0.2);
          ctx.fillRect(-tSize*0.6, -tSize*0.4, tSize*1.2, tSize*0.2);
          ctx.fillRect(-tSize*0.4, -tSize*0.6, tSize*0.8, tSize*0.2);
          ctx.fillRect(-tSize*0.2, -tSize*0.8, tSize*0.4, tSize*0.2);
          
          ctx.fillStyle = '#ea580c'; // Lava
          ctx.fillRect(-tSize*0.1, -tSize*0.2, tSize*0.2, tSize*0.2); // Door
          ctx.fillRect(-tSize*0.05, -tSize*0.8, tSize*0.1, tSize*0.8); // Lava fall
          
          ctx.fillStyle = '#fef08a'; // Bright core
          ctx.fillRect(-tSize*0.02, -tSize*0.8, tSize*0.04, tSize*0.8);
        }
        else if (subTypeRand < 0.95) {
          // 5. Giant Volcano (5%)
          const vSize2 = size * 3.5;
          ctx.fillStyle = '#0c0a09';
          ctx.beginPath();
          ctx.moveTo(-vSize2*0.8, 0); 
          ctx.lineTo(-vSize2*0.2, -vSize2);
          ctx.lineTo(vSize2*0.2, -vSize2); 
          ctx.lineTo(vSize2*0.8, 0); 
          ctx.fill();
          
          ctx.fillStyle = '#1c1917'; // Crater
          ctx.beginPath(); 
          ctx.ellipse(0, -vSize2, vSize2*0.2, vSize2*0.05, 0, 0, Math.PI*2); 
          ctx.fill();
          
          ctx.fillStyle = '#dc2626'; // Lava flows
          ctx.beginPath(); 
          ctx.moveTo(-vSize2*0.1, -vSize2); 
          ctx.lineTo(-vSize2*0.15, -vSize2*0.6); 
          ctx.lineTo(0, -vSize2*0.4); 
          ctx.lineTo(vSize2*0.05, -vSize2*0.7); 
          ctx.fill();
          
          ctx.fillStyle = '#ea580c'; // Lava highlight
          ctx.beginPath(); 
          ctx.moveTo(-vSize2*0.05, -vSize2); 
          ctx.lineTo(-vSize2*0.08, -vSize2*0.65); 
          ctx.lineTo(-vSize2*0.02, -vSize2*0.5); 
          ctx.fill();
          
          ctx.fillStyle = 'rgba(60, 60, 60, 0.6)'; // Smoke plume
          let sWave = Math.sin(t)*15;
          ctx.beginPath(); 
          ctx.arc(sWave, -vSize2*1.2, vSize2*0.2, 0, Math.PI*2); 
          ctx.fill();
          ctx.beginPath(); 
          ctx.arc(sWave*2.5, -vSize2*1.4, vSize2*0.35, 0, Math.PI*2); 
          ctx.fill();
        }
        else {
          // 6. Ancient Titan Skull (5%)
          const sSize = size * 1.8;
          ctx.fillStyle = '#a8a29e'; // Bone
          ctx.beginPath();
          ctx.arc(0, -sSize*0.5, sSize*0.4, Math.PI, 0);
          ctx.lineTo(sSize*0.3, -sSize*0.1); 
          ctx.lineTo(sSize*0.1, 0);
          ctx.lineTo(-sSize*0.1, 0); 
          ctx.lineTo(-sSize*0.3, -sSize*0.1); 
          ctx.fill();
          
          ctx.fillStyle = '#1c1917'; // Sockets
          ctx.beginPath(); 
          ctx.ellipse(-sSize*0.15, -sSize*0.4, sSize*0.1, sSize*0.08, -0.2, 0, Math.PI*2); 
          ctx.fill();
          ctx.beginPath(); 
          ctx.ellipse(sSize*0.15, -sSize*0.4, sSize*0.1, sSize*0.08, 0.2, 0, Math.PI*2); 
          ctx.fill();
          
          ctx.beginPath(); 
          ctx.moveTo(0, -sSize*0.25); 
          ctx.lineTo(-sSize*0.05, -sSize*0.15); 
          ctx.lineTo(sSize*0.05, -sSize*0.15); 
          ctx.fill();
          
          ctx.fillStyle = '#ef4444'; // Glowing red eyes
          ctx.shadowColor = '#dc2626'; 
          ctx.shadowBlur = 8;
          ctx.beginPath(); 
          ctx.arc(-sSize*0.15, -sSize*0.4, sSize*0.03, 0, Math.PI*2); 
          ctx.fill();
          ctx.beginPath(); 
          ctx.arc(sSize*0.15, -sSize*0.4, sSize*0.03, 0, Math.PI*2); 
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }
      else if (type === 'sky_structures') {
        const subTypeRand = pseudoRandom(seed + 2);
        const floatY = -150 - pseudoRandom(seed + 10) * 200; 
        const bob = Math.sin(t * 2 + seed) * 12;
        
        ctx.translate(0, floatY + bob);

        if (subTypeRand < 0.35) {
          // 1. Hot Air Balloon (Occasionally)
          const bSize = size * 1.5;
          ctx.fillStyle = '#b45309';
          ctx.fillRect(-bSize * 0.2, bSize * 1.2, bSize * 0.4, bSize * 0.3);
          ctx.strokeStyle = '#fcd34d';
          ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.moveTo(-bSize * 0.2, bSize * 1.2); ctx.lineTo(-bSize * 0.5, bSize * 0.5); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(bSize * 0.2, bSize * 1.2); ctx.lineTo(bSize * 0.5, bSize * 0.5); ctx.stroke();
          ctx.fillStyle = '#ef4444'; 
          ctx.beginPath(); ctx.arc(0, 0, bSize, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#facc15'; 
          ctx.beginPath(); ctx.ellipse(0, 0, bSize * 0.6, bSize, 0, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#3b82f6'; 
          ctx.beginPath(); ctx.ellipse(0, 0, bSize * 0.2, bSize, 0, 0, Math.PI * 2); ctx.fill();
        }
        else if (subTypeRand < 0.65) {
          // 2. Airship (Occasionally)
          const aSize = size * 2.0;
          ctx.fillStyle = '#78350f';
          ctx.beginPath();
          ctx.moveTo(-aSize * 0.6, aSize * 0.6);
          ctx.lineTo(aSize * 0.6, aSize * 0.6);
          ctx.lineTo(aSize * 0.8, aSize * 0.4);
          ctx.lineTo(-aSize * 0.8, aSize * 0.4);
          ctx.fill();
          ctx.fillStyle = '#d97706';
          ctx.fillRect(-aSize * 0.3, aSize * 0.2, aSize * 0.6, aSize * 0.2);
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-aSize * 0.5, aSize * 0.4); ctx.lineTo(-aSize * 0.6, 0); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(aSize * 0.5, aSize * 0.4); ctx.lineTo(aSize * 0.6, 0); ctx.stroke();
          ctx.save();
          ctx.translate(-aSize * 0.8, aSize * 0.5);
          ctx.rotate(t * 8);
          ctx.fillStyle = '#94a3b8';
          ctx.fillRect(-aSize * 0.05, -aSize * 0.25, aSize * 0.1, aSize * 0.5);
          ctx.restore();
          ctx.fillStyle = '#e2e8f0';
          ctx.beginPath(); ctx.ellipse(0, -aSize * 0.1, aSize * 1.2, aSize * 0.5, 0, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath(); ctx.ellipse(0, -aSize * 0.1, aSize * 1.2, aSize * 0.2, 0, 0, Math.PI * 2); ctx.fill();
        }
        else if (subTypeRand < 0.85) {
          // 3. Giant Chains (Occasionally)
          const cSize = size * 0.8;
          ctx.strokeStyle = '#475569';
          ctx.lineWidth = cSize * 0.4;
          for(let i=0; i<8; i++) {
             ctx.beginPath();
             ctx.ellipse(0, -300 + i * cSize * 2.2, cSize * 0.5, cSize * 1.1, 0, 0, Math.PI * 2);
             ctx.stroke();
          }
        }
        else if (subTypeRand < 0.95) {
          // 4. Giant Floating Island (Rare)
          const iSize = size * 4.0;
          ctx.fillStyle = '#78350f'; 
          ctx.beginPath();
          ctx.moveTo(-iSize * 0.8, 0);
          ctx.lineTo(-iSize * 0.5, iSize * 0.6);
          ctx.lineTo(0, iSize * 0.9);
          ctx.lineTo(iSize * 0.4, iSize * 0.5);
          ctx.lineTo(iSize * 0.7, 0);
          ctx.fill();
          ctx.fillStyle = '#22c55e'; 
          ctx.beginPath();
          ctx.ellipse(0, 0, iSize * 0.85, iSize * 0.2, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#16a34a';
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(-iSize * 0.6, 0); ctx.lineTo(-iSize * 0.6, iSize * 0.4); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(iSize * 0.5, 0); ctx.lineTo(iSize * 0.5, iSize * 0.5); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(iSize * 0.1, 0); ctx.lineTo(iSize * 0.1, iSize * 0.7); ctx.stroke();
        }
        else {
          // 5. Cloud Castle (Very Rare)
          const cSize = size * 2.5;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
          ctx.beginPath(); ctx.arc(-cSize * 0.6, cSize * 0.5, cSize * 0.5, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(0, cSize * 0.6, cSize * 0.6, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(cSize * 0.6, cSize * 0.5, cSize * 0.5, 0, Math.PI * 2); ctx.fill();
          
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(-cSize * 0.5, -cSize * 0.2, cSize, cSize * 0.8);
          ctx.fillStyle = '#e2e8f0';
          ctx.fillRect(-cSize * 0.5, -cSize * 0.2, cSize * 0.5, cSize * 0.8); 
          
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(-cSize * 0.7, -cSize * 0.6, cSize * 0.3, cSize * 1.2);
          ctx.fillRect(cSize * 0.4, -cSize * 0.5, cSize * 0.3, cSize * 1.1);
          ctx.fillRect(-cSize * 0.15, -cSize * 0.8, cSize * 0.3, cSize * 1.4);
          
          ctx.fillStyle = '#38bdf8'; 
          ctx.beginPath(); ctx.moveTo(-cSize * 0.8, -cSize * 0.6); ctx.lineTo(-cSize * 0.55, -cSize * 1.0); ctx.lineTo(-cSize * 0.3, -cSize * 0.6); ctx.fill();
          ctx.beginPath(); ctx.moveTo(cSize * 0.3, -cSize * 0.5); ctx.lineTo(cSize * 0.55, -cSize * 0.9); ctx.lineTo(cSize * 0.8, -cSize * 0.5); ctx.fill();
          ctx.fillStyle = '#fbbf24'; 
          ctx.beginPath(); ctx.moveTo(-cSize * 0.25, -cSize * 0.8); ctx.lineTo(0, -cSize * 1.3); ctx.lineTo(cSize * 0.25, -cSize * 0.8); ctx.fill();
          
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(0, -cSize * 1.5, cSize * 0.3, cSize * 0.15);
          ctx.strokeStyle = '#94a3b8'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(0, -cSize * 1.5); ctx.lineTo(0, -cSize * 1.3); ctx.stroke();
        }
      }
      else if (type === 'lunar_structures') {
        const subTypeRand = pseudoRandom(seed + 2);
        
        if (subTypeRand < 0.40) {
          // 1. Lunar Rover (40% probability)
          const rSize = size * 1.2;
          ctx.fillStyle = '#e2e8f0'; // Rover body
          ctx.fillRect(-rSize * 0.4, -rSize * 0.3, rSize * 0.8, rSize * 0.2);
          ctx.fillStyle = '#94a3b8'; // Cockpit window
          ctx.fillRect(rSize * 0.1, -rSize * 0.25, rSize * 0.25, rSize * 0.15);
          
          // Wheels (6 wheels)
          ctx.fillStyle = '#1e293b';
          [ -rSize*0.3, 0, rSize*0.3 ].forEach(wx => {
            ctx.beginPath();
            ctx.arc(wx, -rSize * 0.05, rSize * 0.15, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#cbd5e1'; // Hubcap
            ctx.beginPath();
            ctx.arc(wx, -rSize * 0.05, rSize * 0.05, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#1e293b';
          });
          
          // Antenna
          ctx.strokeStyle = '#64748b';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(-rSize * 0.2, -rSize * 0.3);
          ctx.lineTo(-rSize * 0.2, -rSize * 0.6);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(-rSize * 0.2, -rSize * 0.6, rSize * 0.1, Math.PI, 0);
          ctx.stroke();
        }
        else if (subTypeRand < 0.70) {
          // 2. Crashed Rocket (30% probability)
          const rkSize = size * 2.5;
          ctx.save();
          ctx.translate(0, rkSize * 0.1); // Buried slightly in lunar dust
          ctx.rotate(0.6); // Tilted
          
          // Rocket body
          ctx.fillStyle = '#f8fafc';
          ctx.beginPath();
          ctx.moveTo(-rkSize * 0.15, 0);
          ctx.lineTo(-rkSize * 0.15, -rkSize * 0.7);
          ctx.lineTo(0, -rkSize);
          ctx.lineTo(rkSize * 0.15, -rkSize * 0.7);
          ctx.lineTo(rkSize * 0.15, 0);
          ctx.fill();
          
          // Rocket stripes
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(-rkSize * 0.15, -rkSize * 0.5, rkSize * 0.3, rkSize * 0.1);
          ctx.fillRect(-rkSize * 0.15, -rkSize * 0.3, rkSize * 0.3, rkSize * 0.05);
          
          // Fin
          ctx.beginPath();
          ctx.moveTo(rkSize * 0.15, -rkSize * 0.2);
          ctx.lineTo(rkSize * 0.35, 0);
          ctx.lineTo(rkSize * 0.15, 0);
          ctx.fill();
          
          // Thruster
          ctx.fillStyle = '#475569';
          ctx.fillRect(-rkSize * 0.1, 0, rkSize * 0.2, rkSize * 0.1);
          
          ctx.restore();
          
          // Moon dust over the crash site
          ctx.fillStyle = '#64748b';
          ctx.beginPath();
          ctx.ellipse(0, 0, rkSize * 0.6, rkSize * 0.15, 0, Math.PI, Math.PI * 2);
          ctx.fill();
        }
        else if (subTypeRand < 0.85) {
          // 3. Research Dome (15% probability)
          const dSize = size * 2.5;
          
          // Base structure
          ctx.fillStyle = '#334155';
          ctx.fillRect(-dSize * 0.6, -dSize * 0.15, dSize * 1.2, dSize * 0.15);
          ctx.fillStyle = '#475569';
          ctx.fillRect(-dSize * 0.8, -dSize * 0.05, dSize * 1.6, dSize * 0.05);
          
          // Airlock
          ctx.fillStyle = '#64748b';
          ctx.fillRect(dSize * 0.5, -dSize * 0.3, dSize * 0.3, dSize * 0.25);
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(dSize * 0.6, -dSize * 0.25, dSize * 0.1, dSize * 0.2);
          
          // Inner equipment (visible through dome)
          ctx.fillStyle = '#94a3b8';
          ctx.fillRect(-dSize * 0.3, -dSize * 0.4, dSize * 0.2, dSize * 0.25);
          ctx.fillStyle = '#facc15'; // Light source
          ctx.fillRect(-dSize * 0.25, -dSize * 0.35, dSize * 0.05, dSize * 0.05);
          
          // Glass Dome
          ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.6)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(0, -dSize * 0.15, dSize * 0.6, Math.PI, 0);
          ctx.fill();
          ctx.stroke();
          
          // Grid lines on dome
          ctx.beginPath(); ctx.arc(0, -dSize * 0.15, dSize * 0.6, Math.PI, 0); ctx.stroke();
          ctx.beginPath(); ctx.ellipse(0, -dSize * 0.15, dSize * 0.3, dSize * 0.6, 0, Math.PI, 0); ctx.stroke();
        }
        else if (subTypeRand < 0.95) {
          // 4. Communication Tower (10% probability)
          const tSize = size * 3;
          
          // Legs/Base
          ctx.strokeStyle = '#475569';
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(-tSize * 0.2, 0); ctx.lineTo(-tSize * 0.05, -tSize * 0.2); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(tSize * 0.2, 0); ctx.lineTo(tSize * 0.05, -tSize * 0.2); ctx.stroke();
          
          // Main Mast
          ctx.fillStyle = '#64748b';
          ctx.fillRect(-tSize * 0.05, -tSize, tSize * 0.1, tSize * 0.8);
          
          // Mast details/ladder
          ctx.strokeStyle = '#334155';
          ctx.lineWidth = 2;
          for (let i = 1; i < 8; i++) {
            ctx.beginPath();
            ctx.moveTo(-tSize * 0.05, -tSize + i * tSize * 0.1);
            ctx.lineTo(tSize * 0.05, -tSize + (i-1) * tSize * 0.1);
            ctx.stroke();
          }
          
          // Satellite Dishes
          ctx.fillStyle = '#94a3b8';
          ctx.beginPath(); ctx.arc(-tSize * 0.15, -tSize * 0.6, tSize * 0.15, Math.PI * 0.5, Math.PI * 1.5); ctx.fill();
          ctx.beginPath(); ctx.arc(tSize * 0.15, -tSize * 0.8, tSize * 0.1, Math.PI * 1.5, Math.PI * 0.5); ctx.fill();
          
          // Beacon light (blinking based on time)
          ctx.fillStyle = (Math.floor(t * 2) % 2 === 0) ? '#ef4444' : '#7f1d1d';
          ctx.beginPath(); ctx.arc(0, -tSize * 1.05, tSize * 0.04, 0, Math.PI*2); ctx.fill();
        }
        else {
          // 5. Satellite Wreckage (5% probability)
          const wSize = size * 1.5;
          ctx.save();
          
          // Main body crashed
          ctx.translate(-wSize * 0.2, -wSize * 0.2);
          ctx.rotate(0.4);
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(-wSize * 0.2, -wSize * 0.2, wSize * 0.4, wSize * 0.4);
          ctx.fillStyle = '#f59e0b'; // Gold foil
          ctx.fillRect(-wSize * 0.15, -wSize * 0.15, wSize * 0.3, wSize * 0.3);
          
          // Broken solar panel 1 attached
          ctx.translate(wSize * 0.2, 0);
          ctx.rotate(0.2);
          ctx.fillStyle = '#1e3a8a';
          ctx.fillRect(0, -wSize * 0.1, wSize * 0.8, wSize * 0.2);
          ctx.strokeStyle = '#60a5fa';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, -wSize * 0.1, wSize * 0.8, wSize * 0.2);
          ctx.beginPath(); ctx.moveTo(wSize * 0.4, -wSize * 0.1); ctx.lineTo(wSize * 0.4, wSize * 0.1); ctx.stroke();
          ctx.restore();
          
          // Disconnected broken solar panel
          ctx.save();
          ctx.translate(wSize * 0.8, -wSize * 0.05);
          ctx.rotate(-0.5);
          ctx.fillStyle = '#1e3a8a';
          ctx.fillRect(-wSize * 0.4, -wSize * 0.1, wSize * 0.6, wSize * 0.2);
          ctx.strokeStyle = '#60a5fa';
          ctx.strokeRect(-wSize * 0.4, -wSize * 0.1, wSize * 0.6, wSize * 0.2);
          ctx.restore();
          
          // Wires / Debris fragments
          ctx.strokeStyle = '#475569';
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(wSize * 0.3, -wSize * 0.1); ctx.stroke();
          ctx.fillStyle = '#334155';
          ctx.fillRect(wSize * 0.4, 0, wSize * 0.1, wSize * 0.1);
        }
      }
      else if (type === 'deep_space_structures') {
        const subTypeRand = pseudoRandom(seed + 2);
        const floatY = -200 - pseudoRandom(seed + 10) * 200; 
        
        ctx.translate(0, floatY);

        if (subTypeRand < 0.45) {
          // 1. Asteroid Field (45% probability)
          const numAsteroids = 3 + Math.floor(pseudoRandom(seed + 5) * 3);
          for(let i=0; i<numAsteroids; i++) {
            const aX = (pseudoRandom(seed + i) - 0.5) * size * 5;
            const aY = (pseudoRandom(seed + 20 + i) - 0.5) * size * 3;
            const aSize = size * 0.2 + pseudoRandom(seed + 30 + i) * size * 0.5;
            const rot = t * 0.3 * (pseudoRandom(seed + i) > 0.5 ? 1 : -1);
            
            ctx.save();
            ctx.translate(aX, aY);
            ctx.rotate(rot);
            ctx.fillStyle = '#475569';
            ctx.beginPath();
            for(let j=0; j<7; j++) {
              const angle = (j / 7) * Math.PI * 2;
              const dist = aSize * (0.7 + pseudoRandom(seed + i + j) * 0.3);
              if(j===0) ctx.moveTo(Math.cos(angle)*dist, Math.sin(angle)*dist);
              else ctx.lineTo(Math.cos(angle)*dist, Math.sin(angle)*dist);
            }
            ctx.closePath();
            ctx.fill();
            
            // Asteroid Crater/Highlight
            ctx.fillStyle = '#334155';
            ctx.beginPath();
            ctx.arc(-aSize*0.2, -aSize*0.2, aSize*0.25, 0, Math.PI*2);
            ctx.fill();
            ctx.restore();
          }
        }
        else if (subTypeRand < 0.70) {
          // 2. Cargo Spaceship (25% probability)
          // Slow drift effect based on time
          const driftOffset = ((t * 30 + pseudoRandom(seed) * 1000) % (VW * 2)) - VW;
          const sSize = size * 1.5;
          ctx.save();
          ctx.translate(driftOffset, Math.sin(t + seed) * 15);
          
          // Main truss
          ctx.fillStyle = '#334155';
          ctx.fillRect(-sSize * 2, -sSize * 0.1, sSize * 4, sSize * 0.2);
          
          // Engine
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(-sSize * 2.2, -sSize * 0.3, sSize * 0.4, sSize * 0.6);
          ctx.fillStyle = '#38bdf8'; // Thruster glow
          ctx.beginPath(); ctx.arc(-sSize * 2.2, 0, sSize * 0.2, Math.PI*0.5, Math.PI*1.5); ctx.fill();
          
          // Cargo Containers
          const colors = ['#eab308', '#ef4444', '#3b82f6', '#22c55e'];
          for(let i=0; i<4; i++) {
            ctx.fillStyle = colors[(Math.floor(seed*100) + i) % colors.length];
            ctx.fillRect(-sSize + i*sSize*0.7, -sSize * 0.4, sSize * 0.6, sSize * 0.8);
            ctx.fillStyle = 'rgba(0,0,0,0.2)'; // Container detail
            ctx.fillRect(-sSize + i*sSize*0.7 + sSize*0.4, -sSize * 0.4, sSize * 0.2, sSize * 0.8);
          }
          
          // Cockpit
          ctx.fillStyle = '#94a3b8';
          ctx.beginPath(); ctx.moveTo(sSize * 1.8, -sSize * 0.2); ctx.lineTo(sSize * 2.2, 0); ctx.lineTo(sSize * 1.8, sSize * 0.2); ctx.fill();
          ctx.fillStyle = '#38bdf8'; // Window
          ctx.beginPath(); ctx.moveTo(sSize * 1.9, -sSize * 0.1); ctx.lineTo(sSize * 2.1, 0); ctx.lineTo(sSize * 1.9, sSize * 0.1); ctx.fill();
          
          ctx.restore();
        }
        else if (subTypeRand < 0.90) {
          // 3. Nebula Cloud (20% probability)
          const nSize = size * 3.5;
          ctx.save();
          ctx.globalCompositeOperation = 'screen';
          const color1 = pseudoRandom(seed) > 0.5 ? 'rgba(168, 85, 247, 0.12)' : 'rgba(14, 165, 233, 0.12)';
          const color2 = pseudoRandom(seed+1) > 0.5 ? 'rgba(236, 72, 153, 0.12)' : 'rgba(16, 185, 129, 0.12)';
          
          for(let i=0; i<5; i++) {
            const nx = (pseudoRandom(seed + i*2) - 0.5) * nSize * 1.5;
            const ny = (pseudoRandom(seed + i*2 + 1) - 0.5) * nSize;
            const nr = nSize * 0.4 + pseudoRandom(seed + i*3) * nSize * 0.6;
            
            const grad = ctx.createRadialGradient(nx, ny, 0, nx, ny, nr);
            grad.addColorStop(0, i % 2 === 0 ? color1 : color2);
            grad.addColorStop(1, 'rgba(0,0,0,0)');
            
            ctx.fillStyle = grad;
            ctx.beginPath(); ctx.arc(nx, ny, nr, 0, Math.PI*2); ctx.fill();
          }
          ctx.restore();
        }
        else if (subTypeRand < 0.95) {
          // 4. Space Station (5% probability)
          const stSize = size * 2.5;
          ctx.save();
          ctx.rotate(t * 0.1); // Slow rotation
          
          // Solar panels
          ctx.fillStyle = '#1e3a8a';
          ctx.fillRect(-stSize * 1.6, -stSize * 0.25, stSize * 3.2, stSize * 0.5);
          ctx.strokeStyle = '#60a5fa';
          ctx.lineWidth = 2;
          ctx.strokeRect(-stSize * 1.6, -stSize * 0.25, stSize * 3.2, stSize * 0.5);
          // Panel grids
          for(let i=1; i<6; i++) {
              ctx.beginPath(); ctx.moveTo(-stSize * 1.6 + i * stSize * 0.53, -stSize * 0.25); ctx.lineTo(-stSize * 1.6 + i * stSize * 0.53, stSize * 0.25); ctx.stroke();
          }
          
          // Main Hub
          ctx.fillStyle = '#e2e8f0';
          ctx.beginPath(); ctx.arc(0, 0, stSize * 0.6, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#64748b';
          ctx.beginPath(); ctx.arc(0, 0, stSize * 0.4, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#0f172a';
          ctx.beginPath(); ctx.arc(0, 0, stSize * 0.2, 0, Math.PI*2); ctx.fill();
          
          // Lights
          const lightPulse = 0.5 + Math.sin(t * 4) * 0.5;
          ctx.fillStyle = `rgba(56, 189, 248, ${lightPulse})`;
          ctx.beginPath(); ctx.arc(0, -stSize * 0.8, stSize * 0.08, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(0, stSize * 0.8, stSize * 0.08, 0, Math.PI*2); ctx.fill();
          
          // Outer Ring
          ctx.strokeStyle = '#94a3b8';
          ctx.lineWidth = stSize * 0.08;
          ctx.beginPath(); ctx.arc(0, 0, stSize * 1.0, 0, Math.PI*2); ctx.stroke();
          
          ctx.restore();
        }
        else {
          // 5. Giant Planet (5% probability)
          const pSize = size * 5.5;
          const pColor1 = pseudoRandom(seed) > 0.5 ? '#7e22ce' : '#0369a1';
          const pColor2 = pseudoRandom(seed+1) > 0.5 ? '#be185d' : '#0f766e';
          const hasRing = pseudoRandom(seed+5) > 0.5;
          
          ctx.save();
          ctx.translate(0, Math.sin(t * 0.5 + seed) * 20); // Slow bobbing
          
          // Back half of the ring (drawn behind planet)
          if (hasRing) {
            ctx.save();
            ctx.rotate(0.4);
            ctx.strokeStyle = `rgba(255, 255, 255, 0.15)`;
            ctx.lineWidth = pSize * 0.15;
            ctx.beginPath(); ctx.ellipse(0, 0, pSize * 1.7, pSize * 0.35, 0, Math.PI, Math.PI*2); ctx.stroke();
            ctx.restore();
          }
          
          // Planet body
          const grad = ctx.createLinearGradient(-pSize, -pSize, pSize, pSize);
          grad.addColorStop(0, pColor1);
          grad.addColorStop(1, pColor2);
          ctx.fillStyle = grad;
          ctx.beginPath(); ctx.arc(0, 0, pSize, 0, Math.PI*2); ctx.fill();
          
          // Craters
          ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
          for(let i=0; i<7; i++) {
            const cx = (pseudoRandom(seed + i*4) - 0.5) * pSize * 1.3;
            const cy = (pseudoRandom(seed + i*4 + 1) - 0.5) * pSize * 1.3;
            const cr = pSize * 0.1 + pseudoRandom(seed + i*4 + 2) * pSize * 0.2;
            if (Math.hypot(cx, cy) < pSize - cr) {
              ctx.beginPath(); ctx.arc(cx, cy, cr, 0, Math.PI*2); ctx.fill();
              ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
              ctx.beginPath(); ctx.arc(cx - cr*0.2, cy - cr*0.2, cr*0.6, 0, Math.PI*2); ctx.fill();
              ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
            }
          }
          
          // Massive Shadow (3D effect)
          ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
          ctx.beginPath(); 
          ctx.arc(0, 0, pSize, Math.PI * 0.1, Math.PI * 1.3); 
          ctx.arc(pSize*0.3, pSize*0.3, pSize*0.9, Math.PI * 1.3, Math.PI * 0.1, true);
          ctx.fill();
          
          // Front half of the ring
          if (hasRing) {
            ctx.save();
            ctx.rotate(0.4);
            ctx.strokeStyle = `rgba(255, 255, 255, 0.35)`;
            ctx.lineWidth = pSize * 0.15;
            ctx.beginPath(); ctx.ellipse(0, 0, pSize * 1.7, pSize * 0.35, 0, 0, Math.PI); ctx.stroke();
            // Outer bright thin ring
            ctx.strokeStyle = `rgba(255, 255, 255, 0.6)`;
            ctx.lineWidth = pSize * 0.02;
            ctx.beginPath(); ctx.ellipse(0, 0, pSize * 1.77, pSize * 0.42, 0, 0, Math.PI); ctx.stroke();
            ctx.restore();
          }
          
          ctx.restore();
        }
      }
      else if (type === 'black_hole_structures') {
        const subTypeRand = pseudoRandom(seed + 2);
        const floatY = -250 - pseudoRandom(seed + 10) * 200; 
        
        ctx.translate(0, floatY);

        if (subTypeRand < 0.40) {
          // 1. Reality Shards (40% probability) - Frequently
          const sSize = size * 1.5;
          ctx.save();
          ctx.rotate(t * 0.5 * (pseudoRandom(seed)>0.5?1:-1) + pseudoRandom(seed+1)*Math.PI);
          ctx.fillStyle = 'rgba(168, 85, 247, 0.15)';
          ctx.strokeStyle = 'rgba(192, 132, 252, 0.5)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(0, -sSize);
          ctx.lineTo(sSize*(0.3+pseudoRandom(seed+2)*0.5), -sSize*0.2);
          ctx.lineTo(sSize*(0.5+pseudoRandom(seed+3)*0.4), sSize*0.6);
          ctx.lineTo(-sSize*0.2, sSize*(0.4+pseudoRandom(seed+4)*0.5));
          ctx.lineTo(-sSize*0.6, sSize*0.1);
          ctx.closePath();
          ctx.fill(); ctx.stroke();
          
          // Inner glass fracture lines
          ctx.beginPath(); 
          ctx.moveTo(-sSize*0.2, sSize*(0.4+pseudoRandom(seed+4)*0.5)); 
          ctx.lineTo(0, 0); 
          ctx.lineTo(sSize*(0.3+pseudoRandom(seed+2)*0.5), -sSize*0.2); 
          ctx.stroke();
          ctx.beginPath(); 
          ctx.moveTo(0, 0); 
          ctx.lineTo(-sSize*0.6, sSize*0.1); 
          ctx.stroke();
          ctx.restore();
        }
        else if (subTypeRand < 0.65) {
          // 2. Time Fragments (25% probability) - Occasionally
          const cSize = size * 1.2;
          ctx.save();
          ctx.rotate(pseudoRandom(seed) * Math.PI * 2 + t * 0.2 * (pseudoRandom(seed+1)>0.5?1:-1));
          
          // Broken clock face arc
          ctx.beginPath(); ctx.arc(0, 0, cSize, Math.PI * 0.3, Math.PI * 1.8);
          ctx.lineTo(0,0);
          ctx.closePath();
          ctx.fillStyle = 'rgba(226, 232, 240, 0.8)'; ctx.fill();
          ctx.strokeStyle = '#334155'; ctx.lineWidth = cSize*0.15; ctx.stroke();
          
          // Tick marks (skipping the broken missing slice)
          ctx.fillStyle = '#0f172a';
          for(let i=0; i<12; i++) {
             if (i > 2 && i < 11) {
                 ctx.save();
                 ctx.rotate((i/12)*Math.PI*2);
                 ctx.fillRect(cSize*0.65, -cSize*0.05, cSize*0.2, cSize*0.1);
                 ctx.restore();
             }
          }
          
          // Erratically moving hands
          ctx.lineCap = 'round';
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = cSize*0.06;
          ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(t * 4 + seed)*cSize*0.6, Math.sin(t * 4 + seed)*cSize*0.6); ctx.stroke(); 
          ctx.lineWidth = cSize*0.1;
          ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(-t * 1.2 + seed*2)*cSize*0.4, Math.sin(-t * 1.2 + seed*2)*cSize*0.4); ctx.stroke(); 
          
          // Center pin
          ctx.fillStyle = '#ef4444';
          ctx.beginPath(); ctx.arc(0,0, cSize*0.12, 0, Math.PI*2); ctx.fill();
          ctx.restore();
        }
        else if (subTypeRand < 0.85) {
          // 3. Lost Structures (20% probability) - Occasionally
          const lsSize = size * 1.5;
          ctx.save();
          ctx.rotate(t * 0.2 * (pseudoRandom(seed)>0.5?1:-1) + pseudoRandom(seed+1)*Math.PI*2);
          const subSub = pseudoRandom(seed + 2);
          
          if (subSub < 0.33) {
              // Broken Windmill Blade & Roof from Plains
              ctx.fillStyle = '#78350f'; ctx.beginPath(); ctx.moveTo(-lsSize*0.5, 0); ctx.lineTo(lsSize*0.5, 0); ctx.lineTo(0, -lsSize); ctx.fill();
              ctx.fillStyle = '#d97706'; ctx.fillRect(-lsSize*0.1, -lsSize*1.5, lsSize*0.2, lsSize*2.5);
              ctx.fillStyle = '#fcd34d'; ctx.fillRect(0, -lsSize*1.2, lsSize*0.4, lsSize*0.6);
          } else if (subSub < 0.66) {
              // Rover Chassis from Moon
              ctx.fillStyle = '#94a3b8'; ctx.fillRect(-lsSize*0.6, -lsSize*0.3, lsSize*1.2, lsSize*0.6);
              ctx.fillStyle = '#1e293b'; 
              ctx.beginPath(); ctx.arc(-lsSize*0.4, lsSize*0.4, lsSize*0.25, 0, Math.PI*2); ctx.fill();
              ctx.beginPath(); ctx.arc(lsSize*0.6, -lsSize*0.2, lsSize*0.25, 0, Math.PI*2); ctx.fill(); // floating detached wheel
              ctx.strokeStyle = '#ef4444'; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(-lsSize*0.2, -lsSize*0.3); ctx.lineTo(lsSize*0.2, -lsSize*0.8); ctx.stroke(); // sparky wire
          } else {
              // Temple Pillar from Volcano
              ctx.fillStyle = '#1c1917'; ctx.fillRect(-lsSize*0.3, -lsSize*1.2, lsSize*0.6, lsSize*2.4);
              ctx.fillStyle = '#ea580c'; ctx.beginPath(); ctx.moveTo(-lsSize*0.1, -lsSize); ctx.lineTo(lsSize*0.1, -lsSize*0.2); ctx.lineTo(-lsSize*0.1, lsSize*0.5); ctx.fill(); // glowing crack
              ctx.fillStyle = '#292524'; ctx.fillRect(-lsSize*0.4, -lsSize*1.2, lsSize*0.8, lsSize*0.3);
          }
          ctx.restore();
        }
        else if (subTypeRand < 0.95) {
          // 4. Destroyed Portal (10% probability) - Occasionally
          const pSize = size * 2.5;
          ctx.save();
          ctx.rotate(Math.sin(t * 0.5 + seed) * 0.2);
          
          // Outer broken stone ring
          ctx.strokeStyle = '#334155'; ctx.lineWidth = pSize*0.2;
          ctx.beginPath(); ctx.arc(0, 0, pSize, Math.PI*0.1, Math.PI*1.6); ctx.stroke();
          ctx.strokeStyle = '#0f172a'; ctx.lineWidth = pSize*0.08;
          ctx.beginPath(); ctx.arc(0, 0, pSize, Math.PI*0.1, Math.PI*1.6); ctx.stroke();
          
          // Unstable energy effects
          ctx.globalCompositeOperation = 'screen';
          const eColor1 = 'rgba(217, 70, 239, 0.4)'; // Fuchsia
          const eColor2 = 'rgba(168, 85, 247, 0.4)'; // Purple
          
          for(let i=0; i<3; i++) {
             let eWave = Math.sin(t * 4 + i * 2) * pSize * 0.2;
             ctx.fillStyle = i%2===0 ? eColor1 : eColor2;
             ctx.beginPath();
             ctx.ellipse(Math.cos(t*2+i)*pSize*0.2, Math.sin(t*3+i)*pSize*0.2, pSize*0.5 + eWave, pSize*0.3 - eWave*0.5, t + i, 0, Math.PI*2);
             ctx.fill();
          }
          ctx.restore();
        }
        else {
          // 5. Upside Down Space Station (5% probability) - Rare
          const ssSize = size * 3;
          ctx.save();
          ctx.rotate(Math.PI + Math.sin(t*0.5 + seed)*0.1); // Upside down + slight bob
          
          // Broken solar panels
          ctx.fillStyle = '#0f172a'; 
          ctx.strokeStyle = '#334155'; ctx.lineWidth = 2;
          ctx.fillRect(0, -ssSize * 0.25, ssSize * 0.6, ssSize * 0.5); ctx.strokeRect(0, -ssSize * 0.25, ssSize * 0.6, ssSize * 0.5);
          ctx.fillRect(ssSize * 0.9, -ssSize * 0.25, ssSize * 0.6, ssSize * 0.5); ctx.strokeRect(ssSize * 0.9, -ssSize * 0.25, ssSize * 0.6, ssSize * 0.5);
          ctx.fillRect(ssSize * 1.8, -ssSize * 0.25, ssSize * 0.7, ssSize * 0.5); ctx.strokeRect(ssSize * 1.8, -ssSize * 0.25, ssSize * 0.7, ssSize * 0.5);
          
          // Station Hub
          ctx.fillStyle = '#334155';
          ctx.beginPath(); ctx.arc(0, 0, ssSize * 0.8, 0, Math.PI*2); ctx.fill();
          ctx.fillStyle = '#1e293b';
          ctx.beginPath(); ctx.arc(0, 0, ssSize * 0.5, 0, Math.PI*2); ctx.fill();
          
          // Broken Outer Ring
          ctx.strokeStyle = '#475569'; ctx.lineWidth = ssSize*0.1;
          ctx.beginPath(); ctx.arc(0, 0, ssSize * 1.2, Math.PI*0.2, Math.PI*1.5); ctx.stroke();
          
          // Flickering sparks
          if (Math.sin(t*15 + seed) > 0.5) {
              ctx.fillStyle = '#38bdf8';
              ctx.beginPath(); ctx.arc(-ssSize*0.6, ssSize*0.4, ssSize*0.1, 0, Math.PI*2); ctx.fill();
          }
          ctx.restore();
        }
      }
      else if (type === 'core_structures') {
        const subTypeRand = pseudoRandom(seed + 2);
        const floatY = -200 - pseudoRandom(seed + 10) * 200; 
        
        ctx.translate(0, floatY);

        if (subTypeRand < 0.35) {
          // 1. Floating Gravity Crystals (35% probability) - Frequent
          ctx.save();
          ctx.rotate(t * 0.5 * (pseudoRandom(seed) > 0.5 ? 1 : -1) + pseudoRandom(seed+1)*Math.PI);
          const cSize = size * 1.5;
          
          // Main Crystal Body
          ctx.fillStyle = '#06b6d4'; // Cyan
          ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 10;
          ctx.beginPath(); 
          ctx.moveTo(0, -cSize); 
          ctx.lineTo(-cSize*0.3, 0); 
          ctx.lineTo(0, cSize*0.8); 
          ctx.lineTo(cSize*0.3, 0); 
          ctx.closePath();
          ctx.fill();
          
          // Outer Secondary Crystal
          ctx.fillStyle = '#d946ef'; // Magenta
          ctx.shadowColor = '#e879f9'; ctx.shadowBlur = 8;
          ctx.beginPath(); 
          ctx.moveTo(cSize*0.2, -cSize*0.4); 
          ctx.lineTo(-cSize*0.1, cSize*0.2); 
          ctx.lineTo(cSize*0.5, cSize*0.6); 
          ctx.closePath();
          ctx.fill();
          
          ctx.restore();
        }
        else if (subTypeRand < 0.70) {
          // 2. Floating Cubes (35% probability) - Frequent
          const cbSize = size * 1.2;
          ctx.save();
          // Slow multi-axis pseudo rotation
          ctx.rotate(t * 0.3 * (pseudoRandom(seed)>0.5?1:-1) + pseudoRandom(seed)*Math.PI);
          
          // Base solid shadow
          ctx.fillStyle = '#083344'; // Deep Cyan
          ctx.fillRect(-cbSize, -cbSize, cbSize*2, cbSize*2);
          // Highlight panel
          ctx.fillStyle = '#164e63';
          ctx.fillRect(-cbSize, -cbSize, cbSize*2, cbSize*0.8);
          // Outer glowing wireframe
          ctx.strokeStyle = '#22d3ee'; 
          ctx.lineWidth = Math.max(1, cbSize * 0.05);
          ctx.strokeRect(-cbSize, -cbSize, cbSize*2, cbSize*2);
          
          // Inner floating matrix core
          ctx.fillStyle = 'rgba(217, 70, 239, 0.6)'; // Magenta glow
          ctx.fillRect(-cbSize*0.4, -cbSize*0.4, cbSize*0.8, cbSize*0.8);
          
          ctx.restore();
        }
        else if (subTypeRand < 0.85) {
          // 3. Energy Rings (15% probability) - Occasionally
          const rSize = size * 2.5;
          ctx.save();
          // Complex orbital oscillation
          ctx.rotate(Math.sin(t * 0.5 + seed) * 0.8);
          
          // Outer Magenta Ring
          ctx.strokeStyle = 'rgba(217, 70, 239, 0.8)';
          ctx.lineWidth = rSize * 0.1;
          ctx.shadowColor = '#d946ef'; ctx.shadowBlur = 10;
          ctx.beginPath(); 
          ctx.ellipse(0, 0, rSize, rSize * 0.25, t * 1.2, 0, Math.PI * 2); 
          ctx.stroke();
          
          // Inner Cyan Ring
          ctx.strokeStyle = 'rgba(34, 211, 238, 0.9)'; 
          ctx.lineWidth = rSize * 0.05;
          ctx.beginPath(); 
          ctx.ellipse(0, 0, rSize * 0.7, rSize * 0.7, -t * 0.8, 0, Math.PI * 2); 
          ctx.stroke();
          
          // Center Void Particle
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath(); ctx.arc(0, 0, rSize * 0.08, 0, Math.PI*2); ctx.fill();
          
          ctx.restore();
        }
        else if (subTypeRand < 0.95) {
          // 4. Reality Fractures (10% probability) - Rare
          const fSize = size * 3;
          ctx.save();
          // Static, slowly pulsing reality tear
          const pulse = 0.5 + Math.sin(t * 8 + seed) * 0.5;
          
          ctx.strokeStyle = `rgba(244, 63, 94, ${0.4 + pulse*0.6})`; // Crimson pulse
          ctx.lineWidth = fSize * 0.08;
          ctx.lineJoin = 'round';
          ctx.lineCap = 'round';
          
          // Jagged dimensional crack
          ctx.beginPath();
          ctx.moveTo(-fSize*0.5, -fSize*0.8);
          ctx.lineTo(-fSize*0.1, -fSize*0.2);
          ctx.lineTo(fSize*0.2, -fSize*0.4);
          ctx.lineTo(fSize*0.5, 0);
          ctx.lineTo(fSize*0.3, fSize*0.4);
          ctx.lineTo(fSize*0.7, fSize*0.7);
          ctx.stroke();
          
          // Inner hot energy core
          ctx.strokeStyle = '#ffffff'; 
          ctx.lineWidth = fSize * 0.02;
          ctx.stroke();
          
          ctx.restore();
        }
        else {
          // 5. Giant Gravity Core (5% probability) - Very Rare
          const gcSize = size * 4;
          ctx.save();
          // Intense bobbing in space
          ctx.translate(0, Math.sin(t * 2 + seed) * 30);
          
          // Outer energy atmosphere
          const grad = ctx.createRadialGradient(0, 0, gcSize*0.3, 0, 0, gcSize);
          grad.addColorStop(0, 'rgba(217, 70, 239, 0.8)'); // Magenta
          grad.addColorStop(0.5, 'rgba(6, 182, 212, 0.3)'); // Cyan
          grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath(); ctx.arc(0, 0, gcSize, 0, Math.PI*2); ctx.fill();
          
          // Inner intense dense core
          ctx.fillStyle = '#06b6d4';
          ctx.shadowColor = '#ffffff'; ctx.shadowBlur = 20;
          ctx.beginPath(); ctx.arc(0, 0, gcSize*0.35, 0, Math.PI*2); ctx.fill();
          
          // Expanding gravity pulse rings
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.lineWidth = gcSize * 0.03;
          let pulse1 = (t * 1.5) % 1;
          let pulse2 = (t * 1.5 + 0.5) % 1;
          
          ctx.beginPath(); ctx.arc(0, 0, gcSize * 0.35 + gcSize * 0.6 * pulse1, 0, Math.PI*2); ctx.stroke();
          ctx.globalAlpha = 1 - pulse2;
          ctx.beginPath(); ctx.arc(0, 0, gcSize * 0.35 + gcSize * 0.6 * pulse2, 0, Math.PI*2); ctx.stroke();
          
          ctx.restore();
        }
      }
      else if (type === 'crystal') {
        ctx.fillStyle = '#06b6d4';
        ctx.shadowColor = '#06b6d4';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(0, -size * 0.9);
        ctx.lineTo(-size * 0.25, -size * 0.4);
        ctx.lineTo(0, -size * 0.1);
        ctx.lineTo(size * 0.25, -size * 0.4);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#d946ef';
        ctx.shadowColor = '#d946ef';
        ctx.beginPath();
        ctx.moveTo(size * 0.2, -size * 0.5);
        ctx.lineTo(size * 0.4, -size * 0.2);
        ctx.lineTo(size * 0.1, 0);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }

    // ==========================================
    // 12. SHOP ITEMS RENDERING LOGIC
    // ==========================================
    let currentShopTab = 'characters';

    function renderShop() {
      const grid = document.getElementById('shop-items-grid');
      grid.innerHTML = "";

      if (currentShopTab === 'characters') {
        Object.keys(CHARACTERS).forEach(key => {
          const char = CHARACTERS[key];
          const isUnlocked = gameState.unlockedCharacters.includes(key);
          const isActive = gameState.activeCharacter === key;

          const card = document.createElement('div');
          card.className = `bg-slate-900 border ${isActive ? 'border-blue-500' : 'border-slate-800'} p-3 rounded-xl flex flex-col justify-between text-center space-y-2.5`;
          
          let iconName = 'box';
          if(key === 'robo_runner') iconName = 'bot';
          if(key === 'explorer') iconName = 'compass';
          if(key === 'astronaut') iconName = 'rocket';
          if(key === 'ninja') iconName = 'swords';
          if(key === 'gravity_bot') iconName = 'cpu';
          if(key === 'gravity_master') iconName = 'zap';

          card.innerHTML = `
            <div class="flex flex-col items-center">
              <div class="w-12 h-12 rounded-lg mb-2 shadow-lg flex items-center justify-center border border-slate-700/50 bg-slate-800">
                <i data-lucide="${iconName}" class="w-6 h-6 text-blue-400"></i>
              </div>
              <span class="text-xs font-bold block">${char.name}</span>
              <span class="text-[8px] text-gray-400 mt-1 h-6 line-clamp-2">${char.desc}</span>
            </div>
            <div class="mt-auto">
              ${isActive 
                ? `<span class="text-[10px] uppercase font-black text-blue-400 tracking-wider">Equipped</span>`
                : isUnlocked
                  ? `<button onclick="equipCharacter('${key}')" class="w-full py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-wider mt-1">Equip</button>`
                  : `<button onclick="buyCharacter('${key}')" class="w-full py-1 bg-yellow-600 hover:bg-yellow-500 rounded-lg text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1 mt-1">
                      <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.7-1H9V7a1 1 0 00-2 0v2H6.5a1 1 0 100 2H7v2H5.5a1 1 0 100 2H7v1a1 1 0 102 0v-1h3.3a1 1 0 100-2H9v-2h3.3a1 1 0 100-2z" /></svg>
                      <span>${char.cost}</span>
                    </button>`
              }
            </div>
          `;
          grid.appendChild(card);
        });
      } 
      else if (currentShopTab === 'skins') {
        Object.keys(SKINS).forEach(key => {
          const skin = SKINS[key];
          const isUnlocked = gameState.unlockedSkins.includes(key);
          const isActive = gameState.activeSkin === key;

          const card = document.createElement('div');
          card.className = `bg-slate-900 border ${isActive ? 'border-blue-500' : 'border-slate-800'} p-3 rounded-xl flex flex-col justify-between text-center space-y-2.5`;
          
          card.innerHTML = `
            <div class="flex flex-col items-center">
              <div class="w-12 h-12 rounded-lg mb-2 shadow-lg flex items-center justify-center border border-slate-700/50" style="background-color: ${skin.color}">
                <div class="w-4 h-4 bg-slate-950/40 rounded"></div>
              </div>
              <span class="text-xs font-bold block">${skin.name}</span>
            </div>
            <div>
              ${isActive 
                ? `<span class="text-[10px] uppercase font-black text-blue-400 tracking-wider">Equipped</span>`
                : isUnlocked
                  ? `<button onclick="equipSkin('${key}')" class="w-full py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-wider">Equip</button>`
                  : `<button onclick="buySkin('${key}')" class="w-full py-1 bg-yellow-600 hover:bg-yellow-500 rounded-lg text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1">
                      <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.7-1H9V7a1 1 0 00-2 0v2H6.5a1 1 0 100 2H7v2H5.5a1 1 0 100 2H7v1a1 1 0 102 0v-1h3.3a1 1 0 100-2H9v-2h3.3a1 1 0 100-2z" /></svg>
                      <span>${skin.cost}</span>
                    </button>`
              }
            </div>
          `;
          grid.appendChild(card);
        });
      } else {
        Object.keys(TRAILS).forEach(key => {
          const trail = TRAILS[key];
          const isUnlocked = gameState.unlockedTrails.includes(key);
          const isActive = gameState.activeTrail === key;

          const card = document.createElement('div');
          card.className = `bg-slate-900 border ${isActive ? 'border-blue-500' : 'border-slate-800'} p-3 rounded-xl flex flex-col justify-between text-center space-y-2.5`;
          
          card.innerHTML = `
            <div class="flex flex-col items-center">
              <div class="w-12 h-12 rounded-lg mb-2 shadow-lg flex items-center justify-center border border-slate-700/50" style="background-image: radial-gradient(circle, ${trail.color} 10%, transparent 80%)">
                <i data-lucide="sparkles" class="w-5 h-5" style="color: ${trail.color === 'transparent' ? '#64748b' : trail.color}"></i>
              </div>
              <span class="text-xs font-bold block">${trail.name}</span>
            </div>
            <div>
              ${isActive 
                ? `<span class="text-[10px] uppercase font-black text-blue-400 tracking-wider">Equipped</span>`
                : isUnlocked
                  ? `<button onclick="equipTrail('${key}')" class="w-full py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-wider">Equip</button>`
                  : `<button onclick="buyTrail('${key}')" class="w-full py-1 bg-yellow-600 hover:bg-yellow-500 rounded-lg text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1">
                      <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.7-1H9V7a1 1 0 00-2 0v2H6.5a1 1 0 100 2H7v2H5.5a1 1 0 100 2H7v1a1 1 0 102 0v-1h3.3a1 1 0 100-2H9v-2h3.3a1 1 0 100-2z" /></svg>
                      <span>${trail.cost}</span>
                    </button>`
              }
            </div>
          `;
          grid.appendChild(card);
        });
      }
      try { lucide.createIcons(); } catch(e) {}
    }

    function buyCharacter(key) {
      const char = CHARACTERS[key];
      if (gameState.totalCoins >= char.cost) {
        gameState.totalCoins -= char.cost;
        gameState.coinsSpent += char.cost;
        gameState.unlockedCharacters.push(key);
        playSoundFX('purchase');
        
        showAlert("CHARACTER UNLOCKED!", char.name);
        
        checkUnlockAchievements();
        saveLocalData();
        renderShop();
      } else {
        showAlert("Access Denied", "Insufficient coin balance. Clear more vector grids to earn resources.");
      }
    }

    function equipCharacter(key) {
      playSoundFX('click');
      gameState.activeCharacter = key;
      saveLocalData();
      renderShop();
    }

    function buySkin(key) {
      const skin = SKINS[key];
      if (gameState.totalCoins >= skin.cost) {
        gameState.totalCoins -= skin.cost;
        gameState.coinsSpent += skin.cost;
        gameState.unlockedSkins.push(key);
        playSoundFX('purchase');
        
        checkUnlockAchievements();
        saveLocalData();
        renderShop();
      } else {
        showAlert("Access Denied", "Insufficient coin balance. Clear more vector grids to earn resources.");
      }
    }

    function equipSkin(key) {
      playSoundFX('click');
      gameState.activeSkin = key;
      saveLocalData();
      renderShop();
    }

    function buyTrail(key) {
      const trail = TRAILS[key];
      if (gameState.totalCoins >= trail.cost) {
        gameState.totalCoins -= trail.cost;
        gameState.coinsSpent += trail.cost;
        gameState.unlockedTrails.push(key);
        playSoundFX('purchase');
        saveLocalData();
        renderShop();
      } else {
        showAlert("Access Denied", "Insufficient coin balance.");
      }
    }

    function equipTrail(key) {
      playSoundFX('click');
      gameState.activeTrail = key;
      saveLocalData();
      renderShop();
    }

    // ==========================================
    // 13. MISSIONS & ACHIEVEMENT WINDOW RENDERING
    // ==========================================
    function renderQuests() {
      // 1. Render Daily Quests
      const dailiesContainer = document.getElementById('daily-missions-list');
      dailiesContainer.innerHTML = "";
      
      gameState.missions.forEach(m => {
        const percent = Math.min(100, Math.floor((m.progress / m.reqVal) * 100));
        const card = document.createElement('div');
        card.className = "bg-slate-950/60 border border-slate-800/80 p-2.5 rounded-lg flex justify-between items-center space-x-2";
        
        card.innerHTML = `
          <div class="flex-1 min-w-0">
            <p class="text-xs font-bold text-white truncate">${m.text}</p>
            <div class="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div class="bg-cyan-500 h-full rounded-full transition-all" style="width: ${percent}%"></div>
            </div>
            <span class="text-[9px] text-gray-400 font-mono mt-1 block">${m.progress}/${m.reqVal} (${percent}%)</span>
          </div>
          <div>
            ${m.claimed 
              ? `<span class="text-[9px] text-emerald-400 font-bold uppercase tracking-wider">Claimed</span>`
              : m.completed
                ? `<button onclick="claimMissionReward('${m.id}')" class="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-[10px] font-black uppercase rounded text-white tracking-widest animate-pulse">Claim</button>`
                : `<span class="text-[9px] text-yellow-500 font-extrabold flex items-center space-x-0.5">
                    <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.7-1H9V7a1 1 0 00-2 0v2H6.5a1 1 0 100 2H7v2H5.5a1 1 0 100 2H7v1a1 1 0 102 0v-1h3.3a1 1 0 100-2H9v-2h3.3a1 1 0 100-2z" /></svg>
                    <span>+${m.bounty}</span>
                  </span>`
            }
          </div>
        `;
        dailiesContainer.appendChild(card);
      });

      // 2. Render Lifetime Achievements
      const achContainer = document.getElementById('achievements-list');
      achContainer.innerHTML = "";

      ACHIEVEMENT_TEMPLATES.forEach(ach => {
        const isClaimed = gameState.achievementsClaimed.includes(ach.id);
        const card = document.createElement('div');
        card.className = `p-2.5 rounded-lg border flex justify-between items-center space-x-2 ${isClaimed ? 'bg-slate-950/20 border-slate-900 text-gray-500' : 'bg-slate-950/50 border-slate-800/80'}`;

        card.innerHTML = `
          <div class="flex-1 min-w-0">
            <h4 class="text-xs font-bold ${isClaimed ? 'text-gray-500 line-through' : 'text-white'}">${ach.name}</h4>
            <p class="text-[10px] ${isClaimed ? 'text-gray-600' : 'text-gray-400'} mt-0.5">${ach.desc}</p>
          </div>
          <div>
            ${isClaimed 
              ? `<i data-lucide="check-circle-2" class="w-5 h-5 text-emerald-500/60"></i>`
              : `<span class="text-[9px] text-yellow-500 font-extrabold flex items-center space-x-0.5">
                  <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.7-1H9V7a1 1 0 00-2 0v2H6.5a1 1 0 100 2H7v2H5.5a1 1 0 100 2H7v1a1 1 0 102 0v-1h3.3a1 1 0 100-2H9v-2h3.3a1 1 0 100-2z" /></svg>
                  <span>+${ach.bounty}</span>
                </span>`
            }
          </div>
        `;
        achContainer.appendChild(card);
      });
      try { lucide.createIcons(); } catch(e) {}
    }

    function claimMissionReward(id) {
      const mission = gameState.missions.find(m => m.id === id);
      if (mission && mission.completed && !mission.claimed) {
        mission.claimed = true;
        gameState.totalCoins += mission.bounty;
        playSoundFX('purchase');
        saveLocalData();
        renderQuests();
      }
    }

    // ==========================================
    // 14. ADAPTIVE RESOLUTION RESIZERS
    // ==========================================
    function resizeGameCanvas() {
      canvas.width = VW;
      canvas.height = VH;
    }

    function checkOrientation() {
      const isPortrait = window.innerHeight > window.innerWidth;
      const isMobileDevice = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);

      if (isPortrait && isMobileDevice) {
        orientationOverlay.classList.remove('hidden');
        orientationOverlay.classList.add('flex');
      } else {
        orientationOverlay.classList.add('hidden');
        orientationOverlay.classList.remove('flex');
      }
    }

    // ==========================================
    // 15. INPUT BINDINGS & SCREEN TRIGGERS
    // ==========================================
    window.addEventListener('touchstart', (e) => {
      if (e.target.closest('button') || e.target.closest('input') || e.target.closest('label')) return;
      handleScreenTap();
    }, { passive: true });

    window.addEventListener('mousedown', (e) => {
      if (e.target.closest('button') || e.target.closest('input') || e.target.closest('label')) return;
      if ('ontouchstart' in window) return;
      handleScreenTap();
    });

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        handleScreenTap();
      }
    });

    window.addEventListener('resize', () => {
      resizeGameCanvas();
      checkOrientation();
    });

    // Challenge Mode Buttons Hooks
    function setChallengeMode(mode) {
      playSoundFX('click');
      challengeMode = mode;
      
      const buttons = {
        endless: document.getElementById('mode-endless'),
        hardcore: document.getElementById('mode-hardcore'),
        fast: document.getElementById('mode-fast'),
        chaos: document.getElementById('mode-chaos')
      };

      Object.keys(buttons).forEach(key => {
        if (key === mode) {
          buttons[key].className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all bg-blue-600 text-white shadow-md";
        } else {
          buttons[key].className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all text-gray-400 hover:text-white";
        }
      });

      // Update gameplay badge visibility
      if (hudChallengeBadge) {
        if (mode !== 'endless') {
          hudChallengeBadge.classList.remove('hidden');
          hudChallengeBadge.innerText = mode.toUpperCase();
        } else {
          hudChallengeBadge.classList.add('hidden');
        }
      }
    }

    // ==========================================
    // 16. DIALOG SYSTEM HELPERS
    // ==========================================
    function showAlert(title, message) {
      customAlertTitle.innerText = title;
      customAlertMessage.innerText = message;
      customAlertCancel.classList.add('hidden');
      
      customAlertConfirm.onclick = () => {
        playSoundFX('click');
        customAlertModal.classList.add('hidden');
        customAlertModal.classList.remove('flex');
      };

      customAlertModal.classList.remove('hidden');
      customAlertModal.classList.add('flex');
    }

    function showConfirmModal(title, message, onConfirm) {
      customAlertTitle.innerText = title;
      customAlertMessage.innerText = message;
      customAlertCancel.classList.remove('hidden');
      
      customAlertCancel.onclick = () => {
        playSoundFX('click');
        customAlertModal.classList.add('hidden');
        customAlertModal.classList.remove('flex');
      };

      customAlertConfirm.onclick = () => {
        playSoundFX('click');
        customAlertModal.classList.add('hidden');
        customAlertModal.classList.remove('flex');
        onConfirm();
      };

      customAlertModal.classList.remove('hidden');
      customAlertModal.classList.add('flex');
    }

    function showUpcomingModal(featureName) {
      playSoundFX('click');
      showAlert(`${featureName} (Coming Soon)`, `Locked for Phase 1. Complete version includes dynamic custom avatars and global scoreboards!`);
    }

    function syncHUDUpdates() {
      if (appState === 'PLAYING') {
        hudDistance.innerText = `${globalDistance}m`;
        hudCoins.innerText = sessionCoins;
        
        // Update Biome Progress Bar dynamically
        const bIndex = Math.min(Math.floor(globalDistance / 500), BIOMES.length - 1);
        const currentBiomeData = BIOMES[bIndex];

        if (bIndex < BIOMES.length - 1) {
          const nextBiomeData = BIOMES[bIndex + 1];
          const startDist = bIndex * 500;
          const endDist = startDist + 500;
          const prog = globalDistance - startDist;
          const pct = Math.max(0, Math.min(100, (prog / 500) * 100));

          bpCurrent.innerText = `${currentBiomeData.icon} ${currentBiomeData.name}`;
          bpNext.innerText = `${nextBiomeData.icon} ${nextBiomeData.name}`;
          bpNext.className = "text-[7px] md:text-[8px] font-bold text-gray-500 uppercase tracking-widest truncate text-right";
          bpDistance.innerText = `${globalDistance} / ${endDist}m`;
          bpBar.style.width = `${pct}%`;
          bpBar.className = "h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-150 ease-out";
        } else {
          bpCurrent.innerText = `${currentBiomeData.icon} ${currentBiomeData.name}`;
          bpNext.innerText = "MAX BIOME REACHED";
          bpNext.className = "text-[7px] md:text-[8px] font-black text-yellow-500 uppercase tracking-widest animate-pulse truncate text-right";
          bpDistance.innerText = `${globalDistance}m`;
          bpBar.style.width = `100%`;
          bpBar.className = "h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-150 ease-out animate-pulse";
        }
      }
    }

    // Refresh Daily Missions Countdown Clock Display
    function refreshMissionsCountdown() {
      const target = new Date();
      target.setHours(24, 0, 0, 0); // Next midnight
      const diff = target - new Date();
      const hrs = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      if (missionsTimer) missionsTimer.innerText = `Refreshes in ${hrs}h ${mins}m`;
    }

    function setupEventListeners() {
      document.getElementById('mode-endless').addEventListener('click', () => setChallengeMode('endless'));
      document.getElementById('mode-hardcore').addEventListener('click', () => setChallengeMode('hardcore'));
      document.getElementById('mode-fast').addEventListener('click', () => setChallengeMode('fast'));
      document.getElementById('mode-chaos').addEventListener('click', () => setChallengeMode('chaos'));

      // Dynamic Shop Modals Hooks
      btnShopOpen.addEventListener('click', () => {
        playSoundFX('click');
        renderShop();
        shopModal.classList.remove('hidden');
        shopModal.classList.add('flex');
      });
      btnShopClose.addEventListener('click', () => {
        playSoundFX('click');
        shopModal.classList.add('hidden');
        shopModal.classList.remove('flex');
      });

      tabCharacters.addEventListener('click', () => {
        playSoundFX('click');
        currentShopTab = 'characters';
        tabCharacters.className = "px-4 py-1 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-md transition-all";
        tabSkins.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        tabTrails.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        renderShop();
      });
      tabSkins.addEventListener('click', () => {
        playSoundFX('click');
        currentShopTab = 'skins';
        tabSkins.className = "px-4 py-1 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-md transition-all";
        tabCharacters.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        tabTrails.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        renderShop();
      });
      tabTrails.addEventListener('click', () => {
        playSoundFX('click');
        currentShopTab = 'trails';
        tabTrails.className = "px-4 py-1 bg-blue-600 text-white rounded-lg text-xs font-bold shadow-md transition-all";
        tabCharacters.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        tabSkins.className = "px-4 py-1 text-gray-400 hover:text-white rounded-lg text-xs font-bold transition-all";
        renderShop();
      });

      // Quests Modal Hooks
      btnQuestsOpen.addEventListener('click', () => {
        playSoundFX('click');
        renderQuests();
        questsModal.classList.remove('hidden');
        questsModal.classList.add('flex');
      });
      btnQuestsClose.addEventListener('click', () => {
        playSoundFX('click');
        questsModal.classList.add('hidden');
        questsModal.classList.remove('flex');
      });

      // Other System standard triggers
      toggleSound.addEventListener('change', (e) => {
        gameState.soundEnabled = e.target.checked;
        saveLocalData();
        playSoundFX('click');
      });

      toggleMusic.addEventListener('change', (e) => {
        gameState.musicEnabled = e.target.checked;
        saveLocalData();
        if (gameState.musicEnabled) {
          startMusicEngine();
        } else {
          stopMusicEngine();
        }
      });

      toggleVibration.addEventListener('change', (e) => {
        gameState.vibrationEnabled = e.target.checked;
        saveLocalData();
        if (gameState.vibrationEnabled && navigator.vibrate) {
          navigator.vibrate(50);
        }
      });

      btnSettingsOpen.addEventListener('click', () => {
        playSoundFX('click');
        settingsModal.classList.remove('hidden');
      });
      btnSettingsClose.addEventListener('click', () => {
        playSoundFX('click');
        settingsModal.classList.add('hidden');
      });

      btnStatsOpen.addEventListener('click', () => {
        playSoundFX('click');
        updateUIWithState();
        statsModal.classList.remove('hidden');
      });
      btnStatsClose.addEventListener('click', () => {
        playSoundFX('click');
        statsModal.classList.add('hidden');
      });

      btnCloudStatus.addEventListener('click', () => {
        playSoundFX('click');
        cloudModal.classList.remove('hidden');
      });
      btnCloudModal.addEventListener('click', () => {
        playSoundFX('click');
        cloudModal.classList.remove('hidden');
      });
      btnCloudClose.addEventListener('click', () => {
        playSoundFX('click');
        cloudModal.classList.add('hidden');
      });

      btnCloudConnect.addEventListener('click', () => {
        playSoundFX('click');
        showAlert("Local Offline Play Only", "Firebase and cloud backups have been removed. Save progress is run securely in local storage.");
      });

      btnCloudSync.addEventListener('click', () => {
        playSoundFX('click');
        showAlert("Local Offline Play Only", "Firebase and cloud backups have been removed. Save progress is run securely in local storage.");
      });

      btnResetData.addEventListener('click', () => {
        playSoundFX('click');
        showConfirmModal("Confirm Reset", "Wipe all metrics, scores, and currency records permanently?", () => {
          localStorage.clear();
          gameState = {
            bestScore: 0,
            totalCoins: 0,
            totalFlips: 0,
            totalDeaths: 0,
            totalMeters: 0,
            maxBiomeIndex: 0,
            soundEnabled: true,
            musicEnabled: true,
            vibrationEnabled: true,
            unlockedCharacters: ['gravity_cube'],
            activeCharacter: 'gravity_cube',
            unlockedSkins: ['default'],
            activeSkin: 'default',
            unlockedTrails: ['none'],
            activeTrail: 'none',
            achievementsClaimed: [],
            discoveredBiomes: ['Plains'],
            gamesPlayed: 0,
            coinsSpent: 0,
            missionsDateStamp: "",
            missions: []
          };
          saveLocalData();
          updateUIWithState();
          showAlert("Save State Reset", "Your profile directories have been returned to stock.");
        });
      });

      btnPlayGame.addEventListener('click', startGameplay);
      btnRestart.addEventListener('click', startGameplay);
      btnRevive.addEventListener('click', showAdThenRevive);
      btnGoHome.addEventListener('click', () => {
        playSoundFX('click');
        stopMusicEngine();
        appState = 'MENU';
        demoMode = true;
        resetGeneration();
        gameOverScreen.classList.add('hidden');
        mainMenu.classList.remove('hidden');
      });
    }

    // ==========================================
    // Bind module functions to global window context
    window.buyCharacter = buyCharacter;
    window.equipCharacter = equipCharacter;
    window.equipSkin = equipSkin;
    window.buySkin = buySkin;
    window.equipTrail = equipTrail;
    window.buyTrail = buyTrail;
    window.claimMissionReward = claimMissionReward;

    // ==========================================
    // 17. FLOW STATE COORDINATOR & INTERACTION
    // ==========================================
    let appState = 'SPLASH'; // SPLASH | LOADING | MENU | PLAYING | GAMEOVER
    let demoMode = true;     
    let lastTime = 0;

    function loop(time) {
      if (!lastTime) lastTime = time;
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      if (appState === 'PLAYING' || (appState === 'MENU' && demoMode)) {
        updatePhysics(dt);
      }

      drawGame(time / 1000);
      requestAnimationFrame(loop);
    }

    function initGameLaunch() {
      loadSavedData();
      resetGeneration();
      
      // Auto transition Splash screen -> Loading Screen (2 seconds delay)
      setTimeout(() => {
        splashScreen.classList.add('opacity-0');
        setTimeout(() => {
          splashScreen.classList.add('hidden');
          triggerLoadingSequence();
        }, 1000);
      }, 2000);
    }

    const tips = [
      "Calibrating Gravitational Vectors...",
      "Interpolating Structural Biomes...",
      "Resolving Quantum Matrix Nodes...",
      "Calibrating Polarity Grid Rails...",
      "Powering Vector Engine Core..."
    ];

    function triggerLoadingSequence() {
      loadingScreen.classList.remove('hidden');

      let currentPercent = 0;
      let tipIndex = 0;

      const tipInterval = setInterval(() => {
        tipIndex = (tipIndex + 1) % tips.length;
        if (loadingStatusText) loadingStatusText.innerText = tips[tipIndex];
      }, 400);

      const fillInterval = setInterval(() => {
        currentPercent += Math.floor(Math.random() * 8) + 4;
        if (currentPercent >= 100) {
          currentPercent = 100;
          clearInterval(fillInterval);
          clearInterval(tipInterval);
          
          if (loadingProgressBar) loadingProgressBar.style.width = `100%`;
          if (loadingPercentage) loadingPercentage.innerText = `100%`;

          setTimeout(() => {
            loadingScreen.classList.add('opacity-0');
            setTimeout(() => {
              loadingScreen.classList.add('hidden');
              appState = 'MENU';
              demoMode = true;
              mainMenu.classList.remove('hidden');
              initAudioContext();
              initCloudBackup();
            }, 500);
          }, 300);
        } else {
          if (loadingProgressBar) loadingProgressBar.style.width = `${currentPercent}%`;
          if (loadingPercentage) loadingPercentage.innerText = `${currentPercent}%`;
        }
      }, 70);
    }

    function startGameplay() {
      playSoundFX('click');
      initAudioContext();
      startMusicEngine();

      appState = 'PLAYING';
      demoMode = false;
      sessionCoins = 0;

      // Reset revive counter for this new run
      revivesRemaining = 3;
      if (btnRevive) {
        btnRevive.classList.remove('hidden');
        if (goReviveCount) goReviveCount.innerText = revivesRemaining;
      }

      mainMenu.classList.add('hidden');
      gameOverScreen.classList.add('hidden');
      settingsModal.classList.add('hidden');
      statsModal.classList.add('hidden');
      cloudModal.classList.add('hidden');

      resetGeneration();

      hudChallengeBadge.classList.add('hidden');
      hudChallengeBadge.innerText = challengeMode.toUpperCase();
      if (challengeMode !== 'endless') {
        hudChallengeBadge.classList.remove('hidden');
      }

      gameplayHud.classList.remove('hidden');
      gameplayHud.classList.add('flex');
      
      hudDistance.innerText = "0m";
      hudCoins.innerText = "0";
    }

    function handleScreenTap() {
      if (appState === 'PLAYING') {
        flipGravity();
      }
    }

    function getInterpolatedState() {
      const active = BIOMES[currentBiomeIndex];
      const prev = BIOMES[previousBiomeIndex];
      
      const factor = transitionTimer > 0 ? (1.0 - (transitionTimer / transitionDuration)) : 1.0;

      return {
        name: active.name,
        colorTop: interpolateHex(prev.colorTop, active.colorTop, factor),
        colorBottom: interpolateHex(prev.colorBottom, active.colorBottom, factor),
        groundColor: interpolateHex(prev.groundColor, active.groundColor, factor),
        dangerColor: interpolateHex(prev.dangerColor, active.dangerColor, factor),
        hillColor: interpolateHex(prev.hillColor, active.hillColor, factor),
        mountainColor: interpolateHex(prev.mountainColor, active.mountainColor, factor),
        stars: prev.stars + (active.stars - prev.stars) * factor,
        clouds: prev.clouds + (active.clouds - prev.clouds) * factor,
        mountains: prev.mountains + (active.mountains - prev.mountains) * factor,
        hills: prev.hills + (active.hills - prev.hills) * factor,
        particle: factor > 0.5 ? active.particle : prev.particle,
        treeType: factor > 0.5 ? active.treeType : prev.treeType,
        celestialActive: active.celestial,
        celestialPrev: prev.celestial,
        transitionFactor: factor
      };
    }

    function drawWeatherParticles(type, t) {
      if (type === 'none') return;
      
      for (let i = 0; i < weatherParticles.length; i++) {
        const p = weatherParticles[i];
        
        if (type === 'snow') {
          p.vy = 55 + Math.sin(t + i) * 12;
          p.vx = -40 + Math.cos(t) * 8;
          p.x += p.vx * 0.016; 
          p.y += p.vy * 0.016;
          p.color = "rgba(255,255,255,0.7)";
        } 
        else if (type === 'ash') {
          p.vy = -35 - Math.sin(t + i) * 8;
          p.vx = -70 + Math.cos(t * 0.5) * 15;
          p.x += p.vx * 0.016;
          p.y += p.vy * 0.016;
          p.color = "rgba(239,68,68,0.35)";
        }
        else if (type === 'matrix') {
          p.vy = 210 + Math.random() * 40;
          p.vx = 0;
          p.y += p.vy * 0.016;
          p.color = "rgba(6,182,212,0.45)";
        }
        else if (type === 'cosmic' || type === 'distortion') {
          p.vx = -110;
          p.vy = 0;
          p.x += p.vx * 0.016;
          p.color = type === 'cosmic' ? "rgba(168,85,247,0.35)" : "rgba(244,63,94,0.3)";
        }
        else if (type === 'ambient_fireflies') {
          p.vy = Math.sin(t + i) * 15;
          p.vx = Math.cos(t * 0.5 + i) * 10 - 20;
          p.x += p.vx * 0.016;
          p.y += p.vy * 0.016;
          p.color = "rgba(217, 249, 157, 0.9)"; // Glowing light lime/yellow
        }

        if (p.x < -40) p.x = VW + 40;
        if (p.x > VW + 40) p.x = -40;
        if (p.y < -40) p.y = VH + 40;
        if (p.y > VH + 40) p.y = -40;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        if (type === 'matrix') {
          ctx.fillRect(p.x, p.y, 1.5, 10);
        } else {
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (type === 'islands') {
        ctx.fillStyle = "rgba(255,255,255,0.18)";
        for (let idx = 0; idx < 3; idx++) {
          const islandX = ((idx * 380 - cameraX * 0.08) % (VW + 300)) - 100;
          const islandY = 140 + idx * 45;
          ctx.beginPath();
          ctx.moveTo(islandX, islandY);
          ctx.lineTo(islandX + 110, islandY);
          ctx.lineTo(islandX + 90, islandY + 25);
          ctx.lineTo(islandX + 20, islandY + 25);
          ctx.closePath();
          ctx.fill();
          
          ctx.fillStyle = "rgba(248,250,252,0.25)";
          ctx.beginPath();
          ctx.ellipse(islandX + 55, islandY, 55, 8, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "rgba(255,255,255,0.18)";
        }
      }
    }

    setInterval(syncHUDUpdates, 100);


window.onload = () => {
      initDOMReferences();
      setupEventListeners();
      try {
        lucide.createIcons();
      } catch (e) {
        console.warn("Lucide icons failed to load:", e);
      }
      resizeGameCanvas();
      checkOrientation();
      initGameLaunch();
      refreshMissionsCountdown();
      requestAnimationFrame(loop);
    };

/* --- RESPONSIVE SCREEN MANAGER --- */
const ResponsiveScreenManager = {
    canvas: null,
    hud: null,
    
    init: function() {
        this.canvas = document.querySelector('canvas');
        this.hud = document.getElementById('gameplay-hud');
        if (!this.canvas) return;
        
        this.bindEvents();
        this.handleResize();
    },
    
    bindEvents: function() {
        const throttledResize = () => requestAnimationFrame(() => this.handleResize());
        window.addEventListener('resize', throttledResize);
        window.addEventListener('orientationchange', throttledResize);
        
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', throttledResize);
        }
        
        // CRITICAL FIX: Automatically push canvas down when HUD becomes visible on "Play"
        if (this.hud && window.ResizeObserver) {
            new ResizeObserver(throttledResize).observe(this.hud);
        }
    },
    
    handleResize: function() {
        // 1. Force strict internal resolution so your game physics NEVER break
        this.canvas.width = 960;
        this.canvas.height = 540;
        
        // 2. Safe area logic for mobile notches
        const style = getComputedStyle(document.documentElement);
        const sat = parseInt(style.getPropertyValue('--sat')) || 0;
        const sab = parseInt(style.getPropertyValue('--sab')) || 0;
        
        // 3. Exact HUD measurement dynamically
        let hudHeight = 0;
        if (this.hud) {
            this.hud.style.paddingTop = sat + 'px'; 
            hudHeight = this.hud.offsetHeight; // Returns 0 on menu, but correct height when playing!
        }
        
        const vpWidth = window.visualViewport ? window.visualViewport.width : window.innerWidth;
        const vpHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
        
        // 4. Anchor Canvas exactly below the HUD
        this.canvas.style.position = 'fixed';
        this.canvas.style.top = hudHeight + 'px';
        this.canvas.style.left = '0px';
        
        // 5. Fill remaining space (Removes side black bars & prevents top clipping)
        this.canvas.style.width = vpWidth + 'px';
        this.canvas.style.height = (vpHeight - hudHeight - sab) + 'px';
        this.canvas.style.transform = 'none';
    }
};

// Start the manager securely after the original game initializes
window.addEventListener('load', () => {
    setTimeout(() => ResponsiveScreenManager.init(), 100);
});
