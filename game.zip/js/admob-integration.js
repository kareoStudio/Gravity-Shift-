// ============================================================
// AdMob Integration (admob-plus-cordova) — Kareo Studio
// Gravity Shift
//
// Behaviour:
//  - Banner ad  -> shown only on the Home / Main Menu screen
//  - Rewarded ad -> Shop "Watch Ad for Coins" button + Revive button
//
// IMPORTANT: These are Google's official TEST ad unit IDs.
// Replace BANNER_AD_UNIT_ID and REWARDED_AD_UNIT_ID with your real,
// approved AdMob ad unit IDs before you publish the app.
//
// DEBUG_ADS: set to true to show an on-screen log panel (top of screen)
// with every AdMob step, so you can diagnose issues on a real phone
// without needing a PC / USB debugging. Set to false before release.
// ============================================================
(function () {
  'use strict';

  const BANNER_AD_UNIT_ID   = 'ca-app-pub-3940256099942544/6300978111'; // TEST banner unit
  const REWARDED_AD_UNIT_ID = 'ca-app-pub-3940256099942544/5224354917'; // TEST rewarded unit
  const DEBUG_ADS = true; // <-- set to false once ads are confirmed working

  let bannerAd = null;
  let admobReady = false;
  let debugPanel = null;

  function debugLog(msg) {
    console.log('[AdManager] ' + msg);
    if (!DEBUG_ADS) return;
    try {
      if (!debugPanel) {
        debugPanel = document.createElement('div');
        debugPanel.id = 'admob-debug-panel';
        debugPanel.style.cssText =
          'position:fixed;top:0;left:0;right:0;max-height:38%;overflow-y:auto;' +
          'background:rgba(0,0,0,0.88);color:#39ff14;font-size:11px;line-height:1.4;' +
          'font-family:monospace;z-index:2147483647;padding:6px;white-space:pre-wrap;' +
          'pointer-events:none;';
        (document.body || document.documentElement).appendChild(debugPanel);
      }
      const line = document.createElement('div');
      const t = new Date();
      const ts = ('0' + t.getHours()).slice(-2) + ':' + ('0' + t.getMinutes()).slice(-2) + ':' + ('0' + t.getSeconds()).slice(-2);
      line.textContent = '[' + ts + '] ' + msg;
      debugPanel.appendChild(line);
    } catch (e) { /* ignore */ }
  }

  function pluginAvailable() {
    return typeof admob !== 'undefined';
  }

  debugLog('admob-integration.js loaded, waiting for deviceready...');

  // If deviceready never fires, cordova.js itself isn't loading/bridging correctly.
  const deviceReadyTimeout = setTimeout(function () {
    debugLog('WARNING: deviceready did NOT fire within 8s. cordova.js may be missing/broken.');
  }, 8000);

  document.addEventListener('deviceready', function () {
    clearTimeout(deviceReadyTimeout);
    debugLog('deviceready fired.');

    if (!pluginAvailable()) {
      debugLog('ERROR: window.admob is undefined — admob-plus plugin not present in this build.');
      return;
    }
    debugLog('admob plugin object found. Calling admob.start()...');

    admob.start()
      .then(function () {
        admobReady = true;
        debugLog('admob.start() SUCCESS.');
        try {
          bannerAd = new admob.BannerAd({
            adUnitId: BANNER_AD_UNIT_ID,
            position: admob.BannerAdPosition.BOTTOM_CENTER,
            size: admob.BannerAdSize.BANNER
          });
          debugLog('Banner ad object created.');
        } catch (e) {
          debugLog('ERROR creating banner ad: ' + (e && e.message ? e.message : e));
        }
      })
      .catch(function (e) {
        debugLog('ERROR: admob.start() failed: ' + (e && e.message ? e.message : e));
      });
  }, false);

  // ---------------- Banner (Home screen only) ----------------
  function showBanner() {
    debugLog('showBanner() called. admobReady=' + admobReady + ' bannerAd=' + (!!bannerAd));
    if (!admobReady || !bannerAd) return;
    bannerAd.show()
      .then(function () { debugLog('Banner show() SUCCESS.'); })
      .catch(function (e) { debugLog('ERROR: Banner show failed: ' + (e && e.message ? e.message : e)); });
  }

  function hideBanner() {
    if (!admobReady || !bannerAd) return;
    bannerAd.hide().catch(function () { /* ignore */ });
  }

  // ---------------- Rewarded (Shop + Revive) ----------------
  // onReward()      -> called ONLY if the user watched the ad fully and earned the reward
  // onUnavailable() -> called if ads aren't available right now (plugin missing, no fill,
  //                    load/show failure). Callers decide what to do in that case.
  function showRewarded(onReward, onUnavailable) {
    debugLog('showRewarded() called. admobReady=' + admobReady);
    if (!admobReady || !pluginAvailable()) {
      debugLog('Rewarded ad unavailable (admob not ready).');
      if (typeof onUnavailable === 'function') onUnavailable();
      return;
    }

    let earned = false;
    let settled = false;

    const fail = function (reason) {
      if (settled) return;
      settled = true;
      debugLog('Rewarded ad unavailable: ' + reason);
      if (typeof onUnavailable === 'function') onUnavailable();
    };

    try {
      const rewarded = new admob.RewardedAd({ adUnitId: REWARDED_AD_UNIT_ID });
      debugLog('Rewarded ad object created, loading...');

      rewarded.on('reward', function () { earned = true; debugLog('Rewarded: reward earned event.'); });

      rewarded.on('dismiss', function () {
        debugLog('Rewarded: dismissed. earned=' + earned);
        if (settled) return;
        settled = true;
        if (earned && typeof onReward === 'function') onReward();
      });

      rewarded.on('loadfail', function (e) { fail('loadfail ' + JSON.stringify(e || {})); });
      rewarded.on('showfail', function (e) { fail('showfail ' + JSON.stringify(e || {})); });

      rewarded.load()
        .then(function () {
          debugLog('Rewarded ad loaded. Showing...');
          return rewarded.show();
        })
        .catch(function (e) {
          fail('load/show error: ' + (e && e.message ? e.message : e));
        });
    } catch (e) {
      fail('exception: ' + (e && e.message ? e.message : e));
    }
  }

  window.AdManager = {
    showBanner: showBanner,
    hideBanner: hideBanner,
    showRewarded: showRewarded
  };
})();
