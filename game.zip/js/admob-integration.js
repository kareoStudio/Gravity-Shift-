// ============================================================
// AdMob Integration (admob-plus-cordova) — Kareo Studio
// Gravity Shift
//
// Behaviour:
//  - Banner ad  -> shown only on the Home / Main Menu screen
//  - Rewarded ad -> Shop "Watch Ad for Coins" button + Revive button
//
// IMPORTANT: These are Google's official TEST ad unit IDs.
// Replace BANNER_AD_UNIT_ID and REWARDED_AD_UNIT_ID with your real,
// approved AdMob ad unit IDs before you publish the app.
//
// This file is 100% safe to load even outside Cordova (e.g. testing
// in a normal desktop browser) — it silently no-ops if the "admob"
// plugin object isn't present, so it can never break the game.
// ============================================================
(function () {
  'use strict';

  const BANNER_AD_UNIT_ID   = 'ca-app-pub-3940256099942544/6300978111'; // TEST banner unit
  const REWARDED_AD_UNIT_ID = 'ca-app-pub-3940256099942544/5224354917'; // TEST rewarded unit

  let bannerAd = null;
  let admobReady = false;

  function pluginAvailable() {
    return typeof admob !== 'undefined';
  }

  document.addEventListener('deviceready', function () {
    if (!pluginAvailable()) {
      console.warn('[AdManager] admob-plus plugin not found — running without ads.');
      return;
    }

    admob.start()
      .then(function () {
        admobReady = true;
        try {
          bannerAd = new admob.BannerAd({
            adUnitId: BANNER_AD_UNIT_ID,
            position: admob.BannerAdPosition.BOTTOM_CENTER,
            size: admob.BannerAdSize.BANNER
          });
        } catch (e) {
          console.warn('[AdManager] Failed to create banner ad:', e);
        }
      })
      .catch(function (e) {
        console.warn('[AdManager] admob.start() failed:', e);
      });
  }, false);

  // ---------------- Banner (Home screen only) ----------------
  function showBanner() {
    if (!admobReady || !bannerAd) return;
    bannerAd.show().catch(function (e) {
      console.warn('[AdManager] Banner show failed:', e);
    });
  }

  function hideBanner() {
    if (!admobReady || !bannerAd) return;
    bannerAd.hide().catch(function () { /* ignore */ });
  }

  // ---------------- Rewarded (Shop + Revive) ----------------
  // onReward()      -> called ONLY if the user watched the ad fully and earned the reward
  // onUnavailable() -> called if ads aren't available right now (plugin missing, no fill,
  //                    load/show failure). Callers decide what to do in that case.
  function showRewarded(onReward, onUnavailable) {
    if (!admobReady || !pluginAvailable()) {
      if (typeof onUnavailable === 'function') onUnavailable();
      return;
    }

    let earned = false;
    let settled = false;

    const fail = function () {
      if (settled) return;
      settled = true;
      if (typeof onUnavailable === 'function') onUnavailable();
    };

    try {
      const rewarded = new admob.RewardedAd({ adUnitId: REWARDED_AD_UNIT_ID });

      rewarded.on('reward', function () { earned = true; });

      rewarded.on('dismiss', function () {
        if (settled) return;
        settled = true;
        if (earned && typeof onReward === 'function') onReward();
      });

      rewarded.on('loadfail', fail);
      rewarded.on('showfail', fail);

      rewarded.load()
        .then(function () { return rewarded.show(); })
        .catch(function (e) {
          console.warn('[AdManager] Rewarded ad error:', e);
          fail();
        });
    } catch (e) {
      console.warn('[AdManager] Rewarded ad exception:', e);
      fail();
    }
  }

  window.AdManager = {
    showBanner: showBanner,
    hideBanner: hideBanner,
    showRewarded: showRewarded
  };
})();
