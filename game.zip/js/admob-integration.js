// ============================================================
// AdMob Integration (admob-plus-cordova) — Kareo Studio
// Gravity Shift
//
// Behaviour:
//  - Banner ad  -> shown only on the Home / Main Menu screen
//  - Rewarded ad -> Shop "Watch Ad for Coins" button + Revive button
//
// IMPORTANT: These are Google's official TEST ad unit IDs.
// Replace BANNER_AD_UNIT_ID and REWARDED_AD_UNIT_ID with your real,
// approved AdMob ad unit IDs before you publish the app.
//
// DEBUG_ADS: set to true to show an on-screen log panel (top of screen)
// with every AdMob step, so you can diagnose issues on a real phone
// without needing a PC / USB debugging. Set to false before release.
// ============================================================
(function () {
  'use strict';

  const BANNER_AD_UNIT_ID   = 'ca-app-pub-3940256099942544/6300978111'; // TEST banner unit
  const REWARDED_AD_UNIT_ID = 'ca-app-pub-3940256099942544/5224354917'; // TEST rewarded unit
  const DEBUG_ADS = true; // <-- set to false once ads are confirmed working

  let bannerAd = null;
  let admobReady = false;
  let bannerWanted = false; // true if the game currently wants the banner visible (home screen)
  let debugPanel = null;

  function debugLog(msg) {
    console.log('[AdManager] ' + msg);
    if (!DEBUG_ADS) return;
    try {
      if (!debugPanel) {
        debugPanel = document.createElement('div');
        debugPanel.id = 'admob-debug-panel';
        debugPanel.style.cssText =
          'position:fixed;top:0;left:0;right:0;height:45%;overflow-y:scroll;' +
          '-webkit-overflow-scrolling:touch;background:rgba(0,0,0,0.92);color:#39ff14;' +
          'font-size:11px;line-height:1.5;font-family:monospace;z-index:2147483647;' +
          'padding:6px;white-space:pre-wrap;pointer-events:auto;border-bottom:2px solid #39ff14;';
        (document.body || document.documentElement).appendChild(debugPanel);

        const hint = document.createElement('div');
        hint.textContent = '--- tap here to minimize/expand this log ---';
        hint.style.cssText = 'color:#888;font-style:italic;margin-bottom:4px;';
        debugPanel.appendChild(hint);

        let minimized = false;
        debugPanel.addEventListener('click', function () {
          minimized = !minimized;
          debugPanel.style.height = minimized ? '20px' : '45%';
          debugPanel.style.overflowY = minimized ? 'hidden' : 'scroll';
        });
      }
      const line = document.createElement('div');
      const t = new Date();
      const ts = ('0' + t.getHours()).slice(-2) + ':' + ('0' + t.getMinutes()).slice(-2) + ':' + ('0' + t.getSeconds()).slice(-2);
      line.textContent = '[' + ts + '] ' + msg;
      debugPanel.appendChild(line);
      // Always auto-scroll to the newest line so you never need to manually scroll.
      debugPanel.scrollTop = debugPanel.scrollHeight;
    } catch (e) { /* ignore */ }
  }

  let onNextResume = null; // set while a rewarded ad is open; fires once the app resumes (ad closed)

  document.addEventListener('resume', function () {
    debugLog('App resume event fired (likely returned from ad).');
    if (onNextResume) {
      const cb = onNextResume;
      onNextResume = null;
      cb();
    }
  }, false);

  // Small on-screen countdown shown after the ad is confirmed closed and before
  // the reward is actually granted, so the player gets clear visual confirmation
  // (and the game state never changes while the ad is still on screen).
  function runRewardCountdown(seconds, onDone) {
    try {
      const overlay = document.createElement('div');
      overlay.id = 'ad-reward-countdown-overlay';
      overlay.style.cssText =
        'position:fixed;inset:0;background:rgba(0,0,0,0.78);color:#fff;display:flex;' +
        'align-items:center;justify-content:center;flex-direction:column;' +
        'font-family:sans-serif;z-index:2147483646;text-align:center;';
      const label = document.createElement('div');
      label.textContent = 'Reward incoming...';
      label.style.cssText = 'font-size:18px;letter-spacing:1px;margin-bottom:8px;opacity:0.85;';
      const num = document.createElement('div');
      num.style.cssText = 'font-size:56px;font-weight:900;';
      overlay.appendChild(label);
      overlay.appendChild(num);
      (document.body || document.documentElement).appendChild(overlay);

      let remaining = seconds;
      num.textContent = remaining;
      const iv = setInterval(function () {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(iv);
          if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
          onDone();
        } else {
          num.textContent = remaining;
        }
      }, 1000);
    } catch (e) {
      debugLog('Countdown overlay error: ' + (e && e.message ? e.message : e) + ' — granting reward without it.');
      onDone();
    }
  }

  function pluginAvailable() {
    return typeof admob !== 'undefined';
  }

  debugLog('admob-integration.js loaded, waiting for deviceready...');

  // If deviceready never fires, cordova.js itself isn't loading/bridging correctly.
  const deviceReadyTimeout = setTimeout(function () {
    debugLog('WARNING: deviceready did NOT fire within 8s. cordova.js may be missing/broken.');
  }, 8000);

  document.addEventListener('deviceready', function () {
    clearTimeout(deviceReadyTimeout);
    debugLog('deviceready fired.');

    if (!pluginAvailable()) {
      debugLog('ERROR: window.admob is undefined — admob-plus plugin not present in this build.');
      return;
    }
    debugLog('admob plugin object found. Calling admob.start()...');

    let startSettled = false;

    const startTimeout = setTimeout(function () {
      if (startSettled) return;
      startSettled = true;
      debugLog('WARNING: admob.start() did not resolve within 15s. Proceeding anyway (best-effort).');
      admobReady = true;
      createBannerIfNeeded();
    }, 15000);

    admob.start()
      .then(function () {
        if (startSettled) return;
        startSettled = true;
        clearTimeout(startTimeout);
        admobReady = true;
        debugLog('admob.start() SUCCESS.');
        createBannerIfNeeded();
      })
      .catch(function (e) {
        if (startSettled) return;
        startSettled = true;
        clearTimeout(startTimeout);
        debugLog('ERROR: admob.start() failed: ' + (e && e.message ? e.message : e));
      });
  }, false);

  function createBannerIfNeeded() {
    if (bannerAd) return;
    try {
      bannerAd = new admob.BannerAd({
        adUnitId: BANNER_AD_UNIT_ID,
        position: 'bottom'
      });
      debugLog('Banner ad object created.');

      // Only keep the banner visible when it actually has content to show.
      // If it fails to load (e.g. no internet), hide it immediately so it
      // doesn't sit on screen empty / taking up space.
      bannerAd.on('load', function () {
        debugLog('Banner ad loaded (has content).');
      });
      bannerAd.on('loadfail', function (e) {
        debugLog('Banner loadfail: ' + JSON.stringify(e || {}) + ' — hiding until it can load.');
        bannerAd.hide().catch(function () { /* ignore */ });
      });

      // If the game already wants the banner visible (e.g. we're still on the
      // home screen but the ad object only just became ready now), show it.
      if (bannerWanted) doShowBanner();
    } catch (e) {
      debugLog('ERROR creating banner ad: ' + (e && e.message ? e.message : e));
    }
  }

  // React to connectivity changes: no point holding a banner on screen with no
  // internet, and we should bring it back automatically once connection returns.
  window.addEventListener('online', function () {
    debugLog('Network back online.');
    if (bannerWanted) doShowBanner();
  });
  window.addEventListener('offline', function () {
    debugLog('Network offline — hiding banner.');
    if (bannerAd) bannerAd.hide().catch(function () { /* ignore */ });
  });

  // ---------------- Banner (Home screen only) ----------------
  function doShowBanner() {
    if (!admobReady || !bannerAd) return;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      debugLog('Skipping banner show — device is offline.');
      return;
    }
    let settled = false;
    const t = setTimeout(function () {
      if (!settled) debugLog('WARNING: Banner show() did not respond within 10s.');
    }, 10000);
    bannerAd.show()
      .then(function () { settled = true; clearTimeout(t); debugLog('Banner show() SUCCESS.'); })
      .catch(function (e) { settled = true; clearTimeout(t); debugLog('ERROR: Banner show failed: ' + (e && e.message ? e.message : e)); });
  }

  function showBanner() {
    bannerWanted = true;
    debugLog('showBanner() called. admobReady=' + admobReady + ' bannerAd=' + (!!bannerAd));
    doShowBanner();
  }

  function hideBanner() {
    bannerWanted = false;
    if (!admobReady || !bannerAd) return;
    bannerAd.hide().catch(function () { /* ignore */ });
  }

  // ---------------- Rewarded (Shop + Revive) ----------------
  // onReward()      -> called ONLY if the user watched the ad fully and earned the reward
  // onUnavailable() -> called if ads aren't available right now (plugin missing, no fill,
  //                    load/show failure). Callers decide what to do in that case.
  function showRewarded(onReward, onUnavailable) {
    debugLog('showRewarded() called. admobReady=' + admobReady);
    if (!admobReady || !pluginAvailable()) {
      debugLog('Rewarded ad unavailable (admob not ready).');
      if (typeof onUnavailable === 'function') onUnavailable();
      return;
    }

    let earned = false;
    let settled = false;
    let displayed = false; // true once the ad has actually opened on screen
    let openedAt = 0;
    let currentTimeout = null;
    let resumeArmed = false;
    const MIN_WATCH_MS = 5000; // minimum time on-screen to count as "genuinely watched"

    // Called once we're confident the ad has actually been closed (app resumed,
    // or a dismiss/close plugin event, or the last-resort timeout). Only THEN do
    // we run the countdown and grant the reward — never while the ad may still
    // be on screen.
    const handleAdClosed = function (source) {
      if (settled) return;
      settled = true;
      clearTimeout(currentTimeout);
      onNextResume = null;
      const watchedMs = openedAt ? (Date.now() - openedAt) : 0;
      const watchedLongEnough = watchedMs >= MIN_WATCH_MS;
      debugLog('Ad closed (' + source + '). earned(event)=' + earned + ' watchedMs=' + watchedMs);
      if (earned || watchedLongEnough) {
        debugLog('Ad confirmed closed — starting 5s countdown before granting reward.');
        runRewardCountdown(5, function () {
          if (typeof onReward === 'function') onReward();
        });
      }
    };

    const armResumeDetection = function () {
      if (resumeArmed) return;
      resumeArmed = true;
      onNextResume = function () { handleAdClosed('app resume'); };
    };

    const fail = function (reason) {
      if (settled) return;
      // If the ad already opened on screen, a late load/show promise rejection is
      // just a plugin quirk — the real outcome is decided by the reward/dismiss
      // events instead, so don't treat it as a hard failure once displayed.
      if (displayed) {
        debugLog('Ignoring post-display error: ' + reason);
        return;
      }
      settled = true;
      clearTimeout(currentTimeout);
      debugLog('Rewarded ad unavailable: ' + reason);
      if (typeof onUnavailable === 'function') onUnavailable();
    };

    // Stage 1: loading the ad shouldn't take long.
    currentTimeout = setTimeout(function () {
      fail('load timed out after 20s (no fill)');
    }, 20000);

    try {
      const rewarded = new admob.RewardedAd({ adUnitId: REWARDED_AD_UNIT_ID });
      debugLog('Rewarded ad object created, loading...');

      rewarded.on('reward', function () {
        earned = true;
        debugLog('Rewarded: reward earned event (waiting for ad to actually close before granting).');
      });
      rewarded.on('show', function () {
        displayed = true;
        if (!openedAt) openedAt = Date.now();
        debugLog('Rewarded: show event (ad is on screen).');
        // Stage 2: once actually on screen, give plenty of time for a full watch
        // (rewarded videos commonly run 15-30s+) before giving up on a response.
        clearTimeout(currentTimeout);
        currentTimeout = setTimeout(function () { handleAdClosed('90s fallback timeout'); }, 90000);
        armResumeDetection();
      });

      // Different plugin/versions have used different names for "ad closed" — handle both,
      // as a secondary signal alongside the app-resume detection above.
      rewarded.on('dismiss', function () { handleAdClosed('dismiss event'); });
      rewarded.on('close', function () { handleAdClosed('close event'); });

      rewarded.on('loadfail', function (e) { fail('loadfail ' + JSON.stringify(e || {})); });
      rewarded.on('showfail', function (e) { fail('showfail ' + JSON.stringify(e || {})); });

      rewarded.load()
        .then(function () {
          debugLog('Rewarded ad loaded. Showing...');
          displayed = true; // showing now begins; treat as displayed even if no 'show' event fires
          if (!openedAt) openedAt = Date.now();
          clearTimeout(currentTimeout);
          currentTimeout = setTimeout(function () { handleAdClosed('90s fallback timeout'); }, 90000);
          armResumeDetection();
          return rewarded.show();
        })
        .catch(function (e) {
          fail('load/show error: ' + (e && e.message ? e.message : e));
        });
    } catch (e) {
      fail('exception: ' + (e && e.message ? e.message : e));
    }
  }

  window.AdManager = {
    showBanner: showBanner,
    hideBanner: hideBanner,
    showRewarded: showRewarded
  };
})();
